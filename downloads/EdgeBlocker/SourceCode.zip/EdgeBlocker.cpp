#include <windows.h>
#include <commctrl.h>
#include <tchar.h>
#include <shellapi.h>
#include <uxtheme.h>
#include <dwmapi.h>
#include <string>
#include "UAHMenuBar.h"

#pragma comment(lib, "uxtheme.lib")
#pragma comment(lib, "dwmapi.lib")

// Menü ID'leri güncellendi
#define ID_WEBSITE 201
#define ID_GITHUB  202
#define ID_DONATE  203
#define ID_WEBVIEW_ENABLE 204
#define ID_WEBVIEW_DISABLE 205
#define ID_PARAMETERS 206

// Global değişkenler
HINSTANCE hInst;
HWND hBlockBtn, hUnblockBtn;
HWND hStatusText;
bool g_blockWebView = true; // WebView engelleme durumu
HMENU hWebViewMenu = NULL; // WebView menü handle'ı eklendi
static HTHEME g_menuTheme = nullptr;
static HBRUSH g_brBarBackground = CreateSolidBrush(RGB(32, 32, 32));  // Dark mode rengi

// Dark mode için gereken yapılar
struct IMMERSIVE_HC_CACHE
{
    DWORD Dirty;
    DWORD Running;
};

// Windows 10 1809 ve üzeri için dark mode API'leri
using fnSetPreferredAppMode = void (WINAPI*)(DWORD);
using fnAllowDarkModeForWindow = bool (WINAPI*)(HWND, bool);
using fnShouldAppsUseDarkMode = bool (WINAPI*)();

// Global dark mode function pointers
fnSetPreferredAppMode SetPreferredAppMode;
fnAllowDarkModeForWindow AllowDarkModeForWindow;
fnShouldAppsUseDarkMode ShouldAppsUseDarkMode;

// Dark mode için yeni global değişkenler
bool g_darkModeEnabled = true;
HBRUSH g_darkModeBrush = NULL;

// Dark mode renk tanımları
const COLORREF DARK_BG_COLOR = RGB(32, 32, 32);
const COLORREF DARK_TEXT_COLOR = RGB(255, 255, 255);
const COLORREF DARK_BUTTON_COLOR = RGB(51, 51, 51);
const COLORREF DARK_BUTTON_HOVER = RGB(75, 75, 75);     // Daha belirgin hover rengi
const COLORREF DARK_BUTTON_PRESSED = RGB(40, 40, 40);
const COLORREF STATUS_GREEN = RGB(46, 160, 67);         // Daha açık yeşil
const COLORREF STATUS_RED = RGB(218, 54, 51);          // Daha açık kırmızı
const COLORREF DARK_MENU_BG = RGB(32, 32, 32);
const COLORREF DARK_MENU_TEXT = RGB(255, 255, 255);
const COLORREF DARK_MENUBAR_BG = RGB(32, 32, 32);
const COLORREF DARK_MENUBAR_TEXT = RGB(255, 255, 255);

// Dark mode için gereken yapılar kısmına ekle:
#define DWMWA_USE_IMMERSIVE_DARK_MODE 20
#define DWMWA_CAPTION_COLOR 35

// Forward declarations
bool BlockWebView();
bool UnblockWebView();

// Edge durumunu kontrol eden fonksiyon - en üste taşındı
bool IsEdgeBlocked() {
    HKEY hKey;
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\msedge.exe",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        RegCloseKey(hKey);
        return true;
    }
    return false;
}

// WebView durumunu kontrol eden fonksiyon
bool IsWebViewBlocked() {
    HKEY hKey;
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\msedgewebview2.exe",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        RegCloseKey(hKey);
        return true;
    }
    return false;
}

// Durum göstergesini güncelle fonksiyonu - global olarak tanımlandı
void UpdateStatusText() {
    bool edgeBlocked = IsEdgeBlocked();
    bool webviewBlocked = IsWebViewBlocked();
    
    std::wstring status = L"Edge";
    status += edgeBlocked ? L"Devre Dışı" : L"Etkin";
    status += L" | WebView ";
    status += webviewBlocked ? L"Devre Dışı" : L"Etkin";
    
    SetWindowText(hStatusText, status.c_str());
    InvalidateRect(hStatusText, NULL, TRUE);
}

// Registry işlemleri için fonksiyonlar
bool BlockEdge(bool blockWebViewToo = true) {
    bool success = true;
    
    HKEY hKey;
    LONG result = RegCreateKeyEx(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\msedge.exe",
        0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL);
    
    if (result != ERROR_SUCCESS) success = false;
    
    const wchar_t* value = L"1";
    result = RegSetValueEx(hKey, L"Debugger", 0, REG_SZ, (BYTE*)value, 
        (wcslen(value) + 1) * sizeof(wchar_t));
    
    RegCloseKey(hKey);
    if (result != ERROR_SUCCESS) success = false;

    if (blockWebViewToo && !BlockWebView()) success = false;
    
    return success;
}

// UnblockEdge fonksiyonunu düzelt
bool UnblockEdge(bool unblockWebViewToo = true) {
    bool success = true;
    
    // Edge'i her zaman etkinleştir
    if (RegDeleteKey(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\msedge.exe")
        != ERROR_SUCCESS) success = false;

    // WebView'ı sadece menüde işaret yoksa etkinleştir
    if (unblockWebViewToo && !g_blockWebView) {
        if (!UnblockWebView()) success = false;
    }
    
    return success;
}

// WebView engelleme fonksiyonu
bool BlockWebView() {
    HKEY hKey;
    LONG result = RegCreateKeyEx(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\msedgewebview2.exe",
        0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL);
    
    if (result != ERROR_SUCCESS) return false;
    
    const wchar_t* value = L"1";
    result = RegSetValueEx(hKey, L"Debugger", 0, REG_SZ, (BYTE*)value, 
        (wcslen(value) + 1) * sizeof(wchar_t));
    
    RegCloseKey(hKey);
    return result == ERROR_SUCCESS;
}

// WebView engeli kaldırma fonksiyonu
bool UnblockWebView() {
    return (RegDeleteKey(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\msedgewebview2.exe")
        == ERROR_SUCCESS);
}

// Parametre yardım mesajı
void ShowParameterHelp(HWND hwnd) {
    const wchar_t* helpText = 
        L"Komut Satırı Parametreleri:\n\n"
        L"/block         : Edge'i engelle\n"
        L"/unblock      : Edge engelini kaldır\n"
        L"/webview      : WebView'ı da engelle (varsayılan)\n"
        L"/nowebview    : WebView'ı engelleme\n"
        L"/status       : Mevcut durumu göster\n\n"
        L"Örnek:\n"
        L"EdgeBlocker.exe /block /webview";
    
    MessageBox(hwnd, helpText, L"Parametre Kullanımı", MB_OK | MB_ICONINFORMATION);
}

// Dark mode init fonksiyonu
bool InitDarkMode() {
    HMODULE hUxtheme = LoadLibraryEx(L"uxtheme.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (!hUxtheme) return false;

    SetPreferredAppMode = reinterpret_cast<fnSetPreferredAppMode>(GetProcAddress(hUxtheme, MAKEINTRESOURCEA(135)));
    AllowDarkModeForWindow = reinterpret_cast<fnAllowDarkModeForWindow>(GetProcAddress(hUxtheme, MAKEINTRESOURCEA(133)));
    ShouldAppsUseDarkMode = reinterpret_cast<fnShouldAppsUseDarkMode>(GetProcAddress(hUxtheme, MAKEINTRESOURCEA(132)));

    if (SetPreferredAppMode) {
        SetPreferredAppMode(2); // Enable dark mode
    }

    g_darkModeBrush = CreateSolidBrush(DARK_BG_COLOR);

    // Menü arkaplan rengini ayarla
    MENUINFO mi = { sizeof(MENUINFO) };
    mi.fMask = MIM_BACKGROUND | MIM_APPLYTOSUBMENUS;
    mi.hbrBack = CreateSolidBrush(DARK_MENU_BG);

    return true;
}

// WndProc içinde msg parametresini kullanan yerlerde farklı bir isim kullanalım
LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    LRESULT lr;
    if (UAHWndProc(hwnd, uMsg, wParam, lParam, &lr)) {
        return lr;
    }

    switch (uMsg) {
        case WM_CREATE: {
            // Dark mode için pencere ayarları
            if (AllowDarkModeForWindow) {
                AllowDarkModeForWindow(hwnd, true);
            }

            // Title bar ayarları
            BOOL value = TRUE;
            DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, &value, sizeof(value));
            
            // Title bar rengi için
            COLORREF captionColor = RGB(32, 32, 32); // Title bar rengi
            DwmSetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, &captionColor, sizeof(captionColor));

            // Köşeleri sivri yap
            DWM_WINDOW_CORNER_PREFERENCE corner = DWMWCP_DONOTROUND;
            DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, &corner, sizeof(corner));

            RECT rcClient;
            GetClientRect(hwnd, &rcClient);
            int clientWidth = rcClient.right - rcClient.left;
            int clientHeight = rcClient.bottom - rcClient.top;
            
            // Button pozisyonlarını üste taşı
            int buttonY = 20; // Menü çubuğunun altından başlat
            int buttonWidth = 300;
            int buttonHeight = 36;
            int buttonX = (clientWidth - buttonWidth) / 2;

            // Modern butonlar - dark mode style
            DWORD buttonStyle = WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON | BS_OWNERDRAW;
            hBlockBtn = CreateWindow(L"BUTTON", L"Microsoft Edge'i Devre Dışı Bırak",
                buttonStyle,
                buttonX, buttonY, buttonWidth, buttonHeight, 
                hwnd, (HMENU)1001, // Benzersiz bir ID
                hInst, NULL);

            if (AllowDarkModeForWindow) {
                AllowDarkModeForWindow(hBlockBtn, true);
            }
            
            hUnblockBtn = CreateWindow(L"BUTTON", L"Microsoft Edge Etkinleştir",
                buttonStyle,
                buttonX, buttonY + buttonHeight + 20, buttonWidth, buttonHeight, 
                hwnd, (HMENU)1002, // Benzersiz bir ID
                hInst, NULL);

            // Durum göstergesini en alta taşı
            int statusY = clientHeight - 34; // Alt kısımdan 34 piksel yukarıda
            hStatusText = CreateWindow(L"STATIC", L"",
                WS_VISIBLE | WS_CHILD | SS_CENTER | SS_CENTERIMAGE,
                0, statusY, clientWidth, 34,
                hwnd, NULL, hInst, NULL);

            // DPI Farkındalığı
            SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);

            // Menü oluştur
            HMENU hMenu = CreateMenu();
            hWebViewMenu = CreatePopupMenu();
            HMENU hAboutMenu = CreatePopupMenu();

            // WebView menü öğesi
            AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hWebViewMenu, L"WebView");
            AppendMenu(hWebViewMenu, MF_STRING | (g_blockWebView ? MF_CHECKED : MF_UNCHECKED), 
                ID_WEBVIEW_ENABLE, L"WebView'ı da Engelle");

            // Parametreler menü öğesi
            AppendMenu(hMenu, MF_STRING, ID_PARAMETERS, L"Parametreler");

            // Hakkında menüsü ve alt öğeleri
            AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hAboutMenu, L"Hakkında");
            AppendMenu(hAboutMenu, MF_STRING, ID_WEBSITE, L"İnternet Sitesi");
            AppendMenu(hAboutMenu, MF_STRING, ID_GITHUB, L"GitHub");
            AppendMenu(hAboutMenu, MF_STRING, ID_DONATE, L"Bağış Yap");

            // Menüyü pencereye ata
            SetMenu(hwnd, hMenu);

            // Font oluştur
            HFONT hFont = CreateFont(20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                TURKISH_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS,
                CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");

            SendMessage(hBlockBtn, WM_SETFONT, (WPARAM)hFont, TRUE);
            SendMessage(hUnblockBtn, WM_SETFONT, (WPARAM)hFont, TRUE);
            SendMessage(hStatusText, WM_SETFONT, (WPARAM)hFont, TRUE);

            // Buton kenarları için özel tema ayarları
            SetWindowTheme(hBlockBtn, L"Explorer", NULL);  // Explorer teması daha ince kenarlar sağlar
            SetWindowTheme(hUnblockBtn, L"Explorer", NULL);

            // Durum göstergesini güncelle ve renklendir
            UpdateStatusText();

            break;
        }

        case WM_SIZE: {
            // Pencere boyutu değiştiğinde durum göstergesini yeniden konumlandır
            RECT rcClient;
            GetClientRect(hwnd, &rcClient);
            int clientWidth = rcClient.right - rcClient.left;
            int clientHeight = rcClient.bottom - rcClient.top;
            
            SetWindowPos(hStatusText, NULL,
                0, clientHeight - 34,  // Alt kısma yerleştir
                clientWidth, 34,       // Tam genişlik, 34px yükseklik
                SWP_NOZORDER);
            break;
        }

        case WM_CTLCOLORBTN: {
            HDC hdc = (HDC)wParam;
            SetTextColor(hdc, DARK_TEXT_COLOR);
            SetBkColor(hdc, DARK_BUTTON_COLOR);
            if (!g_darkModeBrush) g_darkModeBrush = CreateSolidBrush(DARK_BUTTON_COLOR);
            return (INT_PTR)g_darkModeBrush;
        }

        case WM_CTLCOLORSTATIC: {
            HDC hdcStatic = (HDC)wParam;
            HWND hwndStatic = (HWND)lParam;
            
            if (hwndStatic == hStatusText) {
                bool isBlocked = IsEdgeBlocked();
                SetBkColor(hdcStatic, isBlocked ? 
                    STATUS_RED :    // Daha açık kırmızı
                    STATUS_GREEN);  // Daha açık yeşil
                SetTextColor(hdcStatic, RGB(255, 255, 255));
                
                static HBRUSH hBrush = NULL;
                if (hBrush) DeleteObject(hBrush);
                hBrush = CreateSolidBrush(isBlocked ? 
                    STATUS_RED : 
                    STATUS_GREEN);
                return (INT_PTR)hBrush;
            }
            
            SetTextColor(hdcStatic, DARK_TEXT_COLOR);
            SetBkColor(hdcStatic, DARK_BG_COLOR);
            return (INT_PTR)g_darkModeBrush;
        }

        case WM_CTLCOLORDLG:
        case WM_CTLCOLORLISTBOX:
        case WM_CTLCOLOREDIT: {
            HDC hdc = (HDC)wParam;
            SetTextColor(hdc, DARK_TEXT_COLOR);
            SetBkColor(hdc, DARK_BG_COLOR);
            return (INT_PTR)g_darkModeBrush;
        }

        case WM_ERASEBKGND: {
            HDC hdc = (HDC)wParam;
            RECT rc;
            GetClientRect(hwnd, &rc);
            FillRect(hdc, &rc, g_darkModeBrush);
            return 1;
        }

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case 1001: // Block button ID
                    if (BlockEdge(g_blockWebView)) {
                        UpdateStatusText();
                        std::wstring msg = L"Microsoft Edge başarıyla devre dışı bırakıldı!";
                        if (g_blockWebView) {
                            msg += L"\nWebView da devre dışı bırakıldı!";
                        }
                        MessageBox(hwnd, msg.c_str(), L"Başarılı", MB_OK | MB_ICONINFORMATION);
                    }
                    break;
                case 1002: // Unblock button ID
                    if (UnblockEdge(true)) {
                        UpdateStatusText();
                        std::wstring msg = L"Microsoft Edge etkinleştirildi!";
                        if (!g_blockWebView) {
                            msg += L"\nWebView de etkinleştirildi!";
                        }
                        MessageBox(hwnd, msg.c_str(), L"Başarılı", MB_OK | MB_ICONINFORMATION);
                    }
                    break;
                case ID_WEBSITE:
                    ShellExecute(NULL, L"open", L"https://shade-cloud.vercel.app", NULL, NULL, SW_SHOW);
                    break;
                case ID_GITHUB:
                    ShellExecute(NULL, L"open", L"https://github.com/shadesofdeath", NULL, NULL, SW_SHOW);
                    break;
                case ID_DONATE:
                    ShellExecute(NULL, L"open", L"https://buymeacoffee.com/berkayay", NULL, NULL, SW_SHOW);
                    break;
                case ID_WEBVIEW_ENABLE:
                    g_blockWebView = !g_blockWebView; // Toggle durumu
                    CheckMenuItem(hWebViewMenu, ID_WEBVIEW_ENABLE, 
                        MF_BYCOMMAND | (g_blockWebView ? MF_CHECKED : MF_UNCHECKED));
                    break;
                case ID_PARAMETERS:
                    ShowParameterHelp(hwnd);
                    break;
            }
            break;

        case WM_DESTROY:
            if (g_darkModeBrush) DeleteObject(g_darkModeBrush);
            if (g_menuTheme) {
                CloseThemeData(g_menuTheme);
                g_menuTheme = nullptr;
            }
            if (g_brBarBackground) DeleteObject(g_brBarBackground);
            PostQuitMessage(0);
            break;

        case WM_MEASUREITEM: {
            LPMEASUREITEMSTRUCT lpmis = (LPMEASUREITEMSTRUCT)lParam;
            lpmis->itemHeight = 25; // Menü öğesi yüksekliği
            return TRUE;
        }

        case WM_DRAWITEM: {
            LPDRAWITEMSTRUCT lpdis = (LPDRAWITEMSTRUCT)lParam;
            if (lpdis->CtlType == ODT_MENU) {
                bool isMainMenu = (GetMenu(hwnd) == (HMENU)lpdis->hwndItem);
                BOOL isSelected = lpdis->itemState & ODS_SELECTED;
                
                // Arkaplan rengi
                COLORREF bgColor;
                if (isMainMenu) {
                    bgColor = isSelected ? RGB(70, 70, 70) : DARK_MENUBAR_BG;
                } else {
                    bgColor = isSelected ? RGB(70, 70, 70) : DARK_MENU_BG;
                }
                
                FillRect(lpdis->hDC, &lpdis->rcItem, CreateSolidBrush(bgColor));
                
                // Metin rengi
                SetTextColor(lpdis->hDC, isMainMenu ? DARK_MENUBAR_TEXT : DARK_MENU_TEXT);
                SetBkMode(lpdis->hDC, TRANSPARENT);
                
                // Menü metnini çiz
                WCHAR text[256] = {0};
                if (isMainMenu) {
                    GetMenuString((HMENU)lpdis->hwndItem, lpdis->itemID, text, 256, MF_BYCOMMAND);
                } else if (lpdis->itemData) {
                    GetMenuString((HMENU)lpdis->hwndItem, lpdis->itemID, text, 256, MF_BYCOMMAND);
                }
                
                // Metin pozisyonunu ayarla
                RECT textRect = lpdis->rcItem;
                textRect.left += 8; // Sol kenar boşluğu
                
                DrawText(lpdis->hDC, text, -1, &textRect, 
                    DT_SINGLELINE | DT_VCENTER | (isMainMenu ? DT_CENTER : DT_LEFT));
                
                return TRUE;
            }
            else if (lpdis->CtlType == ODT_BUTTON) {
                bool isPressed = lpdis->itemState & ODS_SELECTED;
                bool isHot = lpdis->itemState & ODS_HOTLIGHT || (GetCapture() == lpdis->hwndItem);
                bool isFocused = lpdis->itemState & ODS_FOCUS;
                
                // Buton arkaplanı
                COLORREF btnColor;
                if (isPressed)
                    btnColor = DARK_BUTTON_PRESSED;
                else if (isHot)
                    btnColor = DARK_BUTTON_HOVER;
                else
                    btnColor = DARK_BUTTON_COLOR;

                // Buton arkaplanını doldur
                HBRUSH hBrush = CreateSolidBrush(btnColor);
                FillRect(lpdis->hDC, &lpdis->rcItem, hBrush);
                DeleteObject(hBrush);
                
                // Buton kenarı çiz
                HPEN hPen = CreatePen(PS_SOLID, 1, isHot ? DARK_BUTTON_HOVER : RGB(45, 45, 45));
                HPEN hOldPen = (HPEN)SelectObject(lpdis->hDC, hPen);
                SelectObject(lpdis->hDC, GetStockObject(NULL_BRUSH));
                Rectangle(lpdis->hDC, lpdis->rcItem.left, lpdis->rcItem.top, 
                    lpdis->rcItem.right, lpdis->rcItem.bottom);
                SelectObject(lpdis->hDC, hOldPen);
                DeleteObject(hPen);
                
                // Buton metni
                SetTextColor(lpdis->hDC, DARK_TEXT_COLOR);
                SetBkMode(lpdis->hDC, TRANSPARENT);
                
                WCHAR text[256];
                GetWindowText(lpdis->hwndItem, text, 256);
                
                // Metni ortala
                DrawText(lpdis->hDC, text, -1, &lpdis->rcItem, 
                    DT_SINGLELINE | DT_CENTER | DT_VCENTER);
                
                if (isFocused) {
                    RECT focusRect = lpdis->rcItem;
                    InflateRect(&focusRect, -3, -3);
                    DrawFocusRect(lpdis->hDC, &focusRect);
                }
                
                return TRUE;
            }
            return FALSE;
        }

        case WM_NCPAINT:
        case WM_NCACTIVATE: {
            BOOL value = TRUE;
            DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, &value, sizeof(value));
            
            COLORREF captionColor = RGB(32, 32, 32);
            DwmSetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, &captionColor, sizeof(captionColor));
            
            // Windows'un varsayılan title bar çizimini kullan
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
        }

        case WM_MENUCHAR: {
            // Menüde alt+tuş kombinasyonlarını engelle
            return MAKELRESULT(0, MNC_CLOSE);
        }

        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
    return 0;
}

// WinMain fonksiyonunda pencere boyutunu güncelle
int WINAPI wWinMain(
    _In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE /* hPrevInstance */,  // Kullanılmıyor
    _In_ LPWSTR /* lpCmdLine */,            // Kullanılmıyor
    _In_ int nShowCmd)
{
    hInst = hInstance;

    // Komut satırı parametrelerini işle
    int argc;
    LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    bool validCommand = false;
    
    if (argc > 1) {
        bool blockRequested = false;
        bool unblockRequested = false;
        bool showStatus = false;
        bool showHelp = false;
        
        for (int i = 1; i < argc; i++) {
            if (_wcsicmp(argv[i], L"/block") == 0) {
                blockRequested = true;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/unblock") == 0) {
                unblockRequested = true;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/webview") == 0) {
                g_blockWebView = true;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/nowebview") == 0) {
                g_blockWebView = false;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/status") == 0) {
                showStatus = true;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/?") == 0 || _wcsicmp(argv[i], L"/help") == 0) {
                showHelp = true;
                validCommand = true;
            }
        }
        
        if (!validCommand) {
            ShowParameterHelp(NULL);
            LocalFree(argv);
            return 1;
        }

        if (showHelp) {
            ShowParameterHelp(NULL);
            LocalFree(argv);
            return 0;
        }
        
        if (showStatus) {
            std::wstring status = L"Edge: ";
            status += IsEdgeBlocked() ? L"Devre Dışı" : L"Etkin";
            status += L"\nWebView: ";
            status += IsWebViewBlocked() ? L"Devre Dışı" : L"Etkin";
            MessageBox(NULL, status.c_str(), L"Durum", MB_OK | MB_ICONINFORMATION); // MB_INFORMATION yerine MB_ICONINFORMATION kullanıldı
            LocalFree(argv);
            return 0;
        }
        
        if (blockRequested) {
            BlockEdge(g_blockWebView);
            LocalFree(argv);
            return 0;
        }
        
        if (unblockRequested) {
            UnblockEdge(g_blockWebView);
            LocalFree(argv);
            return 0;
        }

        LocalFree(argv);
        return 0; // Herhangi bir geçerli komut varsa GUI'yi açma
    }
    
    LocalFree(argv);

    WNDCLASSEX wc = {0};
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszClassName = L"EdgeBlockerClass";
    // İkonu kaynaktan yükle
    wc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(1));
    wc.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(1));

    if (!RegisterClassEx(&wc)) {
        MessageBox(NULL, L"Window Registration Failed!", L"Error", 
            MB_OK | MB_ICONERROR);
        return 0;
    }

    // DPI ölçeklendirme için
    SetProcessDPIAware();

    // Dark mode'u başlat
    InitDarkMode();

    // Ekran boyutlarını al
    RECT workArea;
    SystemParametersInfo(SPI_GETWORKAREA, 0, &workArea, 0);
    
    // Pencere boyutları
    int windowWidth = 500;
    int windowHeight = 250; // Yüksekliği ayarla

    // Çalışma alanının merkezine konumlandır
    int windowX = workArea.left + (workArea.right - workArea.left - windowWidth) / 2;
    int windowY = workArea.top + (workArea.bottom - workArea.top - windowHeight) / 2;

    HWND hwnd = CreateWindowEx(
        WS_EX_COMPOSITED, // Daha pürüzsüz görünüm
        L"EdgeBlockerClass",
        L"Edge Blocker",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,  // Window style güncellendi
        windowX, windowY,    // Merkez konumu
        windowWidth, windowHeight,
        NULL, NULL, hInstance, NULL);

    if (hwnd == NULL) {
        MessageBox(NULL, L"Window Creation Failed!", L"Error", 
            MB_OK | MB_ICONERROR);
        return 0;
    }

    ShowWindow(hwnd, nShowCmd);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (int)msg.wParam;
}

