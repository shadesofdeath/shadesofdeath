#include <windows.h>
#include <commctrl.h>
#include <tchar.h>
#include <shellapi.h>
#include <uxtheme.h>
#include <string>

#pragma comment(lib, "uxtheme.lib")

// Menü ID'leri güncellendi
#define ID_WEBSITE 201
#define ID_GITHUB  202
#define ID_DONATE  203
#define ID_WEBVIEW_ENABLE 204
#define ID_WEBVIEW_DISABLE 205
#define ID_PARAMETERS 206

// Global değişkenler
HINSTANCE hInst;
HWND hBlockBtn, hUnblockBtn;
HWND hStatusText;
bool g_blockWebView = true; // WebView engelleme durumu
HMENU hWebViewMenu = NULL; // WebView menü handle'ı eklendi

// Forward declarations
bool BlockWebView();
bool UnblockWebView();

// Edge durumunu kontrol eden fonksiyon - en üste taşındı
bool IsEdgeBlocked() {
    HKEY hKey;
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\msedge.exe",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        RegCloseKey(hKey);
        return true;
    }
    return false;
}

// WebView durumunu kontrol eden fonksiyon
bool IsWebViewBlocked() {
    HKEY hKey;
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\msedgewebview2.exe",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        RegCloseKey(hKey);
        return true;
    }
    return false;
}

// Durum göstergesini güncelle fonksiyonu - global olarak tanımlandı
void UpdateStatusText() {
    bool edgeBlocked = IsEdgeBlocked();
    bool webviewBlocked = IsWebViewBlocked();
    
    std::wstring status = L"Durum : Edge ";
    status += edgeBlocked ? L"Devre Dışı" : L"Etkin";
    status += L" | WebView ";
    status += webviewBlocked ? L"Devre Dışı" : L"Etkin";
    
    SetWindowText(hStatusText, status.c_str());
    InvalidateRect(hStatusText, NULL, TRUE);
}

// Registry işlemleri için fonksiyonlar
bool BlockEdge(bool blockWebViewToo = true) {
    bool success = true;
    
    HKEY hKey;
    LONG result = RegCreateKeyEx(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\msedge.exe",
        0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL);
    
    if (result != ERROR_SUCCESS) success = false;
    
    const wchar_t* value = L"1";
    result = RegSetValueEx(hKey, L"Debugger", 0, REG_SZ, (BYTE*)value, 
        (wcslen(value) + 1) * sizeof(wchar_t));
    
    RegCloseKey(hKey);
    if (result != ERROR_SUCCESS) success = false;

    if (blockWebViewToo && !BlockWebView()) success = false;
    
    return success;
}

// UnblockEdge fonksiyonunu düzelt
bool UnblockEdge(bool unblockWebViewToo = true) {
    bool success = true;
    
    // Edge'i her zaman etkinleştir
    if (RegDeleteKey(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\msedge.exe")
        != ERROR_SUCCESS) success = false;

    // WebView'ı sadece menüde işaret yoksa etkinleştir
    if (unblockWebViewToo && !g_blockWebView) {
        if (!UnblockWebView()) success = false;
    }
    
    return success;
}

// WebView engelleme fonksiyonu
bool BlockWebView() {
    HKEY hKey;
    LONG result = RegCreateKeyEx(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\msedgewebview2.exe",
        0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL);
    
    if (result != ERROR_SUCCESS) return false;
    
    const wchar_t* value = L"1";
    result = RegSetValueEx(hKey, L"Debugger", 0, REG_SZ, (BYTE*)value, 
        (wcslen(value) + 1) * sizeof(wchar_t));
    
    RegCloseKey(hKey);
    return result == ERROR_SUCCESS;
}

// WebView engeli kaldırma fonksiyonu
bool UnblockWebView() {
    return (RegDeleteKey(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\msedgewebview2.exe")
        == ERROR_SUCCESS);
}

// Parametre yardım mesajı
void ShowParameterHelp(HWND hwnd) {
    const wchar_t* helpText = 
        L"Komut Satırı Parametreleri:\n\n"
        L"/block         : Edge'i engelle\n"
        L"/unblock      : Edge engelini kaldır\n"
        L"/webview      : WebView'ı da engelle (varsayılan)\n"
        L"/nowebview    : WebView'ı engelleme\n"
        L"/status       : Mevcut durumu göster\n\n"
        L"Örnek:\n"
        L"EdgeBlocker.exe /block /webview";
    
    MessageBox(hwnd, helpText, L"Parametre Kullanımı", MB_OK | MB_ICONINFORMATION);
}

// Window Procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CREATE: {
            RECT rcClient;
            GetClientRect(hwnd, &rcClient);
            int clientWidth = rcClient.right - rcClient.left;
            int clientHeight = rcClient.bottom - rcClient.top;
            
            // Button pozisyonlarını üste taşı
            int buttonY = 20; // Menü çubuğunun altından başlat
            int buttonWidth = 300;
            int buttonHeight = 40;
            int buttonX = (clientWidth - buttonWidth) / 2;

            // Modern butonlar - daha ince kenarlar
            DWORD buttonStyle = WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON | BS_FLAT;
            hBlockBtn = CreateWindow(L"BUTTON", L"Microsoft Edge'i Devre Dışı Bırak",
                buttonStyle,
                buttonX, buttonY, buttonWidth, buttonHeight, 
                hwnd, (HMENU)1, hInst, NULL);
            
            hUnblockBtn = CreateWindow(L"BUTTON", L"Microsoft Edge Etkinleştir",
                buttonStyle,
                buttonX, buttonY + buttonHeight + 20, buttonWidth, buttonHeight, 
                hwnd, (HMENU)2, hInst, NULL);

            // Durum göstergesini en alta taşı
            int statusY = clientHeight - 34; // Alt kısımdan 34 piksel yukarıda
            hStatusText = CreateWindow(L"STATIC", L"",
                WS_VISIBLE | WS_CHILD | SS_CENTER | SS_CENTERIMAGE,
                0, statusY, clientWidth, 34,
                hwnd, NULL, hInst, NULL);

            // DPI Farkındalığı
            SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);

            // Menü oluştur
            HMENU hMenu = CreateMenu();
            hWebViewMenu = CreatePopupMenu(); // Global değişkene atandı
            HMENU hAboutMenu = CreatePopupMenu();
            
            AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hWebViewMenu, L"WebView");
            AppendMenu(hWebViewMenu, MF_STRING | (g_blockWebView ? MF_CHECKED : MF_UNCHECKED), 
                ID_WEBVIEW_ENABLE, L"WebView'ı da Engelle");
            
            AppendMenu(hMenu, MF_STRING, ID_PARAMETERS, L"Parametreler");
            
            AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hAboutMenu, L"Hakkında");
            AppendMenu(hAboutMenu, MF_STRING, ID_WEBSITE, L"İnternet Sitesi");
            AppendMenu(hAboutMenu, MF_STRING, ID_GITHUB, L"GitHub");
            AppendMenu(hAboutMenu, MF_STRING, ID_DONATE, L"Bağış Yap");
            
            SetMenu(hwnd, hMenu);

            // Font oluştur
            HFONT hFont = CreateFont(20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                TURKISH_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS,
                CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");

            SendMessage(hBlockBtn, WM_SETFONT, (WPARAM)hFont, TRUE);
            SendMessage(hUnblockBtn, WM_SETFONT, (WPARAM)hFont, TRUE);
            SendMessage(hStatusText, WM_SETFONT, (WPARAM)hFont, TRUE);

            // Buton kenarları için özel tema ayarları
            SetWindowTheme(hBlockBtn, L"Explorer", NULL);  // Explorer teması daha ince kenarlar sağlar
            SetWindowTheme(hUnblockBtn, L"Explorer", NULL);

            // Durum göstergesini güncelle ve renklendir
            UpdateStatusText();

            break;
        }

        case WM_SIZE: {
            // Pencere boyutu değiştiğinde durum göstergesini yeniden konumlandır
            RECT rcClient;
            GetClientRect(hwnd, &rcClient);
            int clientWidth = rcClient.right - rcClient.left;
            int clientHeight = rcClient.bottom - rcClient.top;
            
            SetWindowPos(hStatusText, NULL,
                0, clientHeight - 34,  // Alt kısma yerleştir
                clientWidth, 34,       // Tam genişlik, 34px yükseklik
                SWP_NOZORDER);
            break;
        }

        case WM_CTLCOLORSTATIC: {
            HDC hdcStatic = (HDC)wParam;
            HWND hwndStatic = (HWND)lParam;
            
            if (hwndStatic == hStatusText) {
                bool isBlocked = IsEdgeBlocked();
                // Renkleri biraz daha yumuşattık
                SetBkColor(hdcStatic, isBlocked ? 
                    RGB(255, 82, 82) :  // Daha açık kırmızımsı
                    RGB(22, 196, 127));  // Daha açık yeşilimsi
                SetTextColor(hdcStatic, RGB(0, 0, 0));
                
                static HBRUSH hBrush = NULL;
                if (hBrush) DeleteObject(hBrush);
                hBrush = CreateSolidBrush(isBlocked ? 
                    RGB(255, 82, 82) : 
                    RGB(22, 196, 127));
                return (INT_PTR)hBrush;
            }
            return DefWindowProc(hwnd, msg, wParam, lParam);
        }

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case 1:
                    if (BlockEdge(g_blockWebView)) {
                        UpdateStatusText();
                        std::wstring msg = L"Microsoft Edge başarıyla devre dışı bırakıldı!";
                        if (g_blockWebView) {
                            msg += L"\nWebView da devre dışı bırakıldı!";
                        }
                        MessageBox(hwnd, msg.c_str(), L"Başarılı", MB_OK | MB_ICONINFORMATION);
                    }
                    break;
                case 2: // Unblock Edge butonu
                    if (UnblockEdge(true)) {
                        UpdateStatusText();
                        std::wstring msg = L"Microsoft Edge etkinleştirildi!";
                        if (!g_blockWebView) { // WebView engelleme seçili değilse
                            msg += L"\nWebView de etkinleştirildi!";
                        }
                        MessageBox(hwnd, msg.c_str(), L"Başarılı", MB_OK | MB_ICONINFORMATION);
                    }
                    break;
                case ID_WEBSITE:
                    ShellExecute(NULL, L"open", L"https://shade-cloud.vercel.app", NULL, NULL, SW_SHOW);
                    break;
                case ID_GITHUB:
                    ShellExecute(NULL, L"open", L"https://github.com/shadesofdeath", NULL, NULL, SW_SHOW);
                    break;
                case ID_DONATE:
                    ShellExecute(NULL, L"open", L"https://buymeacoffee.com/berkayay", NULL, NULL, SW_SHOW);
                    break;
                case ID_WEBVIEW_ENABLE:
                    g_blockWebView = !g_blockWebView; // Toggle durumu
                    CheckMenuItem(hWebViewMenu, ID_WEBVIEW_ENABLE, 
                        MF_BYCOMMAND | (g_blockWebView ? MF_CHECKED : MF_UNCHECKED));
                    break;
                case ID_PARAMETERS:
                    ShowParameterHelp(hwnd);
                    break;
            }
            break;

        case WM_DESTROY:
            PostQuitMessage(0);
            break;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

// WinMain fonksiyonunda pencere boyutunu güncelle
int WINAPI wWinMain(
    HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPWSTR lpCmdLine,
    int nShowCmd)
{
    hInst = hInstance;

    // Komut satırı parametrelerini işle
    int argc;
    LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    bool validCommand = false;
    
    if (argc > 1) {
        bool blockRequested = false;
        bool unblockRequested = false;
        bool showStatus = false;
        bool showHelp = false;
        
        for (int i = 1; i < argc; i++) {
            if (_wcsicmp(argv[i], L"/block") == 0) {
                blockRequested = true;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/unblock") == 0) {
                unblockRequested = true;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/webview") == 0) {
                g_blockWebView = true;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/nowebview") == 0) {
                g_blockWebView = false;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/status") == 0) {
                showStatus = true;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/?") == 0 || _wcsicmp(argv[i], L"/help") == 0) {
                showHelp = true;
                validCommand = true;
            }
        }
        
        if (!validCommand) {
            ShowParameterHelp(NULL);
            LocalFree(argv);
            return 1;
        }

        if (showHelp) {
            ShowParameterHelp(NULL);
            LocalFree(argv);
            return 0;
        }
        
        if (showStatus) {
            std::wstring status = L"Edge: ";
            status += IsEdgeBlocked() ? L"Devre Dışı" : L"Etkin";
            status += L"\nWebView: ";
            status += IsWebViewBlocked() ? L"Devre Dışı" : L"Etkin";
            MessageBox(NULL, status.c_str(), L"Durum", MB_OK | MB_ICONINFORMATION); // MB_INFORMATION yerine MB_ICONINFORMATION kullanıldı
            LocalFree(argv);
            return 0;
        }
        
        if (blockRequested) {
            BlockEdge(g_blockWebView);
            LocalFree(argv);
            return 0;
        }
        
        if (unblockRequested) {
            UnblockEdge(g_blockWebView);
            LocalFree(argv);
            return 0;
        }

        LocalFree(argv);
        return 0; // Herhangi bir geçerli komut varsa GUI'yi açma
    }
    
    LocalFree(argv);

    WNDCLASSEX wc = {0};
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszClassName = L"EdgeBlockerClass";
    // İkonu kaynaktan yükle
    wc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(1));
    wc.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(1));

    if (!RegisterClassEx(&wc)) {
        MessageBox(NULL, L"Window Registration Failed!", L"Error", 
            MB_OK | MB_ICONERROR);
        return 0;
    }

    // DPI ölçeklendirme için
    SetProcessDPIAware();

    // Ekran boyutlarını al
    RECT workArea;
    SystemParametersInfo(SPI_GETWORKAREA, 0, &workArea, 0);
    
    // Pencere boyutları
    int windowWidth = 500;
    int windowHeight = 250; // Yüksekliği ayarla

    // Çalışma alanının merkezine konumlandır
    int windowX = workArea.left + (workArea.right - workArea.left - windowWidth) / 2;
    int windowY = workArea.top + (workArea.bottom - workArea.top - windowHeight) / 2;

    HWND hwnd = CreateWindowEx(
        WS_EX_COMPOSITED, // Daha pürüzsüz görünüm
        L"EdgeBlockerClass",
        L"Edge Blocker",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,  // Window style güncellendi
        windowX, windowY,    // Merkez konumu
        windowWidth, windowHeight,
        NULL, NULL, hInstance, NULL);

    if (hwnd == NULL) {
        MessageBox(NULL, L"Window Creation Failed!", L"Error", 
            MB_OK | MB_ICONERROR);
        return 0;
    }

    ShowWindow(hwnd, nShowCmd);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (int)msg.wParam;
}
