#define IDI_ICON 101
#define ID_WEBSITE 201
#define ID_GITHUB 202
#define ID_DONATE 203