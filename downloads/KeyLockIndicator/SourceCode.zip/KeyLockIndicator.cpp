#define UNICODE
#define _UNICODE
#include <windows.h>
#include <string>

// Global değişkenler
HWND g_hwnd = NULL;
HHOOK g_hook = NULL;
HINSTANCE g_hInstance = NULL;
DWORD g_lastKeyTime = 0;     // Son tuş basma zamanı
bool g_isVisible = false;    // Pencere görünürlük durumu
UINT_PTR g_currentTimer = 0; // Aktif timer ID

// Timer ID'leri
const UINT_PTR HIDE_TIMER_ID = 1;

// Pencereyi göster/güncelle
void ShowIndicator(HWND hwnd, const std::wstring& text) 
{


    // Pencere metnini güncelle
    SetWindowText(hwnd, text.c_str());

    // Timer'ı resetle
    if (g_currentTimer != 0) 
    {
        KillTimer(hwnd, g_currentTimer);
    }

    // Pencere görünür değilse göster
    if (!g_isVisible) 
    {
        // Ekranın alt ortasında konumlandır
        RECT workArea;
        SystemParametersInfo(SPI_GETWORKAREA, 0, &workArea, 0);
        
        int dpi = GetDpiForWindow(hwnd);
        int width = MulDiv(160, dpi, 96);
        int height = MulDiv(32, dpi, 96);
        
        int x = (workArea.right - width) / 2;
        int y = workArea.bottom - height - MulDiv(30, dpi, 96);
        
        SetWindowPos(hwnd, HWND_TOPMOST, x, y, width, height, SWP_NOACTIVATE);
        ShowWindow(hwnd, SW_SHOWNOACTIVATE);
        g_isVisible = true;
    }

    // Yeni timer başlat
    g_currentTimer = SetTimer(hwnd, HIDE_TIMER_ID, 2000, NULL);

    // Pencereyi yeniden çiz
    InvalidateRect(hwnd, NULL, TRUE);
    UpdateWindow(hwnd);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_CREATE:
    {
        // DPI farkındalığı
        SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
        
        // Modern pencere stilleri
        SetWindowLong(hwnd, GWL_STYLE, 0);
        SetWindowLong(hwnd, GWL_EXSTYLE, 
            WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_TOPMOST | WS_EX_TRANSPARENT);
        
        // Başlangıç opaklığı
        SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA);
        break;
    }

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        
        RECT rect;
        GetClientRect(hwnd, &rect);
        
        // Double buffering için memory DC
        HDC hdcMem = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, rect.right, rect.bottom);
        HANDLE hOld = SelectObject(hdcMem, hBitmap);

        // Arkaplan
        SetBkMode(hdcMem, TRANSPARENT);
        
        // Font ayarları
        int dpi = GetDpiForWindow(hwnd);
        int fontSize = MulDiv(22, dpi, 96);
        
        HFONT hFont = CreateFontW(fontSize, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
            CLEARTYPE_QUALITY, FF_MODERN, L"Cascadia Code"); 
            
        SelectObject(hdcMem, hFont);
        SetTextColor(hdcMem, RGB(255, 255, 255));

        // Metin çizimi
        TCHAR text[256];
        GetWindowText(hwnd, text, 256);
        DrawText(hdcMem, text, -1, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

        // Double buffer'ı ekrana aktar
        BitBlt(hdc, 0, 0, rect.right, rect.bottom, hdcMem, 0, 0, SRCCOPY);

        // Temizlik
        SelectObject(hdcMem, hOld);
        DeleteObject(hFont);
        DeleteObject(hBitmap);
        DeleteDC(hdcMem);
        
        EndPaint(hwnd, &ps);
        break;
    }

    case WM_TIMER:
        if (wParam == HIDE_TIMER_ID)
        {
            g_isVisible = false;
            ShowWindow(hwnd, SW_HIDE);
            KillTimer(hwnd, HIDE_TIMER_ID);
            g_currentTimer = 0;
        }
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hwnd, message, wParam, lParam);
    }
    return 0;
}

LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode == HC_ACTION)
    {
        KBDLLHOOKSTRUCT* pKbStruct = (KBDLLHOOKSTRUCT*)lParam;

        if (wParam == WM_KEYUP || wParam == WM_SYSKEYUP)
        {
            if (pKbStruct->vkCode == VK_CAPITAL ||
                pKbStruct->vkCode == VK_NUMLOCK ||
                pKbStruct->vkCode == VK_SCROLL)
            {
                std::wstring text;
                bool isOn = false;

                switch (pKbStruct->vkCode)
                {
                case VK_CAPITAL:
                    isOn = (GetKeyState(VK_CAPITAL) & 1) != 0;
                    text = L"CAPS LOCK ";
                    break;
                case VK_NUMLOCK:
                    isOn = (GetKeyState(VK_NUMLOCK) & 1) != 0;
                    text = L"NUM LOCK ";
                    break;
                case VK_SCROLL:
                    isOn = (GetKeyState(VK_SCROLL) & 1) != 0;
                    text = L"SCROLL LOCK ";
                    break;
                }

                text += isOn ? L"ON" : L"OFF";
                ShowIndicator(g_hwnd, text);
            }
        }
    }
    return CallNextHookEx(NULL, nCode, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
                    LPWSTR lpCmdLine, int nCmdShow)
{
    g_hInstance = hInstance;

    // Pencere sınıfı
    WNDCLASSEX wc = {0};
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = L"KeyLockIndicator";
    wc.hbrBackground = NULL;

    if (!RegisterClassEx(&wc))
        return 1;

    // DPI-aware boyutlar
    int dpi = GetDpiForSystem();
    int width = MulDiv(160, dpi, 96);
    int height = MulDiv(36, dpi, 96);

    // Pencere oluştur
    g_hwnd = CreateWindowEx(
        WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | WS_EX_TRANSPARENT,
        L"KeyLockIndicator", L"", WS_POPUP,
        0, 0, width, height,
        NULL, NULL, hInstance, NULL);

    if (!g_hwnd)
        return 1;

    // Klavye hook'u
    g_hook = SetWindowsHookEx(WH_KEYBOARD_LL, LowLevelKeyboardProc, NULL, 0);
    if (!g_hook)
        return 1;

    // Mesaj döngüsü
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    UnhookWindowsHookEx(g_hook);
    return 0;
}