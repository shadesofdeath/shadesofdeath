#ifndef UNICODE
#define UNICODE
#endif

#ifndef _UNICODE
#define _UNICODE
#endif

// DPI farkındalığı için manifest tanımı
#pragma comment(linker,"\"/manifestdependency:type='win32' \
name='Microsoft.Windows.Common-Controls' version='6.0.0.0' \
processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <tchar.h>
#include <dwmapi.h>
#include <unordered_set>
#include <string>

#pragma comment(lib, "dwmapi.lib")

#define WM_APP_TRAYICON (WM_APP + 1)
#define IDM_EXIT       101
#define IDM_TOGGLE     102

// Global variables
HINSTANCE g_hInst = NULL;
HWND g_hwnd = NULL;
bool g_isEnabled = true;
HWND g_lastHoveredWindow = NULL;
HHOOK g_mouseLLHook = NULL;
HHOOK g_keyboardHook = NULL;

// Declarations
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK LowLevelMouseProc(int nCode, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam);

// Pencere geçerli mi kontrolü
BOOL IsValidWindow(HWND hwnd) {
    if (!IsWindow(hwnd) || !IsWindowVisible(hwnd)) return FALSE;

    // Pencere stillerini kontrol et
    LONG style = GetWindowLong(hwnd, GWL_STYLE);
    LONG exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
    
    // Görünmez veya devre dışı pencereleri atla
    if (!(style & WS_VISIBLE) || (style & WS_DISABLED)) return FALSE;
    
    // Tool window'ları atla
    if (exStyle & WS_EX_TOOLWINDOW) return FALSE;
    
    // Başlıksız pencereleri atla
    if (!(style & WS_CAPTION)) return FALSE;

    // UWP/Modern uygulamalar için Cloaked kontrolü
    DWORD cloaked = 0;
    if (SUCCEEDED(DwmGetWindowAttribute(hwnd, DWMWA_CLOAKED, &cloaked, sizeof(cloaked))) && cloaked) 
        return FALSE;

    return TRUE;
}

// Daha kararlı pencere aktivasyonu için helper fonksiyon
BOOL ForceForegroundWindow(HWND hwnd) {
    if (!IsValidWindow(hwnd)) return FALSE;

    HWND currentForeground = GetForegroundWindow();
    if (hwnd == currentForeground) return FALSE;

    // Thread input synchronization
    DWORD currentThreadId = GetCurrentThreadId();
    DWORD foregroundThreadId = GetWindowThreadProcessId(currentForeground, NULL);
    DWORD targetThreadId = GetWindowThreadProcessId(hwnd, NULL);
    
    if (foregroundThreadId != targetThreadId) {
        AttachThreadInput(currentThreadId, foregroundThreadId, TRUE);
        AttachThreadInput(currentThreadId, targetThreadId, TRUE);
    }

    // Pencere durumunu kontrol et ve restore et
    if (IsIconic(hwnd)) {
        ShowWindow(hwnd, SW_RESTORE);
    }

    // En üste getir ve aktif et
    BringWindowToTop(hwnd);
    SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
    SetWindowPos(hwnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);

    // Windows'a pencere değişikliğine izin ver
    AllowSetForegroundWindow(ASFW_ANY);
    BOOL success = SetForegroundWindow(hwnd);

    // Input message gönder
    SendMessage(hwnd, WM_ACTIVATE, WA_ACTIVE, 0);
    SendMessage(hwnd, WM_MOUSEACTIVATE, (WPARAM)hwnd, MAKELPARAM(HTCLIENT, WM_MOUSEMOVE));

    // Thread input bağlantısını kaldır
    if (foregroundThreadId != targetThreadId) {
        AttachThreadInput(currentThreadId, targetThreadId, FALSE);
        AttachThreadInput(currentThreadId, foregroundThreadId, FALSE);
    }

    return success;
}

HWND GetTopLevelWindowAt(POINT pt) {
    // Fare pozisyonundaki en üstteki pencereyi bul
    HWND hwnd = WindowFromPoint(pt);
    if (!hwnd) return NULL;

    // Mouse'un gerçekten o pencerenin üzerinde olup olmadığını kontrol et
    RECT rect;
    if (!GetWindowRect(hwnd, &rect)) return NULL;
    
    if (pt.x < rect.left || pt.x >= rect.right || pt.y < rect.top || pt.y >= rect.top)
        return NULL;

    // Üst seviye pencereyi bul
    HWND rootWindow = GetAncestor(hwnd, GA_ROOT);
    if (!rootWindow || !IsValidWindow(rootWindow)) return NULL;

    return rootWindow;
}

LRESULT CALLBACK LowLevelMouseProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode >= 0 && g_isEnabled) {
        PMSLLHOOKSTRUCT pMouseStruct = (PMSLLHOOKSTRUCT)lParam;
        
        if (wParam == WM_MOUSEMOVE) {
            HWND hwndTarget = WindowFromPoint(pMouseStruct->pt);
            if (hwndTarget) {
                // Üst seviye pencereyi bul
                HWND rootWindow = GetAncestor(hwndTarget, GA_ROOT);
                
                // Pencere geçerli ve önceki pencereden farklı ise
                if (rootWindow && IsValidWindow(rootWindow) && 
                    rootWindow != GetForegroundWindow() && 
                    rootWindow != g_lastHoveredWindow) {
                    
                    // Mouse'un gerçekten pencere içinde olduğunu kontrol et
                    RECT rect;
                    if (GetWindowRect(rootWindow, &rect)) {
                        if (pMouseStruct->pt.x >= rect.left && 
                            pMouseStruct->pt.x < rect.right && 
                            pMouseStruct->pt.y >= rect.top && 
                            pMouseStruct->pt.y < rect.bottom) {
                            
                            g_lastHoveredWindow = rootWindow;
                            ForceForegroundWindow(rootWindow);
                        }
                    }
                }
            }
        }
    }
    return CallNextHookEx(g_mouseLLHook, nCode, wParam, lParam);
}

// Klavye hook'u ile Shift tuşunu izle
LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode >= 0) {
        PKBDLLHOOKSTRUCT p = (PKBDLLHOOKSTRUCT)lParam;
        if (p->vkCode == VK_SHIFT) {
            if (wParam == WM_KEYDOWN) {
                g_isEnabled = false;
            } else if (wParam == WM_KEYUP) {
                g_isEnabled = true;
            }
        }
    }
    return CallNextHookEx(g_keyboardHook, nCode, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, LPWSTR, int) {
    // DPI farkındalığını etkinleştir
    SetProcessDPIAware();
    
    g_hInst = hInstance;
    
    WNDCLASSEXW wc = {0};
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = L"AutoFocusWindowClass";
    
    if (!RegisterClassExW(&wc)) return 1;
    
    // Gizli pencere oluştur
    g_hwnd = CreateWindowExW(0, L"AutoFocusWindowClass", L"AutoFocusWindow",
        0, 0, 0, 0, 0, HWND_MESSAGE, NULL, hInstance, NULL);
    
    if (!g_hwnd) return 1;

    // Hook'ları kur
    g_mouseLLHook = SetWindowsHookEx(WH_MOUSE_LL, LowLevelMouseProc, GetModuleHandle(NULL), 0);
    g_keyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, LowLevelKeyboardProc, GetModuleHandle(NULL), 0);

    if (!g_mouseLLHook || !g_keyboardHook) {
        MessageBoxW(NULL, L"Hook kurulumu başarısız!", L"Hata", MB_ICONERROR);
        return 1;
    }

    MSG msg = {0};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // Cleanup
    if (g_mouseLLHook) UnhookWindowsHookEx(g_mouseLLHook);
    if (g_keyboardHook) UnhookWindowsHookEx(g_keyboardHook);
    
    return 0;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_DESTROY:
            if (g_mouseLLHook) {
                UnhookWindowsHookEx(g_mouseLLHook);
                g_mouseLLHook = NULL;
            }
            if (g_keyboardHook) {
                UnhookWindowsHookEx(g_keyboardHook);
                g_keyboardHook = NULL;
            }
            PostQuitMessage(0);
            break;

        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
    return 0;
}