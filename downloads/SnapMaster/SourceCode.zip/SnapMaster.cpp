#ifndef UNICODE
#define UNICODE
#endif

#ifndef _UNICODE
#define _UNICODE
#endif

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <objidl.h>
#include <windowsx.h>
#include <gdiplus.h>
#include <dwmapi.h>
#include <shellapi.h>
#include <shlobj.h>
#include <memory>
#include <vector>
#include <string>
#include <winhttp.h>

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")

#pragma comment(linker, "\"/manifestdependency:type='win32' \
name='Microsoft.Windows.Common-Controls' version='6.0.0.0' \
processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

// Global değişkenler
HWND g_hwnd = NULL;
NOTIFYICONDATAW g_nid = {};
HMENU g_popup_menu = NULL;
HWND g_highlightedWindow = NULL;
HWND g_lastHighlightedWindow = NULL;
bool g_isSelecting = false;
bool g_uploadMode = false;
HHOOK g_mouseHook = NULL;
HICON g_hIcon = NULL;
HICON g_hIconSmall = NULL;
UINT_PTR g_delayTimer = 0;
RECT g_lastDrawnRect = {0};
bool g_hasLastRect = false;
POINT g_startPoint = {0};
POINT g_endPoint = {0};
bool g_isDrawing = false;
RECT g_selectionRect = {0};
bool g_isAreaSelection = false;
HWND g_overlayWindow = NULL;
HFONT g_hFont = NULL;
HBRUSH g_hBackgroundBrush = NULL;
bool g_selectionFinished = false;
bool g_isEditing = false;
POINT g_lastMousePos = {0};
int g_resizeHandle = 0;
bool g_isDragging = false;
POINT g_dragOffset = {0};

#define WM_TRAYICON (WM_USER + 1)
#define CAPTURE_DELAY_TIMER 1
#define CAPTURE_DELAY_MS 500
#define ID_AREA_SELECTION 3
#define BUFFER_SIZE 4096
#define UPLOAD_HOST L"0x0.st"
#define UPLOAD_PATH L"/"
#define ID_WEBSITE 2001

const wchar_t *OVERLAY_CLASS_NAME = L"SnapMasterOverlay";

int GetEncoderClsid(const WCHAR *format, CLSID *pClsid)
{
    UINT num = 0;
    UINT size = 0;
    Gdiplus::GetImageEncodersSize(&num, &size);
    if (size == 0)
        return -1;

    std::unique_ptr<Gdiplus::ImageCodecInfo[]> pImageCodecInfo(new Gdiplus::ImageCodecInfo[size]);
    Gdiplus::GetImageEncoders(num, size, pImageCodecInfo.get());

    for (UINT j = 0; j < num; ++j)
    {
        if (wcscmp(pImageCodecInfo[j].MimeType, format) == 0)
        {
            *pClsid = pImageCodecInfo[j].Clsid;
            return j;
        }
    }
    return -1;
}

std::wstring UploadScreenshot(const wchar_t *filePath)
{
    std::wstring result;

    // Dosyayı aç
    HANDLE hFile = CreateFileW(filePath, GENERIC_READ, FILE_SHARE_READ, NULL,
                               OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE)
        return result;

    // WinHTTP session başlat
    HINTERNET hSession = WinHttpOpen(L"SnapMaster/1.0",
                                     WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
                                     WINHTTP_NO_PROXY_NAME,
                                     WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession)
    {
        CloseHandle(hFile);
        return result;
    }

    // HTTPS bağlantısı için portu ayarla
    INTERNET_PORT port = INTERNET_DEFAULT_HTTPS_PORT;

    // Sunucuya bağlan
    HINTERNET hConnect = WinHttpConnect(hSession, L"0x0.st", port, 0);
    if (!hConnect)
    {
        WinHttpCloseHandle(hSession);
        CloseHandle(hFile);
        return result;
    }

    // HTTP isteği oluştur
    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"POST", L"/",
                                            L"HTTP/1.1", WINHTTP_NO_REFERER,
                                            WINHTTP_DEFAULT_ACCEPT_TYPES,
                                            WINHTTP_FLAG_SECURE);
    if (!hRequest)
    {
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        CloseHandle(hFile);
        return result;
    }

    // TLS 1.2 ve 1.3'ü etkinleştir
    DWORD dwFlags = WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_2 | WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_3;
    WinHttpSetOption(hRequest, WINHTTP_OPTION_SECURE_PROTOCOLS, &dwFlags, sizeof(dwFlags));

    // Multipart form verisi oluştur
    std::string boundary = "----SnapMasterBoundary";
    std::string header = "Content-Type: multipart/form-data; boundary=" + boundary;

    // Header'ı ekle
    if (!WinHttpAddRequestHeaders(hRequest,
                                  std::wstring(header.begin(), header.end()).c_str(),
                                  static_cast<DWORD>(-1), WINHTTP_ADDREQ_FLAG_ADD | WINHTTP_ADDREQ_FLAG_REPLACE))
    {
        WinHttpCloseHandle(hRequest);
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        CloseHandle(hFile);
        return result;
    }

    std::string formStart = "--" + boundary + "\r\n"
                                              "Content-Disposition: form-data; name=\"file\"; filename=\"screenshot.png\"\r\n"
                                              "Content-Type: image/png\r\n\r\n";
    std::string formEnd = "\r\n--" + boundary + "--\r\n";

    // Dosya boyutunu al
    DWORD fileSize = GetFileSize(hFile, NULL);
    if (fileSize == INVALID_FILE_SIZE)
    {
        WinHttpCloseHandle(hRequest);
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        CloseHandle(hFile);
        return result;
    }

    // Toplam boyut hesapla
    DWORD totalSize = static_cast<DWORD>(formStart.length() + fileSize + formEnd.length());

    // İstek gönder
    if (!WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                            NULL, 0, totalSize, 0))
    {
        WinHttpCloseHandle(hRequest);
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        CloseHandle(hFile);
        return result;
    }

    // Form başlangıcını yaz
    DWORD written;
    WinHttpWriteData(hRequest, formStart.c_str(),
                     static_cast<DWORD>(formStart.length()), &written);

    // Dosya içeriğini yaz
    std::vector<BYTE> buffer(BUFFER_SIZE);
    DWORD bytesRead;
    do
    {
        if (!ReadFile(hFile, buffer.data(), BUFFER_SIZE, &bytesRead, NULL))
            break;
        if (bytesRead > 0)
        {
            WinHttpWriteData(hRequest, buffer.data(), bytesRead, &written);
        }
    } while (bytesRead > 0);

    // Form sonunu yaz
    WinHttpWriteData(hRequest, formEnd.c_str(),
                     static_cast<DWORD>(formEnd.length()), &written);

    // Yanıtı al
    if (WinHttpReceiveResponse(hRequest, NULL))
    {
        std::string response;
        DWORD bytesAvailable;
        do
        {
            bytesAvailable = 0;
            if (!WinHttpQueryDataAvailable(hRequest, &bytesAvailable))
                break;

            if (bytesAvailable > 0)
            {
                std::vector<char> responseBuffer(bytesAvailable + 1);
                DWORD responseBytesRead = 0;
                if (WinHttpReadData(hRequest, responseBuffer.data(),
                                    bytesAvailable, &responseBytesRead))
                {
                    responseBuffer[responseBytesRead] = 0;
                    response += responseBuffer.data();
                }
            }
        } while (bytesAvailable > 0);

        // Yanıtı işle
        if (!response.empty())
        {
            // Boşlukları ve satır sonlarını temizle
            response.erase(std::remove_if(response.begin(), response.end(),
                                          [](char c)
                                          { return c == '\r' || c == '\n' || c == ' '; }),
                           response.end());

            if (response.find("http") == 0)
            {
                result = std::wstring(response.begin(), response.end());

                // URL'i panoya kopyala
                if (OpenClipboard(NULL))
                {
                    EmptyClipboard();
                    size_t len = (response.length() + 1) * sizeof(wchar_t);
                    HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, len);
                    if (hMem)
                    {
                        wchar_t *data = (wchar_t *)GlobalLock(hMem);
                        if (data)
                        {
                            size_t converted;
                            mbstowcs_s(&converted, data, response.length() + 1,
                                       response.c_str(), response.length());
                            GlobalUnlock(hMem);
                            SetClipboardData(CF_UNICODETEXT, hMem);
                        }
                    }
                    CloseClipboard();
                }
            }
        }
    }

    // Kaynakları temizle
    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);
    CloseHandle(hFile);

    return result;
}

void SaveScreenshot(HBITMAP hBitmap)
{
    WCHAR path[MAX_PATH];
    SYSTEMTIME st;
    GetLocalTime(&st);

    if (SUCCEEDED(SHGetFolderPathW(NULL, CSIDL_MYPICTURES, NULL, 0, path)))
    {
        WCHAR fileName[MAX_PATH];
        swprintf_s(fileName, L"%s\\Screenshot_%04d%02d%02d_%02d%02d%02d.png",
                   path, st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);

        Gdiplus::Bitmap bitmap(hBitmap, NULL);
        bitmap.SetResolution(300, 300);

        CLSID pngClsid;
        if (GetEncoderClsid(L"image/png", &pngClsid) != -1)
        {
            Gdiplus::EncoderParameters encoderParams;
            encoderParams.Count = 1;
            encoderParams.Parameter[0].Guid = Gdiplus::EncoderQuality;
            encoderParams.Parameter[0].Type = Gdiplus::EncoderParameterValueTypeLong;
            encoderParams.Parameter[0].NumberOfValues = 1;
            ULONG quality = 100L;
            encoderParams.Parameter[0].Value = &quality;

            bitmap.Save(fileName, &pngClsid, &encoderParams);

            NOTIFYICONDATAW nid = g_nid;

            if (g_uploadMode)
            {
                // Upload işlemi
                std::wstring uploadUrl = UploadScreenshot(fileName);

                if (!uploadUrl.empty())
                {
                    wcscpy_s(nid.szInfo, L"Ekran görüntüsü kaydedildi ve yüklendi\nURL panoya kopyalandı");
                }
                else
                {
                    wcscpy_s(nid.szInfo, L"Ekran görüntüsü kaydedildi\nYükleme başarısız oldu");
                }
                g_uploadMode = false; // Upload modunu sıfırla
            }
            else
            {
                wcscpy_s(nid.szInfo, L"Ekran görüntüsü kaydedildi");
            }

            wcscpy_s(nid.szInfoTitle, L"SnapMaster");
            nid.uFlags |= NIF_INFO;
            nid.dwInfoFlags = NIIF_INFO;
            Shell_NotifyIconW(NIM_MODIFY, &nid);
        }
    }
}

// Helper fonksiyonlar
void CaptureWindow(HWND hwnd)
{
    if (!hwnd || !IsWindow(hwnd))
        return;

    // Pencereyi yüksek öncelikli yap ki üstündekiler alınmasın
    DWORD foreThread = GetWindowThreadProcessId(GetForegroundWindow(), NULL);
    DWORD thisThread = GetCurrentThreadId();
    AttachThreadInput(thisThread, foreThread, TRUE);

    // Pencere pozisyonunu ve boyutunu al
    RECT windowRect, clientRect;
    GetWindowRect(hwnd, &windowRect);
    GetClientRect(hwnd, &clientRect);
    
    // DPI-aware pencere sınırları
    RECT frameRect;
    DwmGetWindowAttribute(hwnd, DWMWA_EXTENDED_FRAME_BOUNDS, &frameRect, sizeof(RECT));

    // Tam pencere boyutları
    int width = frameRect.right - frameRect.left;
    int height = frameRect.bottom - frameRect.top;

    // Print Window kullanarak pencereyi yakala
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);

    BITMAPINFO bmi = {0};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = width;
    bmi.bmiHeader.biHeight = -height;  // Top-down DIB
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    void *pBits = nullptr;
    HBITMAP hBitmap = CreateDIBSection(hdcMem, &bmi, DIB_RGB_COLORS, &pBits, NULL, 0);
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hdcMem, hBitmap);

    // PrintWindow kullan - bu tüm pencereyi alır
    if (!PrintWindow(hwnd, hdcMem, PW_RENDERFULLCONTENT))
    {
        // PrintWindow başarısız olursa BitBlt'yi dene
        BitBlt(hdcMem, 0, 0, width, height, hdcScreen, frameRect.left, frameRect.top, SRCCOPY | CAPTUREBLT);
    }

    // Pencereyi normal hale getir
    SetWindowPos(hwnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    AttachThreadInput(thisThread, foreThread, FALSE);

    SaveScreenshot(hBitmap);

    SelectObject(hdcMem, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
}

BOOL ForceForegroundWindow(HWND hwnd)
{
    if (!IsWindow(hwnd))
        return FALSE;
    SetForegroundWindow(hwnd);
    return TRUE;
}

void RemoveHighlight()
{
    if (g_lastHighlightedWindow)
    {
        InvalidateRect(NULL, NULL, TRUE);
        UpdateWindow(g_lastHighlightedWindow);
        g_lastHighlightedWindow = NULL;
    }
}
void DrawWindowBorder(HWND hwnd, bool clearOnly = false)
{
    static HWND lastHighlightedWindow = NULL;
    static HDC hdcScreen = NULL;
    
    // Screen DC'yi bir kere al ve sakla
    if (!hdcScreen) 
    {
        hdcScreen = GetDC(NULL);
        if (!hdcScreen) return;
    }

    // XOR çizim modu - otomatik eski çizimi siler
    SetROP2(hdcScreen, R2_NOTXORPEN);
    
    // Kalem ayarları - sadece bir kere oluştur
    static HPEN hPen = CreatePen(PS_SOLID, 2, RGB(255, 0, 0));
    static HBRUSH hEmptyBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
    
    if (!hPen) return;

    // Önceki çizimi temizleme
    if (g_hasLastRect)
    {
        SelectObject(hdcScreen, hPen);
        SelectObject(hdcScreen, hEmptyBrush);
        Rectangle(hdcScreen, g_lastDrawnRect.left, g_lastDrawnRect.top,
                 g_lastDrawnRect.right, g_lastDrawnRect.bottom);
        g_hasLastRect = false;
    }

    // Sadece temizlik isteniyorsa veya pencere geçersizse çık
    if (clearOnly || !hwnd || !IsWindow(hwnd))
    {
        if (hdcScreen) 
        {
            ReleaseDC(NULL, hdcScreen);
            hdcScreen = NULL;
        }
        if (hPen) DeleteObject(hPen);
        return;
    }

    // Yeni pencere farklıysa çiz
    if (hwnd != lastHighlightedWindow)
    {
        RECT rc;
        if (SUCCEEDED(DwmGetWindowAttribute(hwnd, DWMWA_EXTENDED_FRAME_BOUNDS, &rc, sizeof(RECT))))
        {
            SelectObject(hdcScreen, hPen);
            SelectObject(hdcScreen, hEmptyBrush);
            Rectangle(hdcScreen, rc.left, rc.top, rc.right, rc.bottom);
            g_lastDrawnRect = rc;
            g_hasLastRect = true;
            lastHighlightedWindow = hwnd;
        }
    }
}

void CaptureSelectedArea()
{
    ShowWindow(g_overlayWindow, SW_HIDE); // Overlay'i gizle
    Sleep(100);
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);

    int width = g_selectionRect.right - g_selectionRect.left;
    int height = g_selectionRect.bottom - g_selectionRect.top;

    BITMAPINFO bmi = {0};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = width;
    bmi.bmiHeader.biHeight = -height;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    void *pBits = nullptr;
    HBITMAP hBitmap = CreateDIBSection(hdcMem, &bmi, DIB_RGB_COLORS, &pBits, NULL, 0);
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hdcMem, hBitmap);

    BitBlt(hdcMem, 0, 0, width, height, hdcScreen,
           g_selectionRect.left, g_selectionRect.top, SRCCOPY);

    SaveScreenshot(hBitmap);

    SelectObject(hdcMem, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
}

void CaptureFullScreenDelayed()
{
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);

    int width = GetSystemMetrics(SM_CXVIRTUALSCREEN);
    int height = GetSystemMetrics(SM_CYVIRTUALSCREEN);
    int left = GetSystemMetrics(SM_XVIRTUALSCREEN);
    int top = GetSystemMetrics(SM_YVIRTUALSCREEN);

    BITMAPINFO bmi = {0};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = width;
    bmi.bmiHeader.biHeight = -height;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    void *pBits = nullptr;
    HBITMAP hBitmap = CreateDIBSection(hdcMem, &bmi, DIB_RGB_COLORS, &pBits, NULL, 0);
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hdcMem, hBitmap);

    SetStretchBltMode(hdcMem, HALFTONE);
    SetBrushOrgEx(hdcMem, 0, 0, NULL);

    BitBlt(hdcMem, 0, 0, width, height, hdcScreen, left, top, CAPTUREBLT | SRCCOPY);

    SaveScreenshot(hBitmap);

    SelectObject(hdcMem, hOldBitmap);
    DeleteObject(hBitmap);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
}
void DrawResizeHandles(HDC hdc, const RECT &rect)
{
    const int handleSize = 8;
    const COLORREF handleColor = RGB(0, 120, 215);
    HBRUSH hBrush = CreateSolidBrush(handleColor);

    // Köşe tutamaçları
    RECT handleRect;

    // Sol üst
    handleRect = {rect.left - handleSize, rect.top - handleSize,
                  rect.left + handleSize, rect.top + handleSize};
    FillRect(hdc, &handleRect, hBrush);

    // Sağ üst
    handleRect = {rect.right - handleSize, rect.top - handleSize,
                  rect.right + handleSize, rect.top + handleSize};
    FillRect(hdc, &handleRect, hBrush);

    // Sol alt
    handleRect = {rect.left - handleSize, rect.bottom - handleSize,
                  rect.left + handleSize, rect.bottom + handleSize};
    FillRect(hdc, &handleRect, hBrush);

    // Sağ alt
    handleRect = {rect.right - handleSize, rect.bottom - handleSize,
                  rect.right + handleSize, rect.bottom + handleSize};
    FillRect(hdc, &handleRect, hBrush);

    DeleteObject(hBrush);
}

// Mouse'un hangi tutamacın üzerinde olduğunu kontrol etmek için
int HitTestResizeHandle(POINT pt)
{
    const int handleSize = 8; // Tutamaç boyutunu biraz büyüttük
    RECT rect = g_selectionRect;

    // Köşeler
    if (pt.x >= rect.left - handleSize && pt.x <= rect.left + handleSize)
    {
        if (pt.y >= rect.top - handleSize && pt.y <= rect.top + handleSize)
            return 1; // Sol üst
        if (pt.y >= rect.bottom - handleSize && pt.y <= rect.bottom + handleSize)
            return 3; // Sol alt
    }
    if (pt.x >= rect.right - handleSize && pt.x <= rect.right + handleSize)
    {
        if (pt.y >= rect.top - handleSize && pt.y <= rect.top + handleSize)
            return 2; // Sağ üst
        if (pt.y >= rect.bottom - handleSize && pt.y <= rect.bottom + handleSize)
            return 4; // Sağ alt
    }

    // Kenarlar
    if (pt.x >= (rect.left + rect.right) / 2 - handleSize &&
        pt.x <= (rect.left + rect.right) / 2 + handleSize)
    {
        if (pt.y >= rect.top - handleSize && pt.y <= rect.top + handleSize)
            return 5; // Üst orta
        if (pt.y >= rect.bottom - handleSize && pt.y <= rect.bottom + handleSize)
            return 6; // Alt orta
    }
    if (pt.y >= (rect.top + rect.bottom) / 2 - handleSize &&
        pt.y <= (rect.top + rect.bottom) / 2 + handleSize)
    {
        if (pt.x >= rect.left - handleSize && pt.x <= rect.left + handleSize)
            return 7; // Sol orta
        if (pt.x >= rect.right - handleSize && pt.x <= rect.right + handleSize)
            return 8; // Sağ orta
    }

    return 0;
}

// Seçimi yeniden boyutlandırmak için
void ResizeSelection(POINT currentPt)
{
    int dx = currentPt.x - g_lastMousePos.x;
    int dy = currentPt.y - g_lastMousePos.y;

    switch (g_resizeHandle)
    {
    case 1: // Sol üst
        g_selectionRect.left += dx;
        g_selectionRect.top += dy;
        break;
    case 2: // Sağ üst
        g_selectionRect.right += dx;
        g_selectionRect.top += dy;
        break;
    case 3: // Sol alt
        g_selectionRect.left += dx;
        g_selectionRect.bottom += dy;
        break;
    case 4: // Sağ alt
        g_selectionRect.right += dx;
        g_selectionRect.bottom += dy;
        break;
    case 5: // Üst orta
        g_selectionRect.top += dy;
        break;
    case 6: // Alt orta
        g_selectionRect.bottom += dy;
        break;
    case 7: // Sol orta
        g_selectionRect.left += dx;
        break;
    case 8: // Sağ orta
        g_selectionRect.right += dx;
        break;
    }

    // Minimum boyut kontrolü
    const int MIN_SIZE = 10;
    if (g_selectionRect.right - g_selectionRect.left < MIN_SIZE)
    {
        if (dx > 0)
            g_selectionRect.right = g_selectionRect.left + MIN_SIZE;
        else
            g_selectionRect.left = g_selectionRect.right - MIN_SIZE;
    }
    if (g_selectionRect.bottom - g_selectionRect.top < MIN_SIZE)
    {
        if (dy > 0)
            g_selectionRect.bottom = g_selectionRect.top + MIN_SIZE;
        else
            g_selectionRect.top = g_selectionRect.bottom - MIN_SIZE;
    }

    // Seçim noktalarını güncelle
    g_startPoint.x = g_selectionRect.left;
    g_startPoint.y = g_selectionRect.top;
    g_endPoint.x = g_selectionRect.right;
    g_endPoint.y = g_selectionRect.bottom;
}
BOOL IsValidWindow(HWND hwnd)
{
    // Temel pencere geçerlilik kontrolü
    if (!IsWindow(hwnd) || !IsWindowVisible(hwnd))
        return FALSE;

    // Stil kontrolü - sadece görünür olup olmadığını kontrol et
    LONG style = GetWindowLong(hwnd, GWL_STYLE);
    if (!(style & WS_VISIBLE))
        return FALSE;

    return TRUE;
}


LPCWSTR GetResizeCursor(int handle)
{
    switch (handle)
    {
    case 1:
    case 4: // Sol üst ve sağ alt
        return IDC_SIZENWSE;
    case 2:
    case 3: // Sağ üst ve sol alt
        return IDC_SIZENESW;
    case 5:
    case 6: // Üst ve alt orta
        return IDC_SIZENS;
    case 7:
    case 8: // Sol ve sağ orta
        return IDC_SIZEWE;
    default:
        return IDC_CROSS;
    }
}

LRESULT CALLBACK MouseHookProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode >= 0 && g_isSelecting)
    {
        MSLLHOOKSTRUCT *hookStruct = (MSLLHOOKSTRUCT *)lParam;
        POINT pt = hookStruct->pt;

        if (wParam == WM_MOUSEMOVE)
        {
            HWND hwndUnderCursor = WindowFromPoint(pt);
            HWND rootHwnd = GetAncestor(hwndUnderCursor, GA_ROOT);
            if (!rootHwnd) rootHwnd = hwndUnderCursor;

            // Sadece geçerli pencere ise ve öncekinden farklıysa
            if (IsValidWindow(rootHwnd) && rootHwnd != g_highlightedWindow)
            {
                g_highlightedWindow = rootHwnd;
                DrawWindowBorder(rootHwnd);
            }
        }
        else if (wParam == WM_LBUTTONDOWN && g_highlightedWindow)
        {
            HWND selectedWindow = g_highlightedWindow;
            g_isSelecting = false;
            UnhookWindowsHookEx(g_mouseHook);
            g_mouseHook = NULL;

            DrawWindowBorder(NULL, true);
            Sleep(50);
            CaptureWindow(selectedWindow);
            return 1;
        }
        else if (wParam == WM_RBUTTONDOWN)
        {
            g_isSelecting = false;
            UnhookWindowsHookEx(g_mouseHook);
            g_mouseHook = NULL;
            DrawWindowBorder(NULL, true);
            return 1;
        }
    }
    return CallNextHookEx(NULL, nCode, wParam, lParam);
}

// Overlay pencere prosedürü
LRESULT CALLBACK OverlayWindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    static HDC hdcBuffer = NULL;
    static HBITMAP hbmBuffer = NULL;
    static int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    static int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    switch (uMsg)
    {
    case WM_CREATE:
    {
        // Yarı saydam arka plan için layered pencere ayarları
        SetLayeredWindowAttributes(hwnd, 0, 128, LWA_ALPHA);

        HDC hdc = GetDC(hwnd);
        hdcBuffer = CreateCompatibleDC(hdc);
        hbmBuffer = CreateCompatibleBitmap(hdc, screenWidth, screenHeight);
        SelectObject(hdcBuffer, hbmBuffer);
        ReleaseDC(hwnd, hdc);

        g_hBackgroundBrush = CreateSolidBrush(RGB(0, 0, 0)); // Siyah arka plan
        g_hFont = CreateFontW(22, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                              DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                              CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
                              L"Segoe UI");
        return 0;
    }

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);

        RECT clientRect;
        GetClientRect(hwnd, &clientRect);

        // Tampon DC'yi temizle
        FillRect(hdcBuffer, &clientRect, g_hBackgroundBrush);

        if (g_isDrawing || g_selectionFinished)
        {
            // Seçim alanını hesapla
            RECT selectionRect = {
                min(g_startPoint.x, g_endPoint.x),
                min(g_startPoint.y, g_endPoint.y),
                max(g_startPoint.x, g_endPoint.x),
                max(g_startPoint.y, g_endPoint.y)};

            // Seçili alan dışındaki bölgeleri karart
            HBRUSH hDarkBrush = CreateSolidBrush(RGB(0, 0, 0));
            RECT darkRects[] = {
                {0, 0, screenWidth, selectionRect.top},
                {0, selectionRect.top, selectionRect.left, selectionRect.bottom},
                {selectionRect.right, selectionRect.top, screenWidth, selectionRect.bottom},
                {0, selectionRect.bottom, screenWidth, screenHeight}};

            for (const auto &rect : darkRects)
            {
                FillRect(hdcBuffer, &rect, hDarkBrush);
            }
            DeleteObject(hDarkBrush);

            // Seçili alanın kenarlıklarını çiz
            HPEN hPen = CreatePen(PS_SOLID, 2, RGB(0, 120, 215)); // Mavi kenarlık
            HPEN hOldPen = (HPEN)SelectObject(hdcBuffer, hPen);
            HBRUSH hOldBrush = (HBRUSH)SelectObject(hdcBuffer, GetStockObject(NULL_BRUSH));

            Rectangle(hdcBuffer, selectionRect.left, selectionRect.top,
                      selectionRect.right, selectionRect.bottom);

            SelectObject(hdcBuffer, hOldPen);
            SelectObject(hdcBuffer, hOldBrush);
            DeleteObject(hPen);

            // Boyut bilgisini göster
            int width = selectionRect.right - selectionRect.left;
            int height = selectionRect.bottom - selectionRect.top;
            wchar_t sizeText[64];

            if (g_selectionFinished)
            {
                swprintf_s(sizeText, L"%dx%d - Enter: Kaydet, ESC: İptal", width, height);
            }
            else
            {
                swprintf_s(sizeText, L"%dx%d", width, height);
            }

            SetBkMode(hdcBuffer, TRANSPARENT);
            SetTextColor(hdcBuffer, RGB(255, 255, 255)); // Beyaz metin
            SelectObject(hdcBuffer, g_hFont);

            // Boyut metnini konumlandır
            RECT textRect = selectionRect;
            textRect.bottom = textRect.top - 5;
            textRect.top = textRect.bottom - 25;

            // Metin ekran dışında kalıyorsa konumunu ayarla
            if (textRect.top < 0)
            {
                textRect.top = selectionRect.bottom + 5;
                textRect.bottom = textRect.top + 25;
            }

            DrawTextW(hdcBuffer, sizeText, -1, &textRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

            // Seçim tamamlandığında tutamaçları çiz
            if (g_selectionFinished)
            {
                DrawResizeHandles(hdcBuffer, selectionRect);
            }
        }

        // Çift tamponlu çizimi ekrana aktar
        BitBlt(hdc, 0, 0, screenWidth, screenHeight, hdcBuffer, 0, 0, SRCCOPY);
        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_LBUTTONDOWN:
    {
        POINT pt;
        pt.x = GET_X_LPARAM(lParam);
        pt.y = GET_Y_LPARAM(lParam);

        if (g_selectionFinished)
        {
            // Tutamaçları kontrol et
            g_resizeHandle = HitTestResizeHandle(pt);
            if (g_resizeHandle != 0)
            {
                g_isEditing = true;
            }
            // Seçim alanı içinde mi kontrol et
            else if (pt.x >= g_selectionRect.left && pt.x <= g_selectionRect.right &&
                     pt.y >= g_selectionRect.top && pt.y <= g_selectionRect.bottom)
            {
                g_isDragging = true;
                g_dragOffset.x = pt.x - g_selectionRect.left;
                g_dragOffset.y = pt.y - g_selectionRect.top;
            }
            else
            {
                // Yeni seçim başlat
                g_selectionFinished = false;
                g_isDrawing = true;
                g_startPoint = g_endPoint = pt;
            }
        }
        else
        {
            g_isDrawing = true;
            g_startPoint = g_endPoint = pt;
        }

        g_lastMousePos = pt;
        SetCapture(hwnd);
        InvalidateRect(hwnd, NULL, TRUE);
        return 0;
    }

    case WM_MOUSEMOVE:
    {
        if (!(wParam & MK_LBUTTON))
        {
            if (g_selectionFinished)
            {
                // Mouse imlecini güncelle
                POINT pt;
                pt.x = GET_X_LPARAM(lParam);
                pt.y = GET_Y_LPARAM(lParam);

                int handle = HitTestResizeHandle(pt);
                if (handle != 0)
                {
                    SetCursor(LoadCursor(NULL, GetResizeCursor(handle)));
                }
                else if (pt.x >= g_selectionRect.left && pt.x <= g_selectionRect.right &&
                         pt.y >= g_selectionRect.top && pt.y <= g_selectionRect.bottom)
                {
                    SetCursor(LoadCursor(NULL, IDC_SIZEALL));
                }
                else
                {
                    SetCursor(LoadCursor(NULL, IDC_CROSS));
                }
            }
            break;
        }

        POINT pt;
        pt.x = GET_X_LPARAM(lParam);
        pt.y = GET_Y_LPARAM(lParam);

        if (g_isDrawing)
        {
            g_endPoint = pt;
        }
        else if (g_isEditing && g_resizeHandle != 0)
        {
            ResizeSelection(pt);
            g_lastMousePos = pt;
        }
        else if (g_isDragging)
        {
            // Seçim alanını taşı
            int width = g_selectionRect.right - g_selectionRect.left;
            int height = g_selectionRect.bottom - g_selectionRect.top;

            g_selectionRect.left = pt.x - g_dragOffset.x;
            g_selectionRect.top = pt.y - g_dragOffset.y;
            g_selectionRect.right = g_selectionRect.left + width;
            g_selectionRect.bottom = g_selectionRect.top + height;

            // Ekran sınırlarını kontrol et
            if (g_selectionRect.left < 0)
            {
                g_selectionRect.left = 0;
                g_selectionRect.right = width;
            }
            if (g_selectionRect.top < 0)
            {
                g_selectionRect.top = 0;
                g_selectionRect.bottom = height;
            }
            if (g_selectionRect.right > screenWidth)
            {
                g_selectionRect.right = screenWidth;
                g_selectionRect.left = screenWidth - width;
            }
            if (g_selectionRect.bottom > screenHeight)
            {
                g_selectionRect.bottom = screenHeight;
                g_selectionRect.top = screenHeight - height;
            }

            // Start ve end noktalarını güncelle
            g_startPoint.x = g_selectionRect.left;
            g_startPoint.y = g_selectionRect.top;
            g_endPoint.x = g_selectionRect.right;
            g_endPoint.y = g_selectionRect.bottom;
        }

        InvalidateRect(hwnd, NULL, TRUE);
        return 0;
    }

    case WM_LBUTTONUP:
    {
        if (g_isDrawing)
        {
            g_isDrawing = false;
            g_selectionFinished = true;

            // Seçim koordinatlarını düzenle
            g_selectionRect.left = min(g_startPoint.x, g_endPoint.x);
            g_selectionRect.top = min(g_startPoint.y, g_endPoint.y);
            g_selectionRect.right = max(g_startPoint.x, g_endPoint.x);
            g_selectionRect.bottom = max(g_startPoint.y, g_endPoint.y);

            // Minimum boyut kontrolü
            const int MIN_SIZE = 10;
            if (g_selectionRect.right - g_selectionRect.left < MIN_SIZE)
            {
                g_selectionRect.right = g_selectionRect.left + MIN_SIZE;
                g_endPoint.x = g_selectionRect.right;
            }
            if (g_selectionRect.bottom - g_selectionRect.top < MIN_SIZE)
            {
                g_selectionRect.bottom = g_selectionRect.top + MIN_SIZE;
                g_endPoint.y = g_selectionRect.bottom;
            }

            // Seçim noktalarını güncelle
            g_startPoint.x = g_selectionRect.left;
            g_startPoint.y = g_selectionRect.top;
            g_endPoint.x = g_selectionRect.right;
            g_endPoint.y = g_selectionRect.bottom;
        }

        g_isEditing = false;
        g_isDragging = false;
        g_resizeHandle = 0;
        ReleaseCapture();
        InvalidateRect(hwnd, NULL, TRUE);
        return 0;
    }

    case WM_KEYDOWN:
    {
        switch (wParam)
        {
        case VK_ESCAPE:
            DestroyWindow(hwnd);
            break;

        case VK_RETURN:
            if (g_selectionFinished)
            {
                CaptureSelectedArea();
                DestroyWindow(hwnd);
            }
            break;

        case VK_SPACE: // Boşluk tuşu ile seçimi onaylama
            if (g_selectionFinished)
            {
                CaptureSelectedArea();
                DestroyWindow(hwnd);
            }
            break;
        }
        return 0;
    }

    case WM_RBUTTONDOWN: // Sağ tık ile iptal
    {
        DestroyWindow(hwnd);
        return 0;
    }

    case WM_DESTROY:
    {
        if (hbmBuffer)
            DeleteObject(hbmBuffer);
        if (hdcBuffer)
            DeleteDC(hdcBuffer);
        if (g_hFont)
            DeleteObject(g_hFont);
        if (g_hBackgroundBrush)
            DeleteObject(g_hBackgroundBrush);
        g_overlayWindow = NULL;
        return 0;
    }

    case WM_SETCURSOR:
    {
        if (g_selectionFinished)
        {
            POINT pt;
            GetCursorPos(&pt);
            ScreenToClient(hwnd, &pt);

            int handle = HitTestResizeHandle(pt);
            if (handle != 0)
            {
                SetCursor(LoadCursor(NULL, GetResizeCursor(handle)));
                return TRUE;
            }
            else if (pt.x >= g_selectionRect.left && pt.x <= g_selectionRect.right &&
                     pt.y >= g_selectionRect.top && pt.y <= g_selectionRect.bottom)
            {
                SetCursor(LoadCursor(NULL, IDC_SIZEALL));
                return TRUE;
            }
        }
        SetCursor(LoadCursor(NULL, IDC_CROSS));
        return TRUE;
    }
    }
    return DefWindowProcW(hwnd, uMsg, wParam, lParam);
}

void StartWindowSelection()
{
    g_isSelecting = true;
    g_highlightedWindow = NULL;
    g_mouseHook = SetWindowsHookExW(WH_MOUSE_LL, MouseHookProc, GetModuleHandleW(NULL), 0);
}

void StartAreaSelection()
{
    WNDCLASSW wc = {0};
    wc.lpfnWndProc = OverlayWindowProc;
    wc.hInstance = GetModuleHandle(NULL);
    wc.lpszClassName = OVERLAY_CLASS_NAME;
    wc.hCursor = LoadCursor(NULL, IDC_CROSS);
    RegisterClassW(&wc);

    // Tam ekran koordinatlarını al
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Overlay penceresini oluştur
    g_overlayWindow = CreateWindowExW(
        WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_LAYERED,
        OVERLAY_CLASS_NAME,
        L"",
        WS_POPUP,
        0, 0, screenWidth, screenHeight,
        NULL, NULL, GetModuleHandle(NULL), NULL);

    if (g_overlayWindow)
    {
        // Çizim değişkenlerini sıfırla
        g_isDrawing = false;
        g_selectionFinished = false;
        g_startPoint = {0};
        g_endPoint = {0};

        // Pencereyi göster
        ShowWindow(g_overlayWindow, SW_SHOW);
        UpdateWindow(g_overlayWindow);
    }
}

void ShowContextMenu(HWND hwnd)
{
    POINT pt;
    GetCursorPos(&pt);

    if (g_popup_menu)
    {
        DestroyMenu(g_popup_menu);
    }
    g_popup_menu = CreatePopupMenu();

    // Ana menü öğeleri
    InsertMenuW(g_popup_menu, UINT_MAX, MF_BYPOSITION | MF_STRING, 1, L"Tam Ekran Alıntısı");
    InsertMenuW(g_popup_menu, UINT_MAX, MF_BYPOSITION | MF_STRING, 2, L"Pencere Alıntısı");
    InsertMenuW(g_popup_menu, UINT_MAX, MF_BYPOSITION | MF_STRING, 3, L"Alan Seçimi");

    InsertMenuW(g_popup_menu, UINT_MAX, MF_BYPOSITION | MF_SEPARATOR, 0, NULL);

    HMENU hUploadMenu = CreatePopupMenu();
    InsertMenuW(hUploadMenu, UINT_MAX, MF_BYPOSITION | MF_STRING, 4, L"Tam Ekran Alıntısı + Upload");
    InsertMenuW(hUploadMenu, UINT_MAX, MF_BYPOSITION | MF_STRING, 5, L"Pencere Alıntısı + Upload");
    InsertMenuW(hUploadMenu, UINT_MAX, MF_BYPOSITION | MF_STRING, 6, L"Alan Seçimi + Upload");

    InsertMenuW(g_popup_menu, UINT_MAX, MF_BYPOSITION | MF_POPUP, (UINT_PTR)hUploadMenu, L"Upload Seçenekleri");

    InsertMenuW(g_popup_menu, UINT_MAX, MF_BYPOSITION | MF_SEPARATOR, 0, NULL);
    InsertMenuW(g_popup_menu, UINT_MAX, MF_BYPOSITION | MF_STRING, 2001, L"Website");
    InsertMenuW(g_popup_menu, UINT_MAX, MF_BYPOSITION | MF_STRING, WM_CLOSE, L"Çıkış");

    SetForegroundWindow(hwnd);
    TrackPopupMenu(g_popup_menu, TPM_RIGHTALIGN | TPM_BOTTOMALIGN,
                   pt.x, pt.y, 0, hwnd, NULL);
    PostMessage(hwnd, WM_NULL, 0, 0);
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
    case WM_TRAYICON:
        if (LOWORD(lParam) == WM_RBUTTONUP)
        {
            ShowContextMenu(hwnd);
        }
        return 0;

    case WM_COMMAND:
        switch (LOWORD(wParam))
        {
        // Normal modlar
        case 1: // Tam ekran
            g_uploadMode = false;
            SetTimer(hwnd, CAPTURE_DELAY_TIMER, CAPTURE_DELAY_MS, NULL);
            break;
        case 2: // Pencere
            g_uploadMode = false;
            StartWindowSelection();
            break;
        case ID_AREA_SELECTION: // Alan seçimi
            g_uploadMode = false;
            StartAreaSelection();
            break;

        // Upload modları
        case 4: // Tam ekran + upload
            g_uploadMode = true;
            SetTimer(hwnd, CAPTURE_DELAY_TIMER, CAPTURE_DELAY_MS, NULL);
            break;
        case 5: // Pencere + upload
            g_uploadMode = true;
            StartWindowSelection();
            break;
        case 6: // Alan seçimi + upload
            g_uploadMode = true;
            StartAreaSelection();
            break;
        case ID_WEBSITE:
            ShellExecuteW(NULL, L"open", L"https://shadesofdeath.github.io/shadesofdeath", NULL, NULL, SW_SHOWNORMAL);
            break;
        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;
        }
        return 0;

    case WM_TIMER:
        if (wParam == CAPTURE_DELAY_TIMER)
        {
            KillTimer(hwnd, CAPTURE_DELAY_TIMER);
            CaptureFullScreenDelayed();
        }
        return 0;

    case WM_DESTROY:
        if (g_hIcon)
            DestroyIcon(g_hIcon);
        if (g_hIconSmall)
            DestroyIcon(g_hIconSmall);
        Shell_NotifyIconW(NIM_DELETE, &g_nid);
        if (g_popup_menu)
            DestroyMenu(g_popup_menu);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, uMsg, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, LPWSTR, int)
{
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);

    Gdiplus::GdiplusStartupInput gdiplusStartupInput;
    ULONG_PTR gdiplusToken;
    Gdiplus::GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

    // İkonları yükle
    HICON hIconLarge = (HICON)LoadImageW(
        hInstance,
        MAKEINTRESOURCEW(1),
        IMAGE_ICON,
        32,
        32,
        LR_DEFAULTCOLOR);

    HICON hIconSmall = (HICON)LoadImageW(
        hInstance,
        MAKEINTRESOURCEW(1),
        IMAGE_ICON,
        16,
        16,
        LR_DEFAULTCOLOR);

    if (!hIconLarge || !hIconSmall)
    {
        hIconLarge = LoadIconW(NULL, IDI_APPLICATION);
        hIconSmall = LoadIconW(NULL, IDI_APPLICATION);
    }

    g_hIcon = hIconLarge;
    g_hIconSmall = hIconSmall;

    WNDCLASSW wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = L"SnapMasterClass";
    wc.hIcon = hIconLarge;
    RegisterClassW(&wc);

    // Pencereyi oluştur
    g_hwnd = CreateWindowExW(
        0, L"SnapMasterClass", L"SnapMaster",
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
        CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);

    if (!g_hwnd)
        return 0;

    // Küçük ikonu pencereye ayarla
    SendMessage(g_hwnd, WM_SETICON, ICON_SMALL, (LPARAM)hIconSmall);
    SendMessage(g_hwnd, WM_SETICON, ICON_BIG, (LPARAM)hIconLarge);

    // Tray ikonunu ayarla
    g_nid.cbSize = sizeof(NOTIFYICONDATAW);
    g_nid.hWnd = g_hwnd;
    g_nid.uID = 1;
    g_nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    g_nid.uCallbackMessage = WM_TRAYICON;
    g_nid.hIcon = hIconSmall; // Küçük ikonu tray için kullan
    wcscpy_s(g_nid.szTip, L"SnapMaster");
    Shell_NotifyIconW(NIM_ADD, &g_nid);

    MSG msg = {};
    while (GetMessageW(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    // Temizlik işlemleri
    if (g_hIcon)
        DestroyIcon(g_hIcon);
    if (g_hIconSmall)
        DestroyIcon(g_hIconSmall);

    Gdiplus::GdiplusShutdown(gdiplusToken);
    return 0;
}
