#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <wlanapi.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <icmpapi.h>
#include <netioapi.h>

#include <string>
#include <sstream>
#include <iomanip>
#include <memory>
#include <functional>

#pragma comment(lib, "wlanapi.lib")
#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "ws2_32.lib")

namespace {
    NOTIFYICONDATA nid = { sizeof(NOTIFYICONDATA) };
    HWND hwnd = nullptr;
    UINT_PTR timerId = 0;
    constexpr size_t PING_BUFFER_SIZE = 32;
    constexpr DWORD PING_TIMEOUT = 1000;
    constexpr WCHAR PING_TARGET[] = L"8.8.8.8";
    constexpr UINT WM_NOTIFYICON = WM_APP + 1;
    constexpr UINT IDM_EXIT = 1001;
}

class AutoCleanup {
private:
    std::function<void()> cleanup;

public:
    explicit AutoCleanup(std::function<void()>&& func) : cleanup(std::move(func)) {}
    ~AutoCleanup() { if (cleanup) cleanup(); }
    
    AutoCleanup(const AutoCleanup&) = delete;
    AutoCleanup& operator=(const AutoCleanup&) = delete;
    AutoCleanup(AutoCleanup&&) = delete;
    AutoCleanup& operator=(AutoCleanup&&) = delete;
};

std::wstring FormatBytes(const unsigned long long bytes) {
    std::wstringstream wss;
    wss.imbue(std::locale(""));
    if (bytes < 1024ULL) {
        wss << bytes << L" B/s";
    } else if (bytes < 1024ULL * 1024ULL) {
        wss << std::fixed << std::setprecision(1) << (bytes / 1024.0) << L" KB/s";
    } else {
        wss << std::fixed << std::setprecision(1) << (bytes / (1024.0 * 1024.0)) << L" MB/s";
    }
    return wss.str();
}

std::wstring GetWifiSignalStrength() {
    HANDLE hClient = nullptr;
    DWORD dwMaxClient = 2;
    DWORD dwCurVersion = 0;
    
    if (WlanOpenHandle(dwMaxClient, nullptr, &dwCurVersion, &hClient) != ERROR_SUCCESS) {
        return L"N/A";
    }
    
    AutoCleanup closeHandle([hClient]() { 
        if (hClient) WlanCloseHandle(hClient, nullptr); 
    });

    WLAN_INTERFACE_INFO_LIST* pIfList = nullptr;
    if (WlanEnumInterfaces(hClient, nullptr, &pIfList) != ERROR_SUCCESS) {
        return L"N/A";
    }

    AutoCleanup freeIfList([pIfList]() { 
        if (pIfList) WlanFreeMemory(pIfList); 
    });

    for (DWORD i = 0; i < pIfList->dwNumberOfItems; ++i) {
        WLAN_INTERFACE_INFO& iface = pIfList->InterfaceInfo[i];
        DWORD dataSize = sizeof(WLAN_CONNECTION_ATTRIBUTES);
        WLAN_CONNECTION_ATTRIBUTES* pConnAttributes = nullptr;

        if (WlanQueryInterface(hClient, &iface.InterfaceGuid,
            wlan_intf_opcode_current_connection, nullptr,
            &dataSize, reinterpret_cast<PVOID*>(&pConnAttributes), nullptr) == ERROR_SUCCESS) {

            AutoCleanup freeConnAttr([pConnAttributes]() { 
                if (pConnAttributes) WlanFreeMemory(pConnAttributes); 
            });

            return std::to_wstring(pConnAttributes->wlanAssociationAttributes.wlanSignalQuality) + L"%";
        }
    }

    return L"N/A";
}

std::wstring GetPing() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        return L"N/A";
    }
    
    AutoCleanup cleanupWsa([]() { WSACleanup(); });

    HANDLE hIcmp = IcmpCreateFile();
    if (hIcmp == INVALID_HANDLE_VALUE) {
        return L"N/A";
    }

    AutoCleanup closeIcmp([hIcmp]() { 
        if (hIcmp != INVALID_HANDLE_VALUE) IcmpCloseHandle(hIcmp); 
    });

    char sendData[PING_BUFFER_SIZE] = "PingTest";
    const DWORD replySize = sizeof(ICMP_ECHO_REPLY) + sizeof(sendData);
    auto replyBuffer = std::make_unique<uint8_t[]>(replySize);
    auto pEchoReply = reinterpret_cast<PICMP_ECHO_REPLY>(replyBuffer.get());

    if (!pEchoReply) {
        return L"N/A";
    }

    IN_ADDR addr;
    if (InetPton(AF_INET, PING_TARGET, &addr) != 1) {
        return L"N/A";
    }

    if (IcmpSendEcho(hIcmp, addr.S_un.S_addr, sendData, 
                     sizeof(sendData), nullptr, pEchoReply, 
                     replySize, PING_TIMEOUT)) {
        return std::to_wstring(pEchoReply->RoundTripTime) + L" ms";
    }

    return L"N/A";
}

void UpdateTray() {
    static ULONG64 prevSentBytes = 0;
    static ULONG64 prevRecvBytes = 0;
    
    MIB_IF_ROW2 ifRow = {};
    NET_IFINDEX ifIndex = 0;
    
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        return;
    }
    
    AutoCleanup cleanupWsa([]() { WSACleanup(); });

    IN_ADDR addr;
    if (InetPton(AF_INET, PING_TARGET, &addr) != 1) {
        return;
    }

    if (GetBestInterface(addr.S_un.S_addr, &ifIndex) == NO_ERROR) {
        ifRow.InterfaceIndex = ifIndex;
        if (GetIfEntry2(&ifRow) == NO_ERROR) {
            const ULONG64 sentBytes = ifRow.OutOctets;
            const ULONG64 recvBytes = ifRow.InOctets;

            // İlk çalıştırmada delta sıfır olsun
            if (prevSentBytes == 0) prevSentBytes = sentBytes;
            if (prevRecvBytes == 0) prevRecvBytes = recvBytes;

            std::wstringstream status;
            status << L"Upload: " << FormatBytes(sentBytes - prevSentBytes) << L"\n"
                   << L"Download: " << FormatBytes(recvBytes - prevRecvBytes) << L"\n"
                   << L"Ping: " << GetPing() << L"\n"
                   << L"Signal: " << GetWifiSignalStrength();

            wcscpy_s(nid.szTip, _countof(nid.szTip), status.str().c_str());
            Shell_NotifyIcon(NIM_MODIFY, &nid);

            prevSentBytes = sentBytes;
            prevRecvBytes = recvBytes;
        }
    }
}

LRESULT CALLBACK WindowProc(HWND hwndParam, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_TIMER:
            UpdateTray();
            return 0;

        case WM_NOTIFYICON: {
            if (lParam == WM_RBUTTONUP || lParam == WM_CONTEXTMENU) {
                POINT pt;
                GetCursorPos(&pt);

                HMENU hMenu = CreatePopupMenu();
                if (hMenu) {
                    InsertMenuW(hMenu, 0, MF_BYPOSITION | MF_STRING, IDM_EXIT, L"Exit");

                    // Menüyü göster ve tıklamayı bekle
                    SetForegroundWindow(hwndParam);
                    TrackPopupMenu(hMenu, TPM_RIGHTALIGN | TPM_BOTTOMALIGN | TPM_RIGHTBUTTON,
                                 pt.x, pt.y, 0, hwndParam, NULL);
                    DestroyMenu(hMenu);
                }
            }
            return 0;
        }

        case WM_COMMAND:
            if (LOWORD(wParam) == IDM_EXIT) {
                DestroyWindow(hwndParam);
                return 0;
            }
            break;

        case WM_DESTROY:
            KillTimer(hwndParam, timerId);
            Shell_NotifyIcon(NIM_DELETE, &nid);
            PostQuitMessage(0);
            return 0;

        default:
            return DefWindowProcW(hwndParam, uMsg, wParam, lParam);
    }
    return 0;
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, PWSTR, int) {
    // DPI desteğini etkinleştir
    SetProcessDPIAware();

    WNDCLASSW wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = L"SystemNetTryClass";
    
    if (!RegisterClassW(&wc)) {
        return 1;
    }

    hwnd = CreateWindowExW(
        0,
        L"SystemNetTryClass",
        L"SystemNetTry",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        CW_USEDEFAULT, CW_USEDEFAULT,
        nullptr,
        nullptr,
        hInstance,
        nullptr
    );

    if (!hwnd) {
        return 1;
    }

    nid.hWnd = hwnd;
    nid.uID = 1;
    nid.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
    nid.uCallbackMessage = WM_NOTIFYICON;
    nid.hIcon = LoadIconW(hInstance, MAKEINTRESOURCEW(101));

    if (!Shell_NotifyIcon(NIM_ADD, &nid)) {
        return 1;
    }

    timerId = SetTimer(hwnd, 1, 1000, nullptr);
    if (!timerId) {
        Shell_NotifyIcon(NIM_DELETE, &nid);
        return 1;
    }

    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}