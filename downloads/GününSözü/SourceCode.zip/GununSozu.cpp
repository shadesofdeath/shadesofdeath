#ifndef UNICODE
#define UNICODE
#endif

#ifndef _UNICODE
#define _UNICODE
#endif

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <commctrl.h>
#include <vector>
#include <string>
#include <random>
#include <clocale>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "user32.lib")

// Common Controls için manifest
#pragma comment(linker, "\"/manifestdependency:type='win32' \
name='Microsoft.Windows.Common-Controls' version='6.0.0.0' \
processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

// Global değişkenler
HWND g_hwnd = NULL;
HMENU g_popup_menu = NULL;
NOTIFYICONDATAW g_nid = {};
HICON g_hIcon = NULL;
std::vector<std::pair<std::wstring, std::wstring>> g_quotes;

// Forward declarations
LRESULT CALLBACK WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
void CreateTrayIcon(HWND hwnd);
void RemoveTrayIcon();
void ShowContextMenu(HWND hwnd);
void UpdateQuote();
void InitializeQuotes();

void InitializeQuotes()
{
    g_quotes = {
        {L"İnsan zihni, bir kere yeni boyutlara açıldığında, asla eski ölçülerine geri dönmez.", L"Oliver Wendell Holmes"},
        {L"Düşünmeden öğrenmek faydasız, öğrenmeden düşünmek tehlikelidir.", L"Konfüçyus"},
        {L"Bilgi güçtür.", L"Francis Bacon"},
        {L"Hayatın değeri uzun yaşanmasında değil, iyi yaşanmasındadır.", L"Montaigne"},
        {L"Hayal gücü bilgiden daha önemlidir.", L"Albert Einstein"},
        {L"Başarı son değil, başarısızlık ölümcül değil: Önemli olan devam etme cesaretidir.", L"Winston Churchill"},
        {L"Her şeyi bilmek mümkün değil, ama her şeyi öğrenmek mümkündür.", L"Sokrates"},
        {L"Yarını düşleyen kişi, bugünden değişmeye başlar.", L"Lao Tzu"},
        {L"İnsan zihni, bir kere yeni boyutlara açıldığında, asla eski ölçülerine geri dönmez.", L"Oliver Wendell Holmes"},
        {L"En karanlık saat, şafaktan hemen önceki saattir.", L"Thomas Fuller"},
        {L"Kendi rüyalarınızı inşa edin, yoksa başkası sizi kendi rüyalarını inşa etmeniz için kiralar.", L"Farraj Gray"},
        {L"Büyük işler başarmak için, sadece eyleme geçmekle kalmamalı, aynı zamanda hayal de etmeliyiz, sadece plan yapmakla kalmamalı, aynı zamanda inanmalıyız da.", L"Anatole France"},
        {L"Önemli olan ne yaptığımız değil, ne kadar sevgiyle yaptığımızdır.", L"Rahibe Teresa"},
        {L"Hayat bir bisiklete binmek gibidir. Dengenizi korumak için hareket etmeye devam etmelisiniz.", L"Albert Einstein"},
        {L"Geleceği tahmin etmenin en iyi yolu, onu yaratmaktır.", L"Peter Drucker"},
        {L"Büyük bir işe başlamanın yolu, konuşmayı bırakıp yapmaya başlamaktır.", L"Walt Disney"},
        {L"Zamanın değeri, onu nasıl kullandığınızla ölçülür.", L"Albert Schweitzer"},
        {L"İnsanlar ne dediğinizi unuturlar, ne yaptığınızı unuturlar, ama onlara nasıl hissettirdiğinizi asla unutmazlar.", L"Maya Angelou"},
        {L"En büyük zafer, asla düşmemek değil, her düştüğümüzde ayağa kalkmaktır.", L"Konfüçyus"},
        {L"Hayat, cesaretini gösterenlere cömert davranır.", L"Charles de Gaulle"},
        {L"İmkansız, sadece denemeyi bırakanlar için imkansızdır.", L"Napoleon Bonaparte"},
        {L"Yalnızca kendi yolunu bulan kişi, hayatını gerçekten yaşayabilir.", L"Henry David Thoreau"},
        {L"Mutluluk, gideceğimiz bir yer değil, yaşadığımız bir yolculuktur.", L"Margaret Lee Runbeck"},
        {L"En iyi intikam, dev bir başarıdır.", L"Frank Sinatra"},
        {L"Hayatta en önemli şey, sevgi ve saygıdır.", L"Dalai Lama"},
        {L"İnsan aklının sınırları, ona ulaşma cesaretini gösterenler tarafından aşılır.", L"Zeno"},
        {L"Hayat, her anı değerlendirebilenler için güzeldir.", L"Benjamin Franklin"},
        {L"Düşüncelerine dikkat et; onlar sözlerin olurlar. Sözlerine dikkat et; onlar eylemlerin olurlar. Eylemlerine dikkat et; onlar alışkanlıkların olurlar. Alışkanlıklarına dikkat et; onlar karakterin olurlar. Karakterine dikkat et; o senin kaderin olur.", L"Lao Tzu"},
        {L"Umut, hayatta kalmanın en güçlü silahıdır.", L"Nelson Mandela"},
        {L"Dünya, değişimi isteyenler tarafından değiştirilir.", L"Barack Obama"},
        {L"Gerçek bilgelik, kendi cehaletini bilmektir.", L"Sokrates"},
        {L"Kendi ışığını bulmak için, karanlığa girmekten korkma.", L"Paulo Coelho"},
        {L"Kitaplar, bilgi ve hayal gücünün en iyi dostlarıdır.", L"Victor Hugo"},
        {L"Gelecek, bugünden hazırlanmaya başlar.", L"Malcolm X"},
        {L"Her düşüş, yeni bir başlangıçtır.", L"George Bernard Shaw"},
        {L"Her şeyin bir sebebi vardır, bazen onu göremeyiz.", L"Steve Jobs"},
        {L"Eğer dünya iyi bir yer olsaydı, hiçbir şey değişmezdi.", L"Bill Gates"},
        {L"Çalışmak, hayatın en büyük ilacıdır.", L"Thomas Edison"},
        {L"Herkes bir dahi olabilir. Ama bir balığı ağaca tırmanma yeteneğine göre yargılarsanız, bütün hayatını aptal olduğuna inanarak geçirir.", L"Albert Einstein"},
        {L"Yapabileceğinizi düşündüğünüz ya da yapamayacağınızı düşündüğünüz, her halükarda haklısınızdır.", L"Henry Ford"},
        {L"Hayat kısa, kuralları çiğneyin, affedin çabuk, yavaşça öpün, gerçekten sevin ve yüzünüzü güldüren hiçbir şeyden pişman olmayın.", L"Mark Twain"},
        {L"Başarı, hevesinizi kaybetmeden başarısızlıktan başarısızlığa yürüyebilmektir.", L"Winston Churchill"},
        {L"Mutluluk hazır yapılmış bir şey değildir. Kendi eylemlerinizden gelir.", L"Dalai Lama"},
        {L"Benim en büyük hayalim, ölmeden önce dünyayı bir araya getirmektir.", L"Muhammad Ali"},
        {L"En iyi öngörü, onu yaratmaktır.", L"Alan Kay"},
        {L"İnsanları harekete geçirecek tek şey, hayalleridir.", L"Napoleon Bonaparte"},
        {L"Yarın çok önemli ise ve işiniz çok acilse, bugünün hayatına odaklanmayı unutmayın.", L"Dalai Lama"},
        {L"Hayat, bir çiçeğe benzer; ne kadar erken yaşarsanız o kadar çabuk solar.", L"William Shakespeare"},
        {L"Cesaret, sadece korkuyu yenmek değil, aynı zamanda korkuyla birlikte yürümektir.", L"Nelson Mandela"},
        {L"Öğrenme, keşfetme ve en önemlisi gelişme potansiyeliniz var.", L"Steve Jobs"},
        {L"Geçmişe takılıp kalmayın, gelecek için yaşayın.", L"Confucius"},
        {L"Hayat, denediğimiz şeylerin toplamıdır.", L"Ernest Hemingway"},
        {L"İçimizdeki çocuğu kaybetmediğimiz sürece yaşlanmayız.", L"Pablo Picasso"},
        {L"Dünya, bir aynadır; ona gülümsersen, sana da gülümser.", L"William Thackeray"},
        {L"Asıl sorun, insanların bilmedikleri değil, bilmediklerini sandıkları şeylerdir.", L"Mark Twain"},
        {L"Herkes yeteneklidir. Ama siz bir balığı ağaca tırmanma yeteneğine göre yargılarsanız, tüm hayatı boyunca aptal olduğuna inanacaktır.", L"Albert Einstein"},
        {L"Hayatta kalmak için bir şeyleri bilmek, başarmak için her şeyi bilmek gerekir.", L"Leonardo Da Vinci"},
        {L"Harekete geçmek, her zaman konuşmaktan daha önemlidir.", L"Albert Einstein"},
        {L"Hayattaki en büyük macera, hayallerinin peşinden gitmektir.", L"Oprah Winfrey"},
        {L"En büyük başarılar, en büyük riskleri alanlardan gelir.", L"John D. Rockefeller"},
        {L"İyilik yapmak, hayatta yapabileceğiniz en iyi şeylerden biridir.", L"Rahibe Teresa"},
        {L"Her zorlukta bir fırsat vardır, sadece onu görmesini bilmelisin.", L"Albert Einstein"},
        {L"Tek sınırlayıcınız kendi zihninizdir.", L"Napoleon Hill"},
        {L"Büyük şeyler küçük adımlarla başlar.", L"Lao Tzu"},
        {L"Hayatta önemli olan, ne kadar yaşadığınız değil, nasıl yaşadığınızdır.", L"Martin Luther King Jr."},
        {L"Sadece başkalarına yardım ederek gerçekten başarılı olabilirsiniz.", L"Zig Ziglar"},
        {L"Umut, en kötü zamanlarda bile sizi ayakta tutar.", L"Victor Frankl"},
        {L"En büyük zayıflığımız pes etmek. En kesin yol ise her zaman bir kez daha denemektir.", L"Thomas Edison"},
        {L"Bazen kaybolmak, doğru yolu bulmak için gereklidir.", L"Paulo Coelho"},
        {L"Unutmayın, hayat sadece sahip olduklarınızla değil, verdiklerinizle de ölçülür.", L"Nelson Mandela"},
        {L"Değişime açık olmak, büyümenin anahtarıdır.", L"Carl Rogers"},
        {L"En iyi öğrenme şekli, deneyimlemektir.", L"Benjamin Franklin"},
        {L"Hayatta sizi mutlu eden şeyleri yapın.", L"Ralph Waldo Emerson"},
        {L"Sessizce çalışın, bırakın başarınız gürültü yapsın.", L"Frank Ocean"},
        {L"Asıl mesele, bir amaca sahip olmaktır.", L"Viktor Frankl"},
        {L"Her yeni gün, yeni bir başlangıçtır.", L"Ernest Hemingway"},
        {L"Hayallerinizin peşinden gidin, hayatınızın her anında.", L"Walt Disney"},
        {L"Gerçek güç, başkalarına yardım etmektir.", L"Martin Luther King Jr."},
        {L"Başarıya giden yol, her zaman kolay değildir.", L"Oprah Winfrey"},
        {L"En büyük risk, risk almamaktır.", L"Mark Zuckerberg"},
        {L"Öğrenmek için her zaman hevesli olun.", L"Steve Jobs"},
        {L"En iyi öğretmenler, hayatın kendisidir.", L"Ralph Waldo Emerson"},
        {L"Mükemmellik, bir amaç değil, bir yolculuktur.", L"Zig Ziglar"},
        {L"Kendinize inanın, her şey mümkün.", L"Les Brown"},
        {L"Hayat, öğrendikçe daha anlamlı hale gelir.", L"John Dewey"},
        {L"Güzellik, bakanın gözündedir.", L"Oscar Wilde"},
        {L"Kendin ol, çünkü herkes başkası olmaya çalışıyor.", L"Kurt Cobain"},
        {L"Hayat kısa, tadını çıkar.", L"Voltaire"},
        {L"Asla pes etme, her zaman bir umut vardır.", L"Helen Keller"},
        {L"En büyük servet, sağlık ve mutluluktur.", L"George Bernard Shaw"},
        {L"Hayatınızda sevdiğiniz şeyleri yapın.", L"Albert Schweitzer"},
        {L"Her gün yeni bir başlangıçtır.", L"Marcus Aurelius"},
        {L"En iyi zaman her zaman şimdidir.", L"Seneca"},
        {L"Kendine dürüst ol, her zaman.", L"Platon"},
        {L"Cesaret, en büyük erdemdir.", L"Aristotle"},
        {L"Zaman, en değerli hazinedir.", L"Benjamin Franklin"},
        {L"Bilgi, güçtür.", L"Francis Bacon"},
        {L"Özgürlük, en büyük hedeftir.", L"Patrick Henry"},
        {L"Adalet, erdemlerin kraliçesidir.", L"Cicero"},
        {L"Güzellik, kalbin derinliklerindedir.", L"Kahlil Gibran"},
        {L"Aşk, hayatın anlamıdır.", L"Leo Tolstoy"},
        {L"Hayat bir öğrenme yolculuğudur.", L"Eleanor Roosevelt"},
        {L"En iyi lider, önce hizmet edendir.", L"Robert K. Greenleaf"},
        {L"Dürüstlük, her şeyin temelidir.", L"Abraham Lincoln"},
        {L"Sabır, en zorlu sınavdır.", L"Viktor Frankl"},
        {L"Başkalarına ilham verin.", L"Jim Rohn"},
        {L"Değişim, kaçınılmazdır.", L"Heraclitus"},
        {L"Başarı, bir yolculuktur, varış noktası değil.", L"Ben Sweetland"},
        {L"İşler iyiye gitmezse, sadece daha çok çalışmanız gerekir.", L"Henry Ford"},
        {L"Önemli olan, hayatınızda anlam yaratmaktır.", L"Viktor Frankl"},
        {L"Kendi gerçeğinizi keşfedin.", L"Buddha"},
        {L"Daima öğrenin, daima büyüyün.", L"Margaret Mead"},
        {L"Kendinizi sevin, başkalarını da sevin.", L"Louise Hay"},
        {L"İnanç, imkansızı mümkün kılar.", L"Norman Vincent Peale"},
        {L"Zorluklar, bizi güçlendirir.", L"James Allen"},
        {L"Hayatın amacı, mutlu olmaktır.", L"Dalai Lama"},
        {L"Her gün, yeni bir fırsattır.", L"Joel Osteen"},
        {L"Umut, asla tükenmez.", L"Emily Dickinson"},
        {L"Hayal gücü, gerçeği yaratır.", L"Lewis Carroll"},
        {L"Her düşüş, bir derstir.", L"Tony Robbins"},
        {L"En büyük başarı, kendin olmaktır.", L"Søren Kierkegaard"},
        {L"Hayat, anılarımızla zenginleşir.", L"Gabriel García Márquez"},
        {L"Hayatın tadını çıkarın, her anında.", L"Maya Angelou"},
        {L"Gelecek, cesur olanlarındır.", L"Elon Musk"},
        {L"Hayatta önemli olan, sevgiyle yaşamaktır.", L"Mother Teresa"},
        {L"İyilik, yayılan bir tohum gibidir.", L"Desmond Tutu"},
        {L"Başkalarının hayatında fark yaratın.", L"Les Brown"},
        {L"En güzel yolculuk, içimize doğru olandır.", L"Carl Jung"},
        {L"Mükemmelliğin peşinden koşun, asla yakalamayacağınızı bilin.", L"Salvador Dali"},
        {L"Hayatta önemli olan, denemektir.", L"Theodore Roosevelt"},
        {L"Hayatın zorluklarına rağmen, gülümsemeyi unutmayın.", L"Charlie Chaplin"},
        {L"Özgürlük, en büyük lütuftur.", L"Voltaire"},
        {L"Basitlik, en büyük zarafettir.", L"Leonardo da Vinci"},
        {L"Hayat, cesaretle yaşanır.", L"Helen Keller"},
        {L"Bilgelik, deneyimden gelir.", L"Confucius"},
        {L"Her şeyin bir sonu vardır, unutma.", L"Marcus Aurelius"},
        {L"Düşlerinizi gerçekleştirin.", L"Walt Disney"},
        {L"En büyük ders, hatalarımızdan öğrendiğimizdir.", L"John Wooden"},
        {L"Başkalarını affetmek, kendimizi özgürleştirir.", L"Lewis B. Smedes"},
        {L"Her gün, daha iyi olmak için çabalayın.", L"Zig Ziglar"},
        {L"Hayatta ne kadar çok verirseniz, o kadar çok alırsınız.", L"Francis of Assisi"},
        {L"Öğrenmek, hayat boyu süren bir yolculuktur.", L"Nelson Mandela"},
        {L"En iyi yatırım, kendinize yaptığınız yatırımdır.", L"Warren Buffett"},
        {L"Büyük düşünün, küçük başlayın.", L"Brian Tracy"},
        {L"Kendinize inanın, dünyayı değiştirebilirsiniz.", L"Rosa Parks"},
        {L"Hayatta en önemli şey, sevmek ve sevilmektir.", L"Audrey Hepburn"},
        {L"Gerçek güç, içten gelir.", L"Mahatma Gandhi"},
        {L"Cesur olun, hayallerinizin peşinden gidin.", L"Amelia Earhart"},
        {L"Her an, hayatınızı değiştirme potansiyeline sahiptir.", L"Deepak Chopra"},
        {L"İyi bir insan olmak, en büyük başarıdır.", L"Ralph Waldo Emerson"},
        {L"Hayat, bir armağandır; onu değerlendirin.", L"Albert Einstein"},
        {L"Mutluluk, bir seçimdir.", L"Wayne Dyer"},
        {L"Gülümse, dünya seninle gülsün.", L"Thich Nhat Hanh"},
        {L"Her zorluk, bir büyüme fırsatıdır.", L"John Maxwell"},
        {L"İyilik yapmak, dünyayı değiştirmenin en güzel yoludur.", L"Mahatma Gandhi"},
        {L"Kendinize karşı nazik olun.", L"Kristin Neff"},
        {L"Hayatta önemli olan, yolculuğun kendisidir.", L"T.S. Eliot"},
        {L"Geçmişi unutun, gelecek için yaşayın.", L"Oprah Winfrey"},
        {L"Sevginin gücüne inanın.", L"Martin Luther King Jr."},
        {L"Herkesin bir amacı vardır.", L"Viktor Frankl"},
        {L"En büyük zenginlik, sağlıktır.", L"Virgil"},
        {L"Sessizlik, bazen en güzel cevaptır.", L"Buddha"},
        {L"Hayatı, bir macera olarak görün.", L"Henry David Thoreau"},
        {L"Hayallerin peşinden gitmekten vazgeçmeyin.", L"Steve Jobs"},
        {L"En önemli şey, şimdiye odaklanmaktır.", L"Eckhart Tolle"},
        {L"İyiliğin gücüne inanın.", L"Desmond Tutu"},
        {L"Büyük olmak için, önce küçük olmak gerekir.", L"Lao Tzu"},
        {L"Hayatta hiçbir şey tesadüf değildir.", L"Friedrich Nietzsche"},
        {L"En güçlü silah, bilgidir.", L"Nelson Mandela"},
        {L"Hayatı sevmek, yaşamaktır.", L"Leo Buscaglia"},
        {L"En büyük hazine, dürüstlüktür.", L"Benjamin Franklin"},
        {L"Herkes, kendi yolunu çizer.", L"Carlos Castaneda"},
        {L"Zorluklar, bizi daha da güçlendirir.", L"Friedrich Nietzsche"},
        {L"İnanç, her şeyin başlangıcıdır.", L"Norman Vincent Peale"},
        {L"Her gün, yeni bir mucizedir.", L"Elizabeth Gilbert"},
        {L"Hayatta önemli olan, sevmektir.", L"Paulo Coelho"},
        {L"En iyi yatırım, kendimize yaptığımızdır.", L"Warren Buffett"},
        {L"Büyümek, her zaman bir seçimdir.", L"Carol Dweck"},
        {L"Gülümsemek, dünyanın dilidir.", L"Thich Nhat Hanh"},
        {L"Hayatta önemli olan, anlam yaratmaktır.", L"Viktor Frankl"},
        {L"En büyük başarı, kendinizi aşmaktır.", L"Bruce Lee"},
        {L"Öğrenmek, her zaman yeni kapılar açar.", L"Neil deGrasse Tyson"},
        {L"Hayatta her şey, bir deneyimdir.", L"Ralph Waldo Emerson"},
        {L"Başkalarının hayatına dokunmak, en büyük sanattır.", L"Maya Angelou"},
        {L"Hayatta sadece iki şey kesindir: Ölüm ve değişim.", L"Buddha"},
        {L"Özgürlük, içsel bir yolculuktur.", L"Dalai Lama"},
        {L"Mükemmelliğin peşinde koşmayın, gelişim peşinde koşun.", L"Carol Dweck"},
        {L"Hayatı bir dans gibi yaşayın.", L"Rumi"},
        {L"Her an, yeni bir başlangıçtır.", L"Eckhart Tolle"},
        {L"Hayatta önemli olan, doğru yolda ilerlemektir.", L"Martin Luther King Jr."},
        {L"En büyük cesaret, dürüst olmaktır.", L"William Shakespeare"},
        {L"Hayat kısa, iyi yaşayın.", L"Oprah Winfrey"},
        {L"Daima meraklı olun.", L"Albert Einstein"},
        {L"Hayatta önemli olan, iç huzurdur.", L"Epictetus"},
        {L"İyiliğe odaklanın, iyilik sizi takip eder.", L"Thich Nhat Hanh"},
        {L"Hayatta önemli olan, öğrenmektir.", L"John Dewey"},
        {L"Her insan, eşsiz bir hikayeye sahiptir.", L"Paulo Coelho"},
        {L"Hayatınızı, bir sanat eseri gibi yaratın.", L"Michelangelo"},
        {L"Geçmişe değil, geleceğe odaklanın.", L"Steve Jobs"},
        {L"Her an, bir fırsattır.", L"Tony Robbins"},
        {L"Hayatın amacı, yaşamaktır.", L"Alan Watts"},
        {L"Özgürlük, kendi seçimidir.", L"Eleanor Roosevelt"},
        {L"Her şey, bir denge içindedir.", L"Carl Jung"},
        {L"Gülümsemek, ruhun güzelliğidir.", L"Dalai Lama"},
        {L"Hayatta önemli olan, şükretmektir.", L"Melody Beattie"},
        {L"En büyük zafer, kendinizi yenebilmektir.", L"Napoleon Bonaparte"},
        {L"Hayatı, bir hediye olarak kabul edin.", L"Thich Nhat Hanh"},
        {L"Cesaret, korkunun üstesinden gelmektir.", L"Nelson Mandela"},
        {L"Hayatta önemli olan, kendin olmaktır.", L"Oscar Wilde"},
        {L"En büyük macera, kendi içinize yolculuktur.", L"Hermann Hesse"},
        {L"Hayatın anlamı, başkalarına yardım etmektir.", L"Albert Schweitzer"},
        {L"Umut, her zaman vardır.", L"Emily Dickinson"},
        {L"Hayalleriniz, gerçeğe dönüşebilir.", L"Walt Disney"},
        {L"Hayat, bir yolculuktur, bir varış noktası değil.", L"Ralph Waldo Emerson"},
        {L"En büyük ders, sevmektir.", L"Leo Tolstoy"},
        {L"Hayatı, bir melodi gibi yaşayın.", L"Victor Hugo"},
        {L"Her düşüş, bir fırsattır.", L"Zig Ziglar"},
        {L"Hayatı, bir serüven olarak görün.", L"Mark Twain"},
        {L"Hayatta önemli olan, anlam bulmaktır.", L"Viktor Frankl"},
        {L"En büyük güç, sevmekten gelir.", L"Leo Buscaglia"},
        {L"Hayat, kısa bir zamandır, onu iyi değerlendirin.", L"Seneca"},
        {L"Her insan, bir potansiyele sahiptir.", L"Abraham Maslow"},
        {L"Hayat, bir deneyimdir, öğrenin.", L"John Dewey"},
        {L"En büyük başarı, başkalarını mutlu etmektir.", L"Mother Teresa"},
        {L"Hayatta önemli olan, kendinizle barışmaktır.", L"Wayne Dyer"},
        {L"Özgürlük, bir sorumluluktur.", L"Albert Camus"},
        {L"Hayatı, bir oyun gibi oynayın.", L"William Shakespeare"},
        {L"En büyük bilgi, deneyimden gelir.", L"Benjamin Franklin"},
        {L"Hayatta önemli olan, büyümektir.", L"Carl Rogers"},
        {L"Cesaret, her zaman vardır, onu kullanın.", L"Les Brown"},
        {L"Hayatı, bir armağan gibi açın.", L"Eckhart Tolle"},
        {L"En büyük zenginlik, paylaşmaktır.", L"Francis of Assisi"},
        {L"Hayatta önemli olan, anlamlı bir yaşam sürmektir.", L"Søren Kierkegaard"},
        {L"En büyük sevgi, koşulsuz sevmektir.", L"Dalai Lama"},
        {L"Hayatı, her anıyla yaşayın.", L"Maya Angelou"},
        {L"En büyük güç, bilgeliktir.", L"Confucius"},
        {L"Hayatta önemli olan, gerçeği aramaktır.", L"Sokrates"},
        {L"En büyük korku, korkunun kendisidir.", L"Franklin D. Roosevelt"},
        {L"Hayatı, bir mucize olarak görün.", L"Albert Einstein"},
        {L"En büyük miras, sevgidir.", L"Audrey Hepburn"},
        {L"Hayatı, öğrenerek yaşayın.", L"Nelson Mandela"},
        {L"En büyük başarı, başkalarına ilham vermektir.", L"Nelson Mandela"},
        {L"Hayatta önemli olan, bağlantı kurmaktır.", L"Brené Brown"},
        {L"En büyük cesaret, kırılganlığı kabul etmektir.", L"Brené Brown"},
        {L"Hayatı, yaratıcılıkla yaşayın.", L"Pablo Picasso"},
        {L"En büyük keşif, kendinizi keşfetmektir.", L"Carl Jung"},
        {L"Hayat, bir dans gibidir, akışa bırakın.", L"Rumi"},
        {L"En büyük sihir, inanmaktır.", L"Roald Dahl"},
        {L"Hayatta önemli olan, anı yaşamaktır.", L"Eckhart Tolle"},
        {L"En büyük hazine, sağlıktır.", L"Buddha"},
        {L"Hayatı, umutla yaşayın.", L"Victor Frankl"},
        {L"En büyük fark, sevgiyle yapılan bir farktır.", L"Mother Teresa"},
        {L"Hayatta önemli olan, affetmektir.", L"Lewis B. Smedes"},
        {L"En büyük zevk, paylaşmaktır.", L"Leo Buscaglia"},
        {L"Hayatı, sevgiyle sarın.", L"Thich Nhat Hanh"},
        {L"En büyük yolculuk, kalbe yapılan yolculuktur.", L"Rumi"},
        {L"Hayatı, bilgelikle yaşayın.", L"Platon"},
        {L"En büyük erdem, dürüstlüktür.", L"Aristotle"},
        {L"Hayatı, bir senfoni gibi yaşayın.", L"Ludwig van Beethoven"},
        {L"En büyük sır, sevginin gücüdür.", L"Deepak Chopra"},
        {L"Hayatı, öğrenmeye açık olun.", L"Maria Montessori"},
        {L"En büyük armağan, zamandır.", L"Benjamin Franklin"},
        {L"Hayatı, şükranla yaşayın.", L"Oprah Winfrey"},
        {L"En büyük lütuf, güvendir.", L"Ernest Hemingway"},
        {L"Hayatta önemli olan, içtenliktir.", L"Ralph Waldo Emerson"},
        {L"En büyük güç, sessizliktir.", L"Lao Tzu"},
        {L"Hayatı, neşeyle yaşayın.", L"Dalai Lama"},
        {L"En büyük arzu, barıştır.", L"Mahatma Gandhi"},
        {L"Hayatı, coşkuyla yaşayın.", L"Walt Whitman"},
        {L"En büyük hediye, hayatın kendisidir.", L"William Shakespeare"},
        {L"Hayatı, merhametle yaşayın.", L"Rahibe Teresa"},
        {L"En büyük kahraman, her zaman kendine inanandır.", L"Muhammad Ali"},
        {L"Hayatınızı, sevgiyle yaratın.", L"Louise Hay"},
        {L"Her an, bir fırsattır; değerlendirin.", L"Paulo Coelho"},
        {L"En büyük keşif, bir başkasını anlamaktır.", L"Carl Rogers"},
        {L"Hayatınızı, bir şiir gibi yaşayın.", L"Kahlil Gibran"},
        {L"En büyük ihtimal, iyiliğin yayılmasıdır.", L"Desmond Tutu"},
        {L"Hayatınızı, umutla boyayın.", L"Pablo Picasso"},
        {L"En büyük dönüşüm, kalpten başlar.", L"Rumi"},
        {L"Hayatın amacı, iyilik yapmaktır.", L"Dalai Lama"},
        {L"En büyük sır, hayatın tadını çıkarmaktır.", L"Albert Schweitzer"},
        {L"Hayatınızı, anlamlı kılın.", L"Viktor Frankl"},
        {L"En büyük fark, küçük eylemlerle yaratılır.", L"Rahibe Teresa"},
        {L"Hayatınızı, öğrenmeye adayın.", L"Sokrates"},
        {L"En büyük güç, bilgelikten gelir.", L"Confucius"},
        {L"Hayatı, tutkuyla yaşayın.", L"Vincent van Gogh"},
        {L"En büyük zenginlik, mutlu anılardır.", L"Mark Twain"},
        {L"Hayatı, merakla yaşayın.", L"Albert Einstein"},
        {L"En büyük hazine, zamanı iyi kullanmaktır.", L"Benjamin Franklin"},
        {L"Hayatınızı, özgürce yaşayın.", L"Eleanor Roosevelt"},
        {L"En büyük mücadele, kendi zihnimizle olan mücadeledir.", L"Buddha"},
        {L"Hayatınızı, güzellikle doldurun.", L"Oscar Wilde"},
        {L"En büyük yolculuk, kendi kalbinize olan yolculuktur.", L"Hermann Hesse"},
        {L"Hayatı, sevgiyle dönüştürün.", L"Leo Tolstoy"},
        {L"En büyük ilham, içten gelir.", L"Ralph Waldo Emerson"},
        {L"Hayatınızı, anlamla doldurun.", L"Victor Frankl"},
        {L"En büyük ders, şefkat göstermektir.", L"Dalai Lama"},
        {L"Hayatınızı, sevinçle kucaklayın.", L"Maya Angelou"},
        {L"En büyük başarı, hayallerinizi gerçekleştirmektir.", L"Walt Disney"},
        {L"Hayatınızı, tutkuyla takip edin.", L"Steve Jobs"},
        {L"En büyük etki, iyilik yaparak yaratılır.", L"Mahatma Gandhi"},
        {L"Hayatınızı, dürüstlükle yaşayın.", L"Abraham Lincoln"},
        {L"En büyük miras, sevgi ve bilgeliktir.", L"Nelson Mandela"},
        {L"Hayatınızı, öğrenme tutkusuyla yaşayın.", L"Albert Einstein"},
        {L"En büyük cesaret, denemektir.", L"Theodore Roosevelt"},
        {L"Hayatınızı, nezaketle yaşayın.", L"Audrey Hepburn"},
        {L"En büyük hediyeniz, hayatınızdır.", L"Thich Nhat Hanh"},
        {L"Hayatınızı, anlamlı bir şekilde yaşayın.", L"Viktor Frankl"},
        {L"En büyük armağan, içsel huzurdur.", L"Eckhart Tolle"},
        {L"Hayatınızı, kendiniz olarak yaşayın.", L"Kurt Cobain"},
        {L"En büyük mutluluk, anda yaşamaktır.", L"Eckhart Tolle"},
        {L"Hayatınızı, keyifle yaşayın.", L"Leo Buscaglia"},
        {L"En büyük umut, daima bir çıkış yolunun olmasıdır.", L"Emily Dickinson"},
        {L"Hayatınızı, bir serüvene dönüştürün.", L"Amelia Earhart"},
        {L"En büyük güç, içten gelir.", L"Mahatma Gandhi"},
        {L"Hayatınızı, anlamlı eylemlerle doldurun.", L"Martin Luther King Jr."},
        {L"En büyük güzellik, kalpten yansır.", L"Kahlil Gibran"},
        {L"Hayatınızı, saygıyla yaşayın.", L"Desmond Tutu"},
        {L"En büyük başarı, başkalarını desteklemektir.", L"Oprah Winfrey"},
        {L"Hayatınızı, sevgiyle dönüştürün.", L"Leo Tolstoy"},
        {L"En büyük zenginlik, deneyim biriktirmektir.", L"Henry David Thoreau"},
        {L"Hayatınızı, merakla öğrenin.", L"John Dewey"},
        {L"En büyük zafer, kendi iç savaşı kazanmaktır.", L"Buddha"},
        {L"Hayatınızı, sabırla yaşayın.", L"Viktor Frankl"},
        {L"En büyük keşif, içsel dünyadır.", L"Carl Jung"},
        {L"Hayatınızı, yaratıcılıkla ifade edin.", L"Leonardo da Vinci"},
        {L"En büyük bilgelik, öğrenmektir.", L"Sokrates"},
        {L"Hayatınızı, her anıyla sevin.", L"Maya Angelou"},
        {L"En büyük tutku, öğrenmektir.", L"Maria Montessori"},
        {L"Hayatınızı, adaletle yaşayın.", L"Cicero"},
        {L"En büyük erdem, iyiliktir.", L"Confucius"},
        {L"Hayatınızı, hedeflerinizle yaşayın.", L"Nelson Mandela"},
        {L"En büyük hediye, zaman ayırmaktır.", L"Benjamin Franklin"},
        {L"Hayatınızı, coşkuyla kucaklayın.", L"Walt Whitman"},
        {L"En büyük mucize, hayatın kendisidir.", L"Albert Einstein"},
        {L"Hayatınızı, bilgelikle yaşayın.", L"Platon"},
        {L"En büyük arzu, barışı yaymaktır.", L"Mahatma Gandhi"},
        {L"Hayatınızı, şükranla yaşayın.", L"Oprah Winfrey"},
        {L"En büyük ilham kaynağı, kalbinizdir.", L"Rumi"},
        {L"Hayatınızı, hayallerle besleyin.", L"Walt Disney"},
        {L"En büyük ders, hoşgörüdür.", L"Dalai Lama"},
        {L"Hayatınızı, umutla yaşayın.", L"Victor Frankl"},
        {L"En büyük güç, sevgiyle hareket etmektir.", L"Mother Teresa"},
        {L"Hayatınızı, gülümseyerek yaşayın.", L"Thich Nhat Hanh"},
    };
}

void CreateTrayIcon(HWND hwnd)
{
    ZeroMemory(&g_nid, sizeof(NOTIFYICONDATAW));
    g_nid.cbSize = sizeof(NOTIFYICONDATAW);
    g_nid.hWnd = hwnd;
    g_nid.uID = 1;
    g_nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    g_nid.uCallbackMessage = WM_USER + 1;

    // Energy icon from shell32.dll
    if (ExtractIconExW(L"shell32.dll", 43, &g_hIcon, NULL, 1) > 0 && g_hIcon)
    {
        g_nid.hIcon = g_hIcon;
    }
    else
    {
        g_nid.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    }

    // Geçici olarak boş bir tooltip ayarla
    wcscpy_s(g_nid.szTip, L"");
    Shell_NotifyIconW(NIM_ADD, &g_nid);

    // Hemen bir söz göster
    UpdateQuote();
}

void RemoveTrayIcon()
{
    if (g_hIcon)
    {
        DestroyIcon(g_hIcon);
    }
    Shell_NotifyIconW(NIM_DELETE, &g_nid);
}

void UpdateQuote()
{
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::uniform_int_distribution<size_t> dis(0, g_quotes.size() - 1);

    size_t index = dis(gen);
    const auto &quote = g_quotes[index];

    wchar_t tooltip[128];
    _snwprintf_s(tooltip, _countof(tooltip), L"%s\n- %s",
                 quote.first.c_str(), quote.second.c_str());

    wcscpy_s(g_nid.szTip, tooltip);
    Shell_NotifyIconW(NIM_MODIFY, &g_nid);
}

void ShowContextMenu(HWND hwnd)
{
    POINT pt;
    GetCursorPos(&pt);

    HMENU hMenu = CreatePopupMenu();
    if (!hMenu)
        return;

    if (g_popup_menu)
    {
        DestroyMenu(g_popup_menu);
    }
    g_popup_menu = hMenu;

    InsertMenuW(g_popup_menu, static_cast<UINT>(-1), MF_BYPOSITION | MF_STRING,
                1000, L"Yeni Söz");

    InsertMenuW(g_popup_menu, static_cast<UINT>(-1), MF_BYPOSITION | MF_SEPARATOR, 0, NULL);
    InsertMenuW(g_popup_menu, static_cast<UINT>(-1), MF_BYPOSITION | MF_STRING, WM_CLOSE, L"Çıkış");

    SetForegroundWindow(hwnd);
    TrackPopupMenu(g_popup_menu, TPM_RIGHTALIGN | TPM_BOTTOMALIGN,
                   pt.x, pt.y, 0, hwnd, NULL);
    PostMessage(hwnd, WM_NULL, 0, 0);
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
    case WM_CREATE:
        SetTimer(hwnd, 1, 10000, NULL); // Her dakika güncelle
        return 0;

    case WM_TIMER:
        UpdateQuote();
        return 0;

    case WM_CLOSE:
        DestroyWindow(hwnd);
        return 0;

    case WM_DESTROY:
        RemoveTrayIcon();
        PostQuitMessage(0);
        return 0;

    case WM_USER + 1:
        if (LOWORD(lParam) == WM_RBUTTONUP)
        {
            ShowContextMenu(hwnd);
        }
        return 0;

    case WM_COMMAND:
        if (LOWORD(wParam) == 1000)
        {
            UpdateQuote();
        }
        else if (LOWORD(wParam) == WM_CLOSE)
        {
            PostMessage(hwnd, WM_CLOSE, 0, 0);
        }
        return 0;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, LPWSTR, int)
{
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);

    INITCOMMONCONTROLSEX icc = {
        sizeof(INITCOMMONCONTROLSEX),
        ICC_WIN95_CLASSES};
    InitCommonControlsEx(&icc);

    // Sözleri başlat
    InitializeQuotes();

    const wchar_t CLASS_NAME[] = L"QuoteDisplayClass";
    WNDCLASS wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);

    RegisterClass(&wc);

    g_hwnd = CreateWindowEx(
        0, CLASS_NAME, L"Günün Sözü",
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
        CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);

    if (g_hwnd == NULL)
    {
        return 0;
    }

    CreateTrayIcon(g_hwnd);

    MSG msg = {};
    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}