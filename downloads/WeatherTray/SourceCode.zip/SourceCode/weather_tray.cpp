#include <windows.h>
#include <shellapi.h>
#include <wininet.h>
#include <string>
#include <sstream>
#include "resource.h"
#include <uxtheme.h>

#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "uxtheme.lib")

// DPI farkındalığı için manifest tanımlamaları
#pragma comment(linker,"\"/manifestdependency:type='win32' \
name='Microsoft.Windows.Common-Controls' version='6.0.0.0' \
processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

#define ID_TRAY_APP_ICON    1001
#define ID_TRAY_EXIT        1002
#define ID_TRAY_REFRESH     1003
#define WM_TRAYICON        (WM_USER + 1)
#define IDI_MYICON         101

// Global değişkenler
NOTIFYICONDATA nid = {};
HWND hwnd;

// UTF-8'den WCHAR'a dönüşüm fonksiyonu
std::wstring UTF8ToWide(const char* str) {
    int size_needed = MultiByteToWideChar(CP_UTF8, 0, str, -1, NULL, 0);
    std::wstring wstrTo(size_needed, 0);
    MultiByteToWideChar(CP_UTF8, 0, str, -1, &wstrTo[0], size_needed);
    return wstrTo;
}

// UTF-8 string'i wstring'e çeviren fonksiyon
std::wstring toWideString(const std::string& str) {
    if (str.empty()) return std::wstring();
    int size_needed = MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), NULL, 0);
    std::wstring wstrTo(size_needed, 0);
    MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), &wstrTo[0], size_needed);
    return wstrTo;
}

// Hava durumu verilerini çeken fonksiyon
std::string FetchWeatherData() {
    HINTERNET hInternet = InternetOpenA("Weather App", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hInternet) return "Bağlantı hatası";

    const char* weatherUrl = "https://wttr.in/?format="
        "📍 %l\\n"
        "🌡️ %C %c %t\\n"
        "💧 %h%%\\n"
        "🌪️ %w\\n"
        "🌧️ %p";
    
    HINTERNET hConnect = InternetOpenUrlA(hInternet, weatherUrl, NULL, 0, INTERNET_FLAG_RELOAD, 0);
    
    if (!hConnect) {
        InternetCloseHandle(hInternet);
        return "Veri alınamadı";
    }

    std::string response;
    char buffer[4096];
    DWORD bytesRead;

    while (InternetReadFile(hConnect, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead > 0) {
        buffer[bytesRead] = 0;
        response += buffer;
    }

    InternetCloseHandle(hConnect);
    InternetCloseHandle(hInternet);

    // Yanıtı düzenle
    size_t pos;
    
    // Fazla % işaretlerini temizle
    while ((pos = response.find("%%")) != std::string::npos) {
        response.replace(pos, 2, "%");
    }
    
    // Gereksiz artı işaretlerini temizle
    while ((pos = response.find("+")) != std::string::npos) {
        response.replace(pos, 1, " ");
    }
    
    // Çift boşlukları temizle
    while ((pos = response.find("  ")) != std::string::npos) {
        response.replace(pos, 2, " ");
    }

    return response;
}

// Pencere prosedürü
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CREATE: {
            std::string weatherData = FetchWeatherData();
            std::wstring tooltipText = toWideString(weatherData);
            wcscpy_s(nid.szTip, tooltipText.c_str());
            Shell_NotifyIcon(NIM_MODIFY, &nid);
            return 0;
        }
        case WM_TRAYICON: {
            switch (lParam) {
                case WM_RBUTTONDOWN: {
                    POINT pt;
                    GetCursorPos(&pt);
                    HMENU hMenu = CreatePopupMenu();
                    
                    // UTF-8 menü öğeleri
                    const char* menuRefresh = "Refresh";
                    const char* menuExit = "Exit";
                    
                    // UTF-8'den Wide char'a dönüştür
                    std::wstring wMenuRefresh = UTF8ToWide(menuRefresh);
                    std::wstring wMenuExit = UTF8ToWide(menuExit);
                    
                    AppendMenuW(hMenu, MF_STRING, ID_TRAY_REFRESH, wMenuRefresh.c_str());
                    AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
                    AppendMenuW(hMenu, MF_STRING, ID_TRAY_EXIT, wMenuExit.c_str());
                    
                    SetForegroundWindow(hWnd);
                    TrackPopupMenu(hMenu, TPM_BOTTOMALIGN | TPM_LEFTALIGN, 
                        pt.x, pt.y, 0, hWnd, NULL);
                    
                    DestroyMenu(hMenu);
                    break;
                }
                case WM_LBUTTONDOWN: {
                    std::string weatherData = FetchWeatherData();
                    std::wstring tooltipText = toWideString(weatherData);
                    wcscpy_s(nid.szTip, tooltipText.c_str());
                    Shell_NotifyIcon(NIM_MODIFY, &nid);
                    break;
                }
            }
            break;
        }
        case WM_COMMAND: {
            switch (LOWORD(wParam)) {
                case ID_TRAY_EXIT: {
                    Shell_NotifyIcon(NIM_DELETE, &nid);
                    PostQuitMessage(0);
                    break;
                }
                case ID_TRAY_REFRESH: {
                    std::string weatherData = FetchWeatherData();
                    std::wstring tooltipText = toWideString(weatherData);
                    wcscpy_s(nid.szTip, tooltipText.c_str());
                    Shell_NotifyIcon(NIM_MODIFY, &nid);
                    break;
                }
            }
            break;
        }
        case WM_TIMER: {
            std::string weatherData = FetchWeatherData();
            std::wstring tooltipText = toWideString(weatherData);
            wcscpy_s(nid.szTip, tooltipText.c_str());
            Shell_NotifyIcon(NIM_MODIFY, &nid);
            break;
        }
        default:
            return DefWindowProc(hWnd, msg, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    // DPI farkındalığını etkinleştir
    SetProcessDPIAware();

    // Pencere sınıfı kaydı
    WNDCLASSEXW wc = {0};
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = L"WeatherTrayApp";
    
    // İkonları yükle
    HICON hIconBig = LoadIcon(hInstance, MAKEINTRESOURCE(MAINICON));
    HICON hIconSmall = (HICON)LoadImage(hInstance, 
                                       MAKEINTRESOURCE(MAINICON),
                                       IMAGE_ICON,
                                       16,
                                       16,
                                       LR_DEFAULTCOLOR);

    wc.hIcon = hIconBig ? hIconBig : LoadIcon(NULL, IDI_APPLICATION);
    wc.hIconSm = hIconSmall ? hIconSmall : LoadIcon(NULL, IDI_APPLICATION);
    
    if (!RegisterClassExW(&wc)) return 1;

    // Gizli pencere oluştur
    hwnd = CreateWindowW(L"WeatherTrayApp", L"Hava Durumu",
                        WS_OVERLAPPEDWINDOW,
                        CW_USEDEFAULT, CW_USEDEFAULT,
                        0, 0,
                        NULL, NULL, hInstance, NULL);

    if (!hwnd) return 1;

    ShowWindow(hwnd, SW_HIDE);

    // Sistem tray ikonu
    HICON hTrayIcon = (HICON)LoadImage(hInstance, 
                                      MAKEINTRESOURCE(MAINICON),
                                      IMAGE_ICON,
                                      16,
                                      16,
                                      LR_DEFAULTCOLOR);

    // Tray icon yapılandırması
    ZeroMemory(&nid, sizeof(nid));
    nid.cbSize = sizeof(NOTIFYICONDATA);
    nid.hWnd = hwnd;
    nid.uID = ID_TRAY_APP_ICON;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = WM_TRAYICON;
    nid.hIcon = hTrayIcon ? hTrayIcon : LoadIcon(NULL, IDI_APPLICATION);
    wcscpy_s(nid.szTip, UTF8ToWide("📱 Hava Durumu Yükleniyor...").c_str());
    
    if (!Shell_NotifyIcon(NIM_ADD, &nid)) {
        MessageBoxW(NULL, L"Sistem tray ikonu eklenemedi!", L"Hata", MB_ICONERROR);
        return 1;
    }

    // Dakikada bir güncelleme için timer (60000 ms = 1 dakika)
    SetTimer(hwnd, 1, 60000, NULL);
    PostMessage(hwnd, WM_TIMER, 0, 0);

    // Ana mesaj döngüsü
    MSG msg = {};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // Temizlik
    Shell_NotifyIcon(NIM_DELETE, &nid);
    if (hTrayIcon) DestroyIcon(hTrayIcon);
    if (hIconSmall) DestroyIcon(hIconSmall);
    if (hIconBig) DestroyIcon(hIconBig);
    
    return 0;
}