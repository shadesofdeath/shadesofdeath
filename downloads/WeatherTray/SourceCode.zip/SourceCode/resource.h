// resource.h
#ifndef RESOURCE_H
#define RESOURCE_H

#define MAINICON 101

#endif // RESOURCE_H