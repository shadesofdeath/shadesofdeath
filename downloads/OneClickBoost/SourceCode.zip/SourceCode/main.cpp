#define NOMINMAX
#define WIN32_LEAN_AND_MEAN

#ifndef SE_PROFILE_SINGLE_PROCESS_NAME
#define SE_PROFILE_SINGLE_PROCESS_NAME L"SeProfileSingleProcessPrivilege"
#endif

#include <windows.h>
#include <shellapi.h>
#include <psapi.h>
#include <dwmapi.h>
#include <memory>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <shlobj.h>

// Uygulama sabitleri
#define WM_APP_TRAYICON (WM_APP + 1)
#define IDM_EXIT       1001
#define IDM_SPEEDUP    1002
#define IDM_RAMINFO    1003
#define IDI_MAINICON   101
#define TIMER_RAM      1004
#define TIMER_MENU     1005

// NT API için tanımlamalar
typedef LONG NTSTATUS;
#define NT_SUCCESS(Status) ((NTSTATUS)(Status) >= 0)

typedef enum _SYSTEM_MEMORY_LIST_COMMAND {
    MemoryPurgeStandbyList = 4
} SYSTEM_MEMORY_LIST_COMMAND;

typedef NTSTATUS(WINAPI* PFN_NT_SET_SYSTEM_INFORMATION)(
    SYSTEM_MEMORY_LIST_COMMAND Command,
    PVOID SystemInformation,
    ULONG SystemInformationLength
);

// Global değişkenler
HWND g_hwnd = NULL;
NOTIFYICONDATAW g_nid = {};
bool g_isSpeedUpActive = false;
std::wstring g_currentRamInfo;
HMENU g_contextMenu = NULL;

// Temp klasör yolları
const std::vector<std::wstring> TEMP_PATHS = {
    L"C:\\Windows\\Temp",
    L"%TEMP%",
    L"%TMP%",
    L"C:\\Windows\\SoftwareDistribution\\Download",
    L"C:\\Windows\\Prefetch"
};

// Kritik işlem listesi
const std::vector<std::wstring> CRITICAL_PROCESSES = {
    L"csrss", L"wininit", L"services", L"lsass", L"winlogon",
    L"explorer", L"smss", L"svchost", L"System", L"System Idle Process"
};

// Fonksiyon bildirimleri
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void CreateTrayIcon(HWND hwnd);
void RemoveTrayIcon();
void ShowContextMenu(HWND hwnd, POINT pt);
void SpeedUpSystem();
std::wstring GetSystemInfo();
bool CleanTempFolders();
bool CleanMemory();
void UpdateSystemInfo();
DWORD64 CalculateTempSize();
void RemoveDirectory(const std::wstring& path);

// Klasör boyutunu hesaplama
DWORD64 GetDirectorySize(const std::wstring& path) {
    DWORD64 size = 0;
    WIN32_FIND_DATAW findData;
    std::wstring searchPath = path + L"\\*.*";
    
    HANDLE hFind = FindFirstFileW(searchPath.c_str(), &findData);
    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            if (wcscmp(findData.cFileName, L".") != 0 && wcscmp(findData.cFileName, L"..") != 0) {
                if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                    std::wstring subDir = path + L"\\" + findData.cFileName;
                    size += GetDirectorySize(subDir);
                }
                else {
                    DWORD64 fileSize = (static_cast<DWORD64>(findData.nFileSizeHigh) << 32) | findData.nFileSizeLow;
                    size += fileSize;
                }
            }
        } while (FindNextFileW(hFind, &findData));
        FindClose(hFind);
    }
    return size;
}

// Klasör silme işlemi (boş klasörler dahil)
void RemoveDirectory(const std::wstring& path) {
    WIN32_FIND_DATAW findData;
    std::wstring searchPath = path + L"\\*.*";
    
    HANDLE hFind = FindFirstFileW(searchPath.c_str(), &findData);
    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            if (wcscmp(findData.cFileName, L".") != 0 && wcscmp(findData.cFileName, L"..") != 0) {
                std::wstring fullPath = path + L"\\" + findData.cFileName;
                
                if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                    RemoveDirectory(fullPath); // Recursive call
                    RemoveDirectoryW(fullPath.c_str()); // Delete empty directory
                }
                else {
                    DeleteFileW(fullPath.c_str());
                }
            }
        } while (FindNextFileW(hFind, &findData));
        FindClose(hFind);
    }
    RemoveDirectoryW(path.c_str()); // Try to delete the empty directory
}

DWORD64 CalculateTempSize() {
    DWORD64 totalSize = 0;
    
    for (const auto& path : TEMP_PATHS) {
        wchar_t expandedPath[MAX_PATH];
        ExpandEnvironmentStringsW(path.c_str(), expandedPath, MAX_PATH);
        totalSize += GetDirectorySize(expandedPath);
    }
    
    return totalSize;
}

// Ana pencere işleyicisi
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_DESTROY:
            KillTimer(hwnd, TIMER_RAM);
            KillTimer(hwnd, TIMER_MENU);
            RemoveTrayIcon();
            PostQuitMessage(0);
            return 0;

        case WM_TIMER:
            if (wParam == TIMER_RAM) {
                UpdateSystemInfo();
            }
            else if (wParam == TIMER_MENU && g_contextMenu != NULL) {
                // Context menu açıkken RAM bilgisini güncelle
                ModifyMenuW(g_contextMenu, 0, MF_BYPOSITION | MF_STRING | MF_DISABLED,
                    0, g_currentRamInfo.c_str());
                DrawMenuBar(hwnd);
            }
            return 0;

        case WM_APP_TRAYICON:
            if (LOWORD(lParam) == WM_RBUTTONUP || LOWORD(lParam) == WM_CONTEXTMENU) {
                POINT pt;
                GetCursorPos(&pt);
                ShowContextMenu(hwnd, pt);
                return 0;
            }
            break;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDM_EXIT:
                    DestroyWindow(hwnd);
                    return 0;

                case IDM_SPEEDUP:
                    if (!g_isSpeedUpActive) {
                        SpeedUpSystem();
                    }
                    return 0;
            }
            break;
    }
    return DefWindowProcW(hwnd, uMsg, wParam, lParam);
}

void CreateTrayIcon(HWND hwnd) {
    g_nid = {};
    g_nid.cbSize = sizeof(NOTIFYICONDATAW);
    g_nid.hWnd = hwnd;
    g_nid.uID = 1;
    g_nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    g_nid.uCallbackMessage = WM_APP_TRAYICON;
    
    // Önce varsayılan sistem ikonunu kullan
    g_nid.hIcon = ExtractIconW(
        GetModuleHandleW(NULL),
        L"monitor.ico",
        0
    );

    // Sonra kendi ikonumuzu yüklemeyi dene
    HICON hCustomIcon = (HICON)LoadImageW(
        GetModuleHandleW(NULL), 
        MAKEINTRESOURCEW(101),  // IDI_MAINICON
        IMAGE_ICON, 
        0, 0,  // Varsayılan boyut
        LR_DEFAULTSIZE | LR_SHARED
    );

    if (hCustomIcon) {
        g_nid.hIcon = hCustomIcon;
    }
    
    UpdateSystemInfo();
    Shell_NotifyIconW(NIM_ADD, &g_nid);
}

void RemoveTrayIcon() {
    Shell_NotifyIconW(NIM_DELETE, &g_nid);
}

void ShowContextMenu(HWND hwnd, POINT pt) {
    if (g_contextMenu != NULL) {
        DestroyMenu(g_contextMenu);
    }
    
    g_contextMenu = CreatePopupMenu();
    
    // RAM bilgisini büyük ve kalın fontla ekle
    MENUITEMINFOW mii = { sizeof(MENUITEMINFOW) };
    mii.fMask = MIIM_FTYPE | MIIM_STRING | MIIM_STATE | MIIM_ID;
    mii.fType = MFT_STRING;
    mii.fState = MFS_DISABLED;
    mii.wID = IDM_RAMINFO;
    mii.dwTypeData = const_cast<LPWSTR>(g_currentRamInfo.c_str());
    InsertMenuItemW(g_contextMenu, 0, TRUE, &mii);
    
    InsertMenuW(g_contextMenu, 1, MF_BYPOSITION | MF_SEPARATOR, 0, NULL);
    InsertMenuW(g_contextMenu, 2, MF_BYPOSITION | MF_STRING, IDM_SPEEDUP, L"Speed Up System");
    InsertMenuW(g_contextMenu, 3, MF_BYPOSITION | MF_STRING, IDM_EXIT, L"Exit");

    // RAM bilgisi için özel font
    HFONT hFont = CreateFontW(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");

    if (hFont) {
        HDC hdc = GetDC(hwnd);
        HFONT hOldFont = (HFONT)SelectObject(hdc, hFont);
        
        SelectObject(hdc, hOldFont);
        ReleaseDC(hwnd, hdc);
        DeleteObject(hFont);
    }

    SetForegroundWindow(hwnd);
    TrackPopupMenu(g_contextMenu, TPM_BOTTOMALIGN | TPM_LEFTALIGN, pt.x, pt.y, 0, hwnd, NULL);
}

bool CleanTempFolders() {
    for (const auto& path : TEMP_PATHS) {
        wchar_t expandedPath[MAX_PATH];
        ExpandEnvironmentStringsW(path.c_str(), expandedPath, MAX_PATH);
        RemoveDirectory(std::wstring(expandedPath));
    }
    return true;
}

bool CleanMemory() {
    // Temel bellek temizleme
    DWORD processes[1024], needed;
    if (!EnumProcesses(processes, sizeof(processes), &needed)) {
        return false;
    }

    DWORD processCount = needed / sizeof(DWORD);
    for (DWORD i = 0; i < processCount; i++) {
        if (processes[i] != 0) {
            HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_SET_QUOTA, 
                FALSE, processes[i]);
            
            if (hProcess) {
                wchar_t processName[MAX_PATH];
                DWORD size = MAX_PATH;
                
                if (QueryFullProcessImageNameW(hProcess, 0, processName, &size)) {
                    std::wstring procName = processName;
                    size_t pos = procName.find_last_of(L"\\");
                    if (pos != std::wstring::npos) {
                        procName = procName.substr(pos + 1);
                    }

                    if (std::find(CRITICAL_PROCESSES.begin(), CRITICAL_PROCESSES.end(), 
                        procName) == CRITICAL_PROCESSES.end()) {
                        SetProcessWorkingSetSize(hProcess, 
                            static_cast<SIZE_T>(-1), static_cast<SIZE_T>(-1));
                    }
                }
                CloseHandle(hProcess);
            }
        }
    }

    // Standby listesini temizle
    HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");
    if (hNtdll) {
        auto NtSetSystemInformation = reinterpret_cast<PFN_NT_SET_SYSTEM_INFORMATION>(
            GetProcAddress(hNtdll, "NtSetSystemInformation"));
        
        if (NtSetSystemInformation) {
            SYSTEM_MEMORY_LIST_COMMAND command = MemoryPurgeStandbyList;
            NtSetSystemInformation(command, &command, sizeof(command));
        }
    }
    return true;
}

void SpeedUpSystem() {
    g_isSpeedUpActive = true;
    
    // Bellek temizleme
    CleanMemory();
    
    // Temp dosyalarını temizle
    CleanTempFolders();
    
    g_isSpeedUpActive = false;
    
    // Temizlik sonrası bilgileri güncelle
    UpdateSystemInfo();
}

std::wstring GetSystemInfo() {
    MEMORYSTATUSEX memInfo = { sizeof(MEMORYSTATUSEX) };
    GlobalMemoryStatusEx(&memInfo);
    
    double totalRAM = static_cast<double>(memInfo.ullTotalPhys) / (1024.0 * 1024.0 * 1024.0);
    double usedRAM = totalRAM * (memInfo.dwMemoryLoad / 100.0);
    
    // Temp dosyalarının toplam boyutunu hesapla
    double tempSize = static_cast<double>(CalculateTempSize()) / (1024.0 * 1024.0 * 1024.0);
    
    std::wstringstream ss;
    ss << std::fixed << std::setprecision(2);
    ss << L"RAM Usage: " << usedRAM << L"/" << totalRAM << L" GB \n";
    ss << L"Temp Files: " << tempSize << L" GB";
    
    return ss.str();
}

void UpdateSystemInfo() {
    g_currentRamInfo = GetSystemInfo();
    wcsncpy_s(g_nid.szTip, _countof(g_nid.szTip), g_currentRamInfo.c_str(), _TRUNCATE);
    Shell_NotifyIconW(NIM_MODIFY, &g_nid);
    
    // Context menu açıksa onu da güncelle
    if (g_contextMenu != NULL) {
        ModifyMenuW(g_contextMenu, 0, MF_BYPOSITION | MF_STRING | MF_DISABLED,
            0, g_currentRamInfo.c_str());
        DrawMenuBar(g_hwnd);
    }
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, PWSTR, int nCmdShow) {
    SetProcessDPIAware();

    const wchar_t CLASS_NAME[] = L"SystemMonitorClass";
    
    WNDCLASSW wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    
    if (!RegisterClassW(&wc)) {
        MessageBoxW(NULL, L"Window Registration Failed!", L"Error", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    g_hwnd = CreateWindowExW(
        0,
        CLASS_NAME,
        L"OneClickBoost",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
        NULL, NULL, hInstance, NULL
    );

    if (!g_hwnd) {
        MessageBoxW(NULL, L"Window Creation Failed!", L"Error", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    CreateTrayIcon(g_hwnd);
    
    // RAM ve Menu güncellemesi için timer'ları başlat
    SetTimer(g_hwnd, TIMER_RAM, 1000, NULL);    // Her saniye RAM bilgisini güncelle
    SetTimer(g_hwnd, TIMER_MENU, 1000, NULL);   // Her saniye menüyü güncelle

    MSG msg = {};
    while (GetMessageW(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    return 0;
}