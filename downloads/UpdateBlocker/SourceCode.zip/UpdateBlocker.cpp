#include <windows.h>
#include <commctrl.h>
#include <tchar.h>
#include <shellapi.h>
#include <uxtheme.h>
#include <dwmapi.h>
#include <string>
#include "UAHMenuBar.h"
#include <Wbemidl.h>
#include <comdef.h>
#include <taskschd.h>
#include <future> // Header kısmına eklendi
#pragma comment(lib, "uxtheme.lib")
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "wbemuuid.lib")
#pragma comment(lib, "taskschd.lib")
#pragma comment(lib, "ole32.lib")

// Menü ID'leri güncellendi
#define ID_WEBSITE 201
#define ID_GITHUB  202
#define ID_DONATE    203
#define ID_PARAMETERS 204  // Eksik tanım eklendi

// Yeni sabitleri ekle
#define SE_GROUP_POLICY_ADMIN_RIGHTS 0x80000000

// Global değişkenler
HINSTANCE hInst;
HWND hBlockBtn, hUnblockBtn;
HWND hStatusText;
static HTHEME g_menuTheme = nullptr;
static HBRUSH g_brBarBackground = CreateSolidBrush(RGB(32, 32, 32));  // Dark mode rengi

// Dark mode için gereken yapılar
struct IMMERSIVE_HC_CACHE
{
    DWORD Dirty;
    DWORD Running;
};

// Windows 10 1809 ve üzeri için dark mode API'leri
using fnSetPreferredAppMode = void (WINAPI*)(DWORD);
using fnAllowDarkModeForWindow = bool (WINAPI*)(HWND, bool);
using fnShouldAppsUseDarkMode = bool (WINAPI*)();

// Global dark mode function pointers
fnSetPreferredAppMode SetPreferredAppMode;
fnAllowDarkModeForWindow AllowDarkModeForWindow;
fnShouldAppsUseDarkMode ShouldAppsUseDarkMode;

// Dark mode için yeni global değişkenler
bool g_darkModeEnabled = true;
HBRUSH g_darkModeBrush = NULL;

// Dark mode renk tanımları
const COLORREF DARK_BG_COLOR = RGB(32, 32, 32);
const COLORREF DARK_TEXT_COLOR = RGB(255, 255, 255);
const COLORREF DARK_BUTTON_COLOR = RGB(51, 51, 51);
const COLORREF DARK_BUTTON_HOVER = RGB(75, 75, 75);     // Daha belirgin hover rengi
const COLORREF DARK_BUTTON_PRESSED = RGB(40, 40, 40);
const COLORREF STATUS_GREEN = RGB(46, 160, 67);         // Daha açık yeşil
const COLORREF STATUS_RED = RGB(218, 54, 51);          // Daha açık kırmızı
const COLORREF DARK_MENU_BG = RGB(32, 32, 32);
const COLORREF DARK_MENU_TEXT = RGB(255, 255, 255);
const COLORREF DARK_MENUBAR_BG = RGB(32, 32, 32);
const COLORREF DARK_MENUBAR_TEXT = RGB(255, 255, 255);

// Dark mode için gereken yapılar kısmına ekle:
#define DWMWA_USE_IMMERSIVE_DARK_MODE 20
#define DWMWA_CAPTION_COLOR 35

// Forward declarations
bool BlockWindowsUpdate();
bool UnblockWindowsUpdate();

// Windows Update durumunu kontrol eden fonksiyon
bool IsWindowsUpdateBlocked() {
    HKEY hKey;
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\wuauserv",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        DWORD dwType = 0;
        DWORD dwValue = 0;
        DWORD dwSize = sizeof(dwValue);
        if (RegQueryValueEx(hKey, L"Start", NULL, &dwType, (LPBYTE)&dwValue, &dwSize) == ERROR_SUCCESS) {
            RegCloseKey(hKey);
            return dwValue == 4; // 4 = Disabled
        }
        RegCloseKey(hKey);
    }
    return false;
}

// Durum göstergesini güncelle fonksiyonu - global olarak tanımlandı
void UpdateStatusText() {
    bool updateBlocked = IsWindowsUpdateBlocked();
    
    std::wstring status = L"Windows Update ";
    status += updateBlocked ? L"Devre Dışı" : L"Etkin";
    
    SetWindowText(hStatusText, status.c_str());
    InvalidateRect(hStatusText, NULL, TRUE);
}

// İlerleme fonksiyonu ekle
void UpdateProgressInTitle(HWND hwnd, const wchar_t* message) {
    static int dots = 0;
    wchar_t title[256];
    swprintf(title, 256, L"Update Blocker - %s%.*s", message, dots, L"...");
    SetWindowText(hwnd, title);
    dots = (dots + 1) % 4;
}

// Asenkron işlem için yardımcı fonksiyon
void ExecuteCommandHidden(const wchar_t* command) {
    STARTUPINFO si = { sizeof(STARTUPINFO) };
    PROCESS_INFORMATION pi;
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    wchar_t cmd[512];
    swprintf(cmd, 512, L"cmd.exe /c %s", command);
    
    CreateProcess(NULL, cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
    WaitForSingleObject(pi.hProcess, INFINITE);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
}

// Registry işlemleri için fonksiyonlar
bool BlockWindowsUpdate() {
    HWND mainWindow = FindWindow(L"UpdateBlockerClass", NULL);
    if (!mainWindow) return false;

    // İşlem başladığında butonları devre dışı bırak
    EnableWindow(GetDlgItem(mainWindow, 1), FALSE);
    EnableWindow(GetDlgItem(mainWindow, 2), FALSE);

    // İlerleme göstergesi için timer başlat
    SetTimer(mainWindow, 1, 500, NULL);

    // Asenkron işlem başlat ve future'ı sakla
    std::thread([mainWindow]() {
        // Firewall kuralları
        ExecuteCommandHidden(L"netsh advfirewall firewall add rule name=\"Block Windows Update\" dir=out action=block service=wuauserv enable=yes");
        ExecuteCommandHidden(L"netsh advfirewall firewall add rule name=\"Block Windows Update 2\" dir=out action=block program=\"%systemroot%\\system32\\svchost.exe\" group=\"Windows Update\"");

        // Servisleri durdur ve devre dışı bırak
        const wchar_t* services[] = {
            L"wuauserv", L"UsoSvc", L"bits", L"dosvc", L"WaaSMedicSvc",
            L"cryptsvc", L"trustedinstaller", L"DiagTrack", L"iphlpsvc"
        };

        for (const wchar_t* service : services) {
            wchar_t cmd[512];
            swprintf(cmd, 512, L"sc stop %s", service);
            ExecuteCommandHidden(cmd);
            swprintf(cmd, 512, L"sc config %s start= disabled", service);
            ExecuteCommandHidden(cmd);
            Sleep(100); // Servisler arası kısa beklemeler ekle
        }

        // Güvenlik politikalarını güncelle (gizli)
        ExecuteCommandHidden(L"gpupdate /force /wait:0");

        // Registry işlemleri
        const wchar_t* moreRegKeys[] = {
            L"SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU",
            L"SOFTWARE\\Microsoft\\WindowsUpdate\\UX\\Settings",
            L"SOFTWARE\\Microsoft\\WindowsUpdate\\UpdatePolicy\\Settings"
        };

        for (const wchar_t* regPath : moreRegKeys) {
            HKEY hKey;
            if (RegCreateKeyEx(HKEY_LOCAL_MACHINE, regPath, 0, NULL,
                REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKey, NULL) == ERROR_SUCCESS) {
                
                DWORD value = 1;
                RegSetValueEx(hKey, L"NoAutoUpdate", 0, REG_DWORD, (BYTE*)&value, sizeof(value));
                RegSetValueEx(hKey, L"AUOptions", 0, REG_DWORD, (BYTE*)&value, sizeof(value));
                RegCloseKey(hKey);
            }
        }

        // İşlem tamamlandığında ana pencereye mesaj gönder
        PostMessage(mainWindow, WM_APP + 1, 0, 0);
    }).detach(); // Thread'i detach et

    return true;
}

bool UnblockWindowsUpdate() {
    HWND mainWindow = FindWindow(L"UpdateBlockerClass", NULL);
    if (!mainWindow) return false;

    // İşlem başladığında butonları devre dışı bırak
    EnableWindow(GetDlgItem(mainWindow, 1), FALSE);
    EnableWindow(GetDlgItem(mainWindow, 2), FALSE);

    // İlerleme göstergesi için timer başlat
    SetTimer(mainWindow, 1, 500, NULL);

    // Asenkron işlem başlat ve thread'i detach et
    std::thread([mainWindow]() {
        // Firewall kurallarını kaldır
        ExecuteCommandHidden(L"netsh advfirewall firewall delete rule name=\"Block Windows Update\"");
        ExecuteCommandHidden(L"netsh advfirewall firewall delete rule name=\"Block Windows Update 2\"");

        // Servisleri etkinleştir ve başlat
        const wchar_t* services[] = {
            L"wuauserv", L"UsoSvc", L"bits", L"dosvc", L"WaaSMedicSvc",
            L"cryptsvc", L"trustedinstaller", L"DiagTrack", L"iphlpsvc"
        };

        for (const wchar_t* service : services) {
            wchar_t cmd[512];
            swprintf(cmd, 512, L"sc config %s start= auto", service);
            ExecuteCommandHidden(cmd);
            swprintf(cmd, 512, L"sc start %s", service);
            ExecuteCommandHidden(cmd);
            Sleep(100); // Servisler arası kısa beklemeler ekle
        }

        // Güvenlik politikalarını güncelle (gizli)
        ExecuteCommandHidden(L"gpupdate /force /wait:0");

        // Registry işlemleri
        const wchar_t* regKeys[] = {
            L"SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate",
            L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WindowsUpdate"
        };

        for (const wchar_t* key : regKeys) {
            RegDeleteTree(HKEY_LOCAL_MACHINE, key);
        }

        // İşlem tamamlandığında ana pencereye mesaj gönder
        PostMessage(mainWindow, WM_APP + 1, 0, 0);
    }).detach();

    return true;
}

// Parametre yardım mesajı
void ShowParameterHelp(HWND hwnd) {
    const wchar_t* helpText = 
        L"Komut Satırı Parametreleri:\n\n"
        L"/block         : Windows Update'i engelle\n"
        L"/unblock      : Windows Update engelini kaldır\n"
        L"/status       : Mevcut durumu göster\n\n"
        L"Örnek:\n"
        L"UpdateBlocker.exe /block";
    
    MessageBox(hwnd, helpText, L"Parametre Kullanımı", MB_OK | MB_ICONINFORMATION);
}

// Dark mode init fonksiyonu
bool InitDarkMode() {
    HMODULE hUxtheme = LoadLibraryEx(L"uxtheme.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (!hUxtheme) return false;

    SetPreferredAppMode = reinterpret_cast<fnSetPreferredAppMode>(GetProcAddress(hUxtheme, MAKEINTRESOURCEA(135)));
    AllowDarkModeForWindow = reinterpret_cast<fnAllowDarkModeForWindow>(GetProcAddress(hUxtheme, MAKEINTRESOURCEA(133)));
    ShouldAppsUseDarkMode = reinterpret_cast<fnShouldAppsUseDarkMode>(GetProcAddress(hUxtheme, MAKEINTRESOURCEA(132)));

    if (SetPreferredAppMode) {
        SetPreferredAppMode(2); // Enable dark mode
    }

    g_darkModeBrush = CreateSolidBrush(DARK_BG_COLOR);

    // Menü arkaplan rengini ayarla
    MENUINFO mi = { sizeof(MENUINFO) };
    mi.fMask = MIM_BACKGROUND | MIM_APPLYTOSUBMENUS;
    mi.hbrBack = CreateSolidBrush(DARK_MENU_BG);

    return true;
}

// WndProc içinde msg parametresini kullanan yerlerde farklı bir isim kullanalım
LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    LRESULT lr;
    if (UAHWndProc(hwnd, uMsg, wParam, lParam, &lr)) {
        return lr;
    }

    switch (uMsg) {
        case WM_CREATE: {
            // Dark mode için pencere ayarları
            if (AllowDarkModeForWindow) {
                AllowDarkModeForWindow(hwnd, true);
            }

            // Title bar ayarları
            BOOL value = TRUE;
            DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, &value, sizeof(value));
            
            // Title bar rengi için
            COLORREF captionColor = RGB(32, 32, 32); // Title bar rengi
            DwmSetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, &captionColor, sizeof(captionColor));

            // Köşeleri sivri yap
            DWM_WINDOW_CORNER_PREFERENCE corner = DWMWCP_DONOTROUND;
            DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, &corner, sizeof(corner));

            RECT rcClient;
            GetClientRect(hwnd, &rcClient);
            int clientWidth = rcClient.right - rcClient.left;
            int clientHeight = rcClient.bottom - rcClient.top;
            
            // Button pozisyonlarını üste taşı
            int buttonY = 20; // Menü çubuğunun altından başlat
            int buttonWidth = 300;
            int buttonHeight = 36;
            int buttonX = (clientWidth - buttonWidth) / 2;

            // Modern butonlar - dark mode style
            DWORD buttonStyle = WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON | BS_OWNERDRAW;
            hBlockBtn = CreateWindow(L"BUTTON", L"Windows Update'i Devre Dışı Bırak",
                buttonStyle,
                buttonX, buttonY, buttonWidth, buttonHeight, 
                hwnd, (HMENU)1, hInst, NULL);

            if (AllowDarkModeForWindow) {
                AllowDarkModeForWindow(hBlockBtn, true);
            }
            
            hUnblockBtn = CreateWindow(L"BUTTON", L"Windows Update Etkinleştir",
                buttonStyle,
                buttonX, buttonY + buttonHeight + 20, buttonWidth, buttonHeight, 
                hwnd, (HMENU)2, hInst, NULL);

            // Durum göstergesini en alta taşı
            int statusY = clientHeight - 34; // Alt kısımdan 34 piksel yukarıda
            hStatusText = CreateWindow(L"STATIC", L"",
                WS_VISIBLE | WS_CHILD | SS_CENTER | SS_CENTERIMAGE,
                0, statusY, clientWidth, 34,
                hwnd, NULL, hInst, NULL);

            // DPI Farkındalığı
            SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);

            // Menü oluştur
            HMENU hMenu = CreateMenu();
            HMENU hAboutMenu = CreatePopupMenu();

            // Parametreler menü öğesi
            AppendMenu(hMenu, MF_STRING, ID_PARAMETERS, L"Parametreler");

            // Hakkında menüsü ve alt öğeleri
            AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hAboutMenu, L"Hakkında");
            AppendMenu(hAboutMenu, MF_STRING, ID_WEBSITE, L"İnternet Sitesi");
            AppendMenu(hAboutMenu, MF_STRING, ID_GITHUB, L"GitHub");
            AppendMenu(hAboutMenu, MF_STRING, ID_DONATE, L"Bağış Yap");

            // Menüyü pencereye ata
            SetMenu(hwnd, hMenu);

            // Font oluştur
            HFONT hFont = CreateFont(20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                TURKISH_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS,
                CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");

            SendMessage(hBlockBtn, WM_SETFONT, (WPARAM)hFont, TRUE);
            SendMessage(hUnblockBtn, WM_SETFONT, (WPARAM)hFont, TRUE);
            SendMessage(hStatusText, WM_SETFONT, (WPARAM)hFont, TRUE);

            // Buton kenarları için özel tema ayarları
            SetWindowTheme(hBlockBtn, L"Explorer", NULL);  // Explorer teması daha ince kenarlar sağlar
            SetWindowTheme(hUnblockBtn, L"Explorer", NULL);

            // Durum göstergesini güncelle ve renklendir
            UpdateStatusText();

            break;
        }

        case WM_SIZE: {
            // Pencere boyutu değiştiğinde durum göstergesini yeniden konumlandır
            RECT rcClient;
            GetClientRect(hwnd, &rcClient);
            int clientWidth = rcClient.right - rcClient.left;
            int clientHeight = rcClient.bottom - rcClient.top;
            
            SetWindowPos(hStatusText, NULL,
                0, clientHeight - 34,  // Alt kısma yerleştir
                clientWidth, 34,       // Tam genişlik, 34px yükseklik
                SWP_NOZORDER);
            break;
        }

        case WM_CTLCOLORBTN: {
            HDC hdc = (HDC)wParam;
            SetTextColor(hdc, DARK_TEXT_COLOR);
            SetBkColor(hdc, DARK_BUTTON_COLOR);
            if (!g_darkModeBrush) g_darkModeBrush = CreateSolidBrush(DARK_BUTTON_COLOR);
            return (INT_PTR)g_darkModeBrush;
        }

        case WM_CTLCOLORSTATIC: {
            HDC hdcStatic = (HDC)wParam;
            HWND hwndStatic = (HWND)lParam;
            
            if (hwndStatic == hStatusText) {
                bool isBlocked = IsWindowsUpdateBlocked();
                SetBkColor(hdcStatic, isBlocked ? 
                    STATUS_RED :    // Daha açık kırmızı
                    STATUS_GREEN);  // Daha açık yeşil
                SetTextColor(hdcStatic, RGB(255, 255, 255));
                
                static HBRUSH hBrush = NULL;
                if (hBrush) DeleteObject(hBrush);
                hBrush = CreateSolidBrush(isBlocked ? 
                    STATUS_RED : 
                    STATUS_GREEN);
                return (INT_PTR)hBrush;
            }
            
            SetTextColor(hdcStatic, DARK_TEXT_COLOR);
            SetBkColor(hdcStatic, DARK_BG_COLOR);
            return (INT_PTR)g_darkModeBrush;
        }

        case WM_CTLCOLORDLG:
        case WM_CTLCOLORLISTBOX:
        case WM_CTLCOLOREDIT: {
            HDC hdc = (HDC)wParam;
            SetTextColor(hdc, DARK_TEXT_COLOR);
            SetBkColor(hdc, DARK_BG_COLOR);
            return (INT_PTR)g_darkModeBrush;
        }

        case WM_ERASEBKGND: {
            HDC hdc = (HDC)wParam;
            RECT rc;
            GetClientRect(hwnd, &rc);
            FillRect(hdc, &rc, g_darkModeBrush);
            return 1;
        }

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case 1: // Block butonu
                    if (BlockWindowsUpdate()) {
                        // Başlangıç mesajı yeter, tamamlandı mesajı WM_APP+1'de gösterilecek
                        UpdateStatusText();
                    }
                    break;
                case 2: // Unblock butonu
                    if (UnblockWindowsUpdate()) {
                        // Başlangıç mesajı yeter, tamamlandı mesajı WM_APP+1'de gösterilecek
                        UpdateStatusText();
                    }
                    break;
                case ID_WEBSITE:
                    ShellExecute(NULL, L"open", L"https://shade-cloud.vercel.app", NULL, NULL, SW_SHOW);
                    break;
                case ID_GITHUB:
                    ShellExecute(NULL, L"open", L"https://github.com/shadesofdeath", NULL, NULL, SW_SHOW);
                    break;
                case ID_DONATE:
                    ShellExecute(NULL, L"open", L"https://buymeacoffee.com/berkayay", NULL, NULL, SW_SHOW);
                    break;
                case ID_PARAMETERS:
                    ShowParameterHelp(hwnd);
                    break;
            }
            break;

        case WM_DESTROY:
            if (g_darkModeBrush) DeleteObject(g_darkModeBrush);
            if (g_menuTheme) {
                CloseThemeData(g_menuTheme);
                g_menuTheme = nullptr;
            }
            if (g_brBarBackground) DeleteObject(g_brBarBackground);
            PostQuitMessage(0);
            break;

        case WM_MEASUREITEM: {
            LPMEASUREITEMSTRUCT lpmis = (LPMEASUREITEMSTRUCT)lParam;
            lpmis->itemHeight = 25; // Menü öğesi yüksekliği
            return TRUE;
        }

        case WM_DRAWITEM: {
            LPDRAWITEMSTRUCT lpdis = (LPDRAWITEMSTRUCT)lParam;
            if (lpdis->CtlType == ODT_MENU) {
                bool isMainMenu = (GetMenu(hwnd) == (HMENU)lpdis->hwndItem);
                BOOL isSelected = lpdis->itemState & ODS_SELECTED;
                
                // Arkaplan rengi
                COLORREF bgColor;
                if (isMainMenu) {
                    bgColor = isSelected ? RGB(70, 70, 70) : DARK_MENUBAR_BG;
                } else {
                    bgColor = isSelected ? RGB(70, 70, 70) : DARK_MENU_BG;
                }
                
                FillRect(lpdis->hDC, &lpdis->rcItem, CreateSolidBrush(bgColor));
                
                // Metin rengi
                SetTextColor(lpdis->hDC, isMainMenu ? DARK_MENUBAR_TEXT : DARK_MENU_TEXT);
                SetBkMode(lpdis->hDC, TRANSPARENT);
                
                // Menü metnini çiz
                WCHAR text[256] = {0};
                if (isMainMenu) {
                    GetMenuString((HMENU)lpdis->hwndItem, lpdis->itemID, text, 256, MF_BYCOMMAND);
                } else if (lpdis->itemData) {
                    GetMenuString((HMENU)lpdis->hwndItem, lpdis->itemID, text, 256, MF_BYCOMMAND);
                }
                
                // Metin pozisyonunu ayarla
                RECT textRect = lpdis->rcItem;
                textRect.left += 8; // Sol kenar boşluğu
                
                DrawText(lpdis->hDC, text, -1, &textRect, 
                    DT_SINGLELINE | DT_VCENTER | (isMainMenu ? DT_CENTER : DT_LEFT));
                
                return TRUE;
            }
            else if (lpdis->CtlType == ODT_BUTTON) {
                bool isPressed = lpdis->itemState & ODS_SELECTED;
                bool isHot = lpdis->itemState & ODS_HOTLIGHT || (GetCapture() == lpdis->hwndItem);
                bool isFocused = lpdis->itemState & ODS_FOCUS;
                
                // Buton arkaplanı
                COLORREF btnColor;
                if (isPressed)
                    btnColor = DARK_BUTTON_PRESSED;
                else if (isHot)
                    btnColor = DARK_BUTTON_HOVER;
                else
                    btnColor = DARK_BUTTON_COLOR;

                // Buton arkaplanını doldur
                HBRUSH hBrush = CreateSolidBrush(btnColor);
                FillRect(lpdis->hDC, &lpdis->rcItem, hBrush);
                DeleteObject(hBrush);
                
                // Buton kenarı çiz
                HPEN hPen = CreatePen(PS_SOLID, 1, isHot ? DARK_BUTTON_HOVER : RGB(45, 45, 45));
                HPEN hOldPen = (HPEN)SelectObject(lpdis->hDC, hPen);
                SelectObject(lpdis->hDC, GetStockObject(NULL_BRUSH));
                Rectangle(lpdis->hDC, lpdis->rcItem.left, lpdis->rcItem.top, 
                    lpdis->rcItem.right, lpdis->rcItem.bottom);
                SelectObject(lpdis->hDC, hOldPen);
                DeleteObject(hPen);
                
                // Buton metni
                SetTextColor(lpdis->hDC, DARK_TEXT_COLOR);
                SetBkMode(lpdis->hDC, TRANSPARENT);
                
                WCHAR text[256];
                GetWindowText(lpdis->hwndItem, text, 256);
                
                // Metni ortala
                DrawText(lpdis->hDC, text, -1, &lpdis->rcItem, 
                    DT_SINGLELINE | DT_CENTER | DT_VCENTER);
                
                if (isFocused) {
                    RECT focusRect = lpdis->rcItem;
                    InflateRect(&focusRect, -3, -3);
                    DrawFocusRect(lpdis->hDC, &focusRect);
                }
                
                return TRUE;
            }
            return FALSE;
        }

        case WM_NCPAINT:
        case WM_NCACTIVATE: {
            BOOL value = TRUE;
            DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, &value, sizeof(value));
            
            COLORREF captionColor = RGB(32, 32, 32);
            DwmSetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, &captionColor, sizeof(captionColor));
            
            // Windows'un varsayılan title bar çizimini kullan
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
        }

        case WM_MENUCHAR: {
            // Menüde alt+tuş kombinasyonlarını engelle
            return MAKELRESULT(0, MNC_CLOSE);
        }

        case WM_APP + 1: // İşlem tamamlandı mesajı
            KillTimer(hwnd, 1);
            SetWindowText(hwnd, L"Update Blocker");
            EnableWindow(GetDlgItem(hwnd, 1), TRUE);
            EnableWindow(GetDlgItem(hwnd, 2), TRUE);
            UpdateStatusText();
            InvalidateRect(hwnd, NULL, TRUE);

            // İşlem başarılı mesajını göster
            if (IsWindowsUpdateBlocked()) {
                MessageBox(hwnd, L"Windows Update başarıyla devre dışı bırakıldı!", L"İşlem Tamamlandı", MB_OK | MB_ICONINFORMATION);
            } else {
                MessageBox(hwnd, L"Windows Update başarıyla etkinleştirildi!", L"İşlem Tamamlandı", MB_OK | MB_ICONINFORMATION);
            }
            break;

        case WM_TIMER:
            if (wParam == 1) {
                static int dots = 0;
                wchar_t title[256];
                swprintf(title, 256, L"Update Blocker - İşlem Devam Ediyor%.*s", dots, L"...");
                SetWindowText(hwnd, title);
                dots = (dots + 1) % 4;
            }
            break;

        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
    return 0;
}

// WinMain fonksiyonunda pencere boyutunu güncelle
int WINAPI wWinMain(
    _In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE /* hPrevInstance */,  // Kullanılmıyor
    _In_ LPWSTR /* lpCmdLine */,            // Kullanılmıyor
    _In_ int nShowCmd)
{
    hInst = hInstance;

    // Komut satırı parametrelerini işle
    int argc;
    LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    bool validCommand = false;
    
    if (argc > 1) {
        bool blockRequested = false;
        bool unblockRequested = false;
        bool showStatus = false;
        bool showHelp = false;
        
        for (int i = 1; i < argc; i++) {
            if (_wcsicmp(argv[i], L"/block") == 0) {
                blockRequested = true;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/unblock") == 0) {
                unblockRequested = true;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/status") == 0) {
                showStatus = true;
                validCommand = true;
            }
            else if (_wcsicmp(argv[i], L"/?") == 0 || _wcsicmp(argv[i], L"/help") == 0) {
                showHelp = true;
                validCommand = true;
            }
        }
        
        if (!validCommand) {
            ShowParameterHelp(NULL);
            LocalFree(argv);
            return 1;
        }

        if (showHelp) {
            ShowParameterHelp(NULL);
            LocalFree(argv);
            return 0;
        }
        
        if (showStatus) {
            std::wstring status = L"Windows Update: ";
            status += IsWindowsUpdateBlocked() ? L"Devre Dışı" : L"Etkin";
        }
        
        if (unblockRequested) {
            UnblockWindowsUpdate();
            LocalFree(argv);
            return 0;
        }

        LocalFree(argv);
        return 0; // Herhangi bir geçerli komut varsa GUI'yi açma
    }
    
    LocalFree(argv);

    WNDCLASSEX wc = {0};
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszClassName = L"UpdateBlockerClass";
    // İkonu kaynaktan yükle
    wc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(1));
    wc.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(1));

    if (!RegisterClassEx(&wc)) {
        MessageBox(NULL, L"Window Registration Failed!", L"Error", 
            MB_OK | MB_ICONERROR);
        return 0;
    }

    // DPI ölçeklendirme için
    SetProcessDPIAware();

    // Dark mode'u başlat
    InitDarkMode();

    // Ekran boyutlarını al
    RECT workArea;
    SystemParametersInfo(SPI_GETWORKAREA, 0, &workArea, 0);
    
    // Pencere boyutları
    int windowWidth = 500;
    int windowHeight = 250; // Yüksekliği ayarla

    // Çalışma alanının merkezine konumlandır
    int windowX = workArea.left + (workArea.right - workArea.left - windowWidth) / 2;
    int windowY = workArea.top + (workArea.bottom - workArea.top - windowHeight) / 2;

    HWND hwnd = CreateWindowEx(
        WS_EX_COMPOSITED, // Daha pürüzsüz görünüm
        L"UpdateBlockerClass",
        L"Update Blocker",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,  // Window style güncellendi
        windowX, windowY,    // Merkez konumu
        windowWidth, windowHeight,
        NULL, NULL, hInstance, NULL);

    if (hwnd == NULL) {
        MessageBox(NULL, L"Window Creation Failed!", L"Error", 
            MB_OK | MB_ICONERROR);
        return 0;
    }

    ShowWindow(hwnd, nShowCmd);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (int)msg.wParam;
}
