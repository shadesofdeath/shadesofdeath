﻿using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using Wpf.Ui.Controls;

namespace FileUploader
{
    public partial class MainWindow : FluentWindow
    {
        private readonly ObservableCollection<UploadItem> _uploadItems;
        private readonly HttpClient _httpClient;
        private readonly Dictionary<string, CancellationTokenSource> _cancellationTokens;
        private readonly string _historyFilePath;

        public ICommand CopyLinkCommand { get; }
        public ICommand CancelUploadCommand { get; }
        public ICommand ShowAboutCommand { get; }

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;

            _uploadItems = new ObservableCollection<UploadItem>();
            _httpClient = new HttpClient();
            _cancellationTokens = new Dictionary<string, CancellationTokenSource>();
            _historyFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "upload_history.json");

            UploadList.ItemsSource = _uploadItems;

            CopyLinkCommand = new RelayCommand<UploadItem>(CopyDownloadLink);
            CancelUploadCommand = new RelayCommand<UploadItem>(CancelUpload);
            ShowAboutCommand = new RelayCommand<object>(_ => ShowAboutDialog());

            LoadUploadHistory();

            Loaded += (sender, args) =>
            {
                Wpf.Ui.Appearance.SystemThemeWatcher.Watch(
                    this,
                    WindowBackdropType.Mica,
                    true
                );
            };
        }
        private void LoadUploadHistory()
        {
            try
            {
                if (File.Exists(_historyFilePath))
                {
                    var json = File.ReadAllText(_historyFilePath);
                    var historyItems = JsonConvert.DeserializeObject<List<UploadItem>>(json);
                    foreach (var item in historyItems)
                    {
                        item.IsCompleted = true;
                        item.IsUploading = false;
                        _uploadItems.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                ShowSnackbar("Geçmiş Yükleme Hatası", "Geçmiş yüklemeler yüklenirken hata oluştu", SymbolRegular.ErrorCircle24);
            }
        }

        private void SaveUploadHistory()
        {
            try
            {
                var completedItems = _uploadItems
                    .Where(item => item.IsCompleted)
                    .ToList();
                var json = JsonConvert.SerializeObject(completedItems, Formatting.Indented);
                File.WriteAllText(_historyFilePath, json);
            }
            catch (Exception ex)
            {
                ShowSnackbar("Geçmiş Kaydetme Hatası", "Geçmiş kayıt edilirken hata oluştu", SymbolRegular.ErrorCircle24);
            }
        }

        private void ShowAboutDialog()
        {
            var dialog = new Wpf.Ui.Controls.MessageBox
            {
                Title = "Hakkında",
                Content = "Uygulama ShadesOfDeath tarafından geliştirilmiştir.\n\n" +
                         "Başlıca özellikleri:\n" +
                         "\n" +
                         "> Hızlı\n" +
                         "> Basit kullanıcı arayüzü, gereksiz şeyler yok, sadece çalışıyor.\n" +
                         "> Dosya boyutu sınırı yok, indirme hızı sınırı yok.\n" +
                         "> Kesin Sıfır Kayıt Politikası - Ne yüklediğiniz veya indirdiğiniz bizim için önemli değil.\n" +
                         "> Dosyalar son 45 gün içinde indirildiği sürece sonsuza kadar saklanacaktır.",
                CloseButtonText = "Tamam",
            };

            dialog.ShowDialogAsync();
        }
        private void DropZone_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                foreach (string file in files)
                {
                    StartUpload(file);
                }
            }

            DropZone.Background = Application.Current.Resources["ControlFillColorDefaultBrush"] as Brush;
        }

        private void DropZone_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                DropZone.Background = Application.Current.Resources["ControlFillColorSecondaryBrush"] as Brush;
            }
        }

        private void DropZone_DragLeave(object sender, DragEventArgs e)
        {
            DropZone.Background = Application.Current.Resources["ControlFillColorDefaultBrush"] as Brush;
        }

        private void DropZone_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Multiselect = true,
                Title = "Yüklenecek dosyaları seçin"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                foreach (string fileName in openFileDialog.FileNames)
                {
                    StartUpload(fileName);
                }
            }
        }

        private async void StartUpload(string filePath)
        {
            var fileInfo = new FileInfo(filePath);
            var uploadItem = new UploadItem
            {
                FileName = fileInfo.Name,
                FileSize = fileInfo.Length,
                Status = "Yükleniyor...",
                Progress = 0,
                UploadSpeed = 0,
                IsUploading = true
            };

            _uploadItems.Add(uploadItem);

            var cts = new CancellationTokenSource();
            _cancellationTokens[uploadItem.Id] = cts;

            try
            {
                var url = $"https://w.buzzheavier.com/{Uri.EscapeDataString(fileInfo.Name)}";

                using var fileStream = File.OpenRead(filePath);
                var streamContent = new ProgressStreamContent(
                    fileStream,
                    4096,
                    progress => uploadItem.Progress = progress,
                    speed => uploadItem.UploadSpeed = speed,
                    cts.Token
                );

                var response = await _httpClient.PutAsync(url, streamContent, cts.Token);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = JObject.Parse(responseContent);
                    var fileId = responseJson["data"]["id"].ToString();
                    uploadItem.Id = fileId;
                    uploadItem.DownloadLink = $"https://buzzheavier.com/{fileId}";
                    uploadItem.Status = "Tamamlandı";
                    uploadItem.IsCompleted = true;
                    uploadItem.IsUploading = false;

                    ShowSnackbar("Yükleme Başarılı", "Dosya başarıyla yüklendi", SymbolRegular.CheckmarkCircle24);
                    SaveUploadHistory();
                }
                else
                {
                    uploadItem.Status = $"Hata: {responseContent}";
                    ShowSnackbar("Yükleme Hatası", responseContent, SymbolRegular.ErrorCircle24);
                    RemoveUploadItem(uploadItem);
                }
            }
            catch (OperationCanceledException)
            {
                uploadItem.Status = "İptal Edildi";
                ShowSnackbar("Yükleme İptal Edildi", "Dosya yüklemesi iptal edildi", SymbolRegular.Dismiss24);
                RemoveUploadItem(uploadItem);
            }
            catch (Exception ex)
            {
                uploadItem.Status = $"Hata: {ex.Message}";
                ShowSnackbar("Yükleme Hatası", ex.Message, SymbolRegular.ErrorCircle24);
                RemoveUploadItem(uploadItem);
            }
            finally
            {
                _cancellationTokens.Remove(uploadItem.Id);
            }
        }

        private void ShowSnackbar(string title, string message, SymbolRegular icon)
        {
            var snackbar = new Snackbar(SnackbarPresenter)
            {
                Title = title,
                Content = message,
                Icon = new SymbolIcon { Symbol = icon },
                Timeout = TimeSpan.FromSeconds(3)
            };
            snackbar.Show();
        }

        private void RemoveUploadItem(UploadItem item)
        {
            Application.Current.Dispatcher.BeginInvoke(new Action(() =>
            {
                _uploadItems.Remove(item);
            }));
        }

        private void CopyDownloadLink(UploadItem item)
        {
            if (!string.IsNullOrEmpty(item.DownloadLink))
            {
                Clipboard.SetText(item.DownloadLink);
                ShowSnackbar("Bağlantı Kopyalandı", "İndirme bağlantısı panoya kopyalandı", SymbolRegular.Copy24);
            }
        }

        private void CancelUpload(UploadItem item)
        {
            if (_cancellationTokens.TryGetValue(item.Id, out var cts))
            {
                cts.Cancel();
                RemoveUploadItem(item);
            }
        }

        private void Website_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "https://shadesofdeath.github.io/shadesofdeath",
                    UseShellExecute = true
                };
                Process.Start(psi);
            }
            catch (Exception)
            {
                ShowSnackbar("Hata", "Web sitesi açılırken hata oluştu", SymbolRegular.ErrorCircle24);
            }
        }
        private void Github_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "https://github.com/shadesofdeath",
                    UseShellExecute = true
                };
                Process.Start(psi);
            }
            catch (Exception)
            {
                ShowSnackbar("Hata", "Web sitesi açılırken hata oluştu", SymbolRegular.ErrorCircle24);
            }
        }
    }

    public class UploadItem : INotifyPropertyChanged
    {
        private string _fileName;
        private long _fileSize;
        private double _progress;
        private string _status;
        private string _downloadLink;
        private double _uploadSpeed;
        private bool _isCompleted;
        private bool _isUploading;
        private string _id = Guid.NewGuid().ToString();

        public string FileName
        {
            get => _fileName;
            set
            {
                _fileName = value;
                OnPropertyChanged(nameof(FileName));
            }
        }

        public long FileSize
        {
            get => _fileSize;
            set
            {
                _fileSize = value;
                OnPropertyChanged(nameof(FileSize));
                OnPropertyChanged(nameof(FileSizeFormatted));
            }
        }

        public string FileSizeFormatted => FormatFileSize(FileSize);

        public double Progress
        {
            get => _progress;
            set
            {
                _progress = value;
                OnPropertyChanged(nameof(Progress));
            }
        }

        public string Status
        {
            get => _status;
            set
            {
                _status = value;
                OnPropertyChanged(nameof(Status));
            }
        }

        public string DownloadLink
        {
            get => _downloadLink;
            set
            {
                _downloadLink = value;
                OnPropertyChanged(nameof(DownloadLink));
            }
        }

        public double UploadSpeed
        {
            get => _uploadSpeed;
            set
            {
                _uploadSpeed = value;
                OnPropertyChanged(nameof(UploadSpeed));
                OnPropertyChanged(nameof(UploadSpeedFormatted));
            }
        }

        public string UploadSpeedFormatted => $"{FormatFileSize((long)UploadSpeed)}/s";

        public bool IsCompleted
        {
            get => _isCompleted;
            set
            {
                _isCompleted = value;
                OnPropertyChanged(nameof(IsCompleted));
            }
        }

        public bool IsUploading
        {
            get => _isUploading;
            set
            {
                _isUploading = value;
                OnPropertyChanged(nameof(IsUploading));
            }
        }

        public string Id
        {
            get => _id;
            set
            {
                _id = value;
                OnPropertyChanged(nameof(Id));
            }
        }

        private string FormatFileSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB", "TB" };
            int order = 0;
            double size = bytes;
            while (size >= 1024 && order < sizes.Length - 1)
            {
                order++;
                size = size / 1024;
            }
            return $"{size:0.##} {sizes[order]}";
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class ProgressStreamContent : StreamContent
    {
        private readonly Stream _stream;
        private readonly Action<double> _progress;
        private readonly Action<double> _speedProgress;
        private readonly CancellationToken _cancellationToken;
        private readonly int _bufferSize;
        private readonly long _totalBytes;
        private DateTime _lastSpeedUpdate = DateTime.Now;
        private long _bytesSinceLastUpdate;

        public ProgressStreamContent(
            Stream stream,
            int bufferSize,
            Action<double> progress,
            Action<double> speedProgress,
            CancellationToken cancellationToken) : base(stream, bufferSize)
        {
            _stream = stream;
            _progress = progress;
            _speedProgress = speedProgress;
            _cancellationToken = cancellationToken;
            _bufferSize = bufferSize;
            _totalBytes = stream.Length;
        }

        protected override async Task SerializeToStreamAsync(Stream stream, TransportContext context)
        {
            var buffer = new byte[_bufferSize];
            long totalBytesRead = 0;

            while (true)
            {
                _cancellationToken.ThrowIfCancellationRequested();

                var bytesRead = await _stream.ReadAsync(buffer, 0, buffer.Length, _cancellationToken);
                if (bytesRead == 0) break;

                await stream.WriteAsync(buffer, 0, bytesRead, _cancellationToken);

                totalBytesRead += bytesRead;
                _bytesSinceLastUpdate += bytesRead;

                var progressPercentage = (double)totalBytesRead / _totalBytes * 100;
                _progress?.Invoke(progressPercentage);

                var now = DateTime.Now;
                var timeDiff = (now - _lastSpeedUpdate).TotalSeconds;
                if (timeDiff >= 1)
                {
                    var speed = _bytesSinceLastUpdate / timeDiff;
                    _speedProgress?.Invoke(speed);
                    _bytesSinceLastUpdate = 0;
                    _lastSpeedUpdate = now;
                }
            }
        }
    }

    public class RelayCommand<T> : ICommand
    {
        private readonly Action<T> _execute;
        private readonly Func<T, bool> _canExecute;

        public RelayCommand(Action<T> execute, Func<T, bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public bool CanExecute(object parameter) =>
            _canExecute?.Invoke((T)parameter) ?? true;

        public void Execute(object parameter) =>
            _execute((T)parameter);
    }
}