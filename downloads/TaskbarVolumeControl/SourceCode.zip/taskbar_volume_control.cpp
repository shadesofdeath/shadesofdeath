#include <windows.h>
#include <endpointvolume.h>
#include <mmdeviceapi.h>
#include <shellapi.h>

#pragma comment(lib, "Ole32.lib")
#pragma comment(lib, "User32.lib")
#pragma comment(lib, "Shell32.lib")

IMMDeviceEnumerator* pDeviceEnumerator = nullptr;
IMMDevice* pDevice = nullptr;
IAudioEndpointVolume* pAudioEndpointVolume = nullptr;

// Taskbar üzerinde olup olmadığını kontrol eden fonksiyon
bool IsMouseOverTaskbar()
{
    POINT cursorPos;
    GetCursorPos(&cursorPos);

    HWND taskbar = FindWindow(L"Shell_TrayWnd", nullptr);
    if (taskbar)
    {
        RECT taskbarRect;
        GetWindowRect(taskbar, &taskbarRect);
        return PtInRect(&taskbarRect, cursorPos);
    }
    return false;
}

// Ses seviyesini ayarlayan fonksiyon
void AdjustVolume(float delta)
{
    if (pAudioEndpointVolume)
    {
        float currentVolume = 0.0f;
        pAudioEndpointVolume->GetMasterVolumeLevelScalar(&currentVolume);

        float newVolume = currentVolume + delta;
        if (newVolume > 1.0f) newVolume = 1.0f;
        if (newVolume < 0.0f) newVolume = 0.0f;

        pAudioEndpointVolume->SetMasterVolumeLevelScalar(newVolume, nullptr);
    }
}

// Mouse olaylarını yakalayan hook
LRESULT CALLBACK LowLevelMouseProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode == HC_ACTION && wParam == WM_MOUSEWHEEL)
    {
        MSLLHOOKSTRUCT* pMouseStruct = (MSLLHOOKSTRUCT*)lParam;
        if (pMouseStruct && IsMouseOverTaskbar())
        {
            short zDelta = GET_WHEEL_DELTA_WPARAM(pMouseStruct->mouseData);
            float delta = zDelta > 0 ? 0.05f : -0.05f; // Scroll hassasiyeti
            AdjustVolume(delta);
            return 1; // Olayı işlenmiş olarak işaretle
        }
    }
    return CallNextHookEx(nullptr, nCode, wParam, lParam);
}

// Tray simgesi oluşturma
void CreateTrayIcon()
{
    NOTIFYICONDATA nid;
    ZeroMemory(&nid, sizeof(nid));
    nid.cbSize = sizeof(nid);
    nid.uID = 1;
    nid.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
    nid.uCallbackMessage = WM_APP + 1;
    nid.hIcon = LoadIcon(NULL, IDI_INFORMATION); // Varsayılan ikon
    lstrcpy(nid.szTip, L"Taskbar Volume Control");

    Shell_NotifyIcon(NIM_ADD, &nid);
}

// Arka planda çalışan bir uygulama olarak başlatmak için:
int main()
{
    // COM başlatılıyor
    CoInitialize(nullptr);

    // Ses kontrolüne erişim sağlanıyor
    CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, __uuidof(IMMDeviceEnumerator), (void**)&pDeviceEnumerator);
    pDeviceEnumerator->GetDefaultAudioEndpoint(eRender, eConsole, &pDevice);
    pDevice->Activate(__uuidof(IAudioEndpointVolume), CLSCTX_ALL, nullptr, (void**)&pAudioEndpointVolume);

    // Konsol penceresini gizle
    HWND hwnd = GetConsoleWindow();
    ShowWindow(hwnd, SW_HIDE); // Bu satırla konsol penceresini gizliyoruz

    // Tray simgesi ekle
    CreateTrayIcon();

    // Global mouse hook ayarlanıyor
    HHOOK hHook = SetWindowsHookEx(WH_MOUSE_LL, LowLevelMouseProc, nullptr, 0);

    // Olay döngüsü
    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // Kaynaklar serbest bırakılıyor
    UnhookWindowsHookEx(hHook);
    pAudioEndpointVolume->Release();
    pDevice->Release();
    pDeviceEnumerator->Release();
    CoUninitialize();

    return 0;
}
